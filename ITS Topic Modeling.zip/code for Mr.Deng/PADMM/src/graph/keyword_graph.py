# src/graph/keyword_graph.py

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
from scipy.sparse import coo_matrix, csr_matrix, save_npz

from src.data_pipeline.combine_cities import load_paths


def _load_vocab(vocab_path: Path) -> Dict[str, int]:
    """
    Load vocabulary JSON and return token_to_id dict.

    Expects vocab.json structure:
    {
      "token_to_id": { "<token>": <id>, ... },
      "id_to_token": [ "<token0>", "<token1>", ... ],
      "freq": { "<token>": <frequency>, ... }
    }
    """
    if not vocab_path.exists():
        raise FileNotFoundError(f"Vocabulary file not found: {vocab_path}")

    with vocab_path.open("r", encoding="utf-8") as f:
        vocab_obj = json.load(f)

    token_to_id = vocab_obj.get("token_to_id", {})
    if not token_to_id:
        raise ValueError(f"No 'token_to_id' found in vocab JSON: {vocab_path}")

    return token_to_id


def _load_post_tokens(tokens_csv_path: Path) -> pd.DataFrame:
    """
    Load tokenized posts.

    Expected columns in post_tokens.csv:
      - doc_index : int (0..N-1)
      - city
      - 博主id
      - tokens : space-separated token string
    """
    if not tokens_csv_path.exists():
        raise FileNotFoundError(f"Tokenized posts file not found: {tokens_csv_path}")

    df_tokens = pd.read_csv(tokens_csv_path, encoding="utf-8-sig")

    required_cols = ["doc_index", "tokens"]
    for col in required_cols:
        if col not in df_tokens.columns:
            raise ValueError(
                f"Expected column '{col}' in tokenized posts CSV, "
                f"but not found in: {tokens_csv_path}"
            )

    return df_tokens


def _load_post_weights(weights_array_path: Path) -> np.ndarray:
    """
    Load the post-level influence weights w_p as a NumPy array.

    Shape is expected to be (N_posts,).
    """
    if not weights_array_path.exists():
        raise FileNotFoundError(
            f"Post weights array (.npy) not found: {weights_array_path}"
        )

    weights = np.load(weights_array_path)
    if weights.ndim != 1:
        raise ValueError(
            f"Expected 1D weights array, got shape {weights.shape} "
            f"from {weights_array_path}"
        )
    return weights


def _load_salience(salience_path: Path, vocab_size: int, use_salience: bool) -> np.ndarray:
    """
    Load salience scores s_i for each vocabulary term.

    If use_salience is False, returns a vector of ones (s_i = 1).
    If use_salience is True but the file does not exist, we fall back to ones
    with a warning; for strict methodology matching, ensure the salience stage
    is run first.
    """
    if not use_salience:
        return np.ones(vocab_size, dtype=np.float32)

    if not salience_path.exists():
        print(
            f"[Graph] WARNING: salience file not found at {salience_path}. "
            f"Proceeding with s_i = 1 for all i (equivalent to No-Salience)."
        )
        return np.ones(vocab_size, dtype=np.float32)

    s = np.load(salience_path)
    if s.ndim != 1 or s.shape[0] != vocab_size:
        raise ValueError(
            f"Salience vector shape {s.shape} does not match vocab size {vocab_size}."
        )

    # Ensure nonnegative
    s = np.maximum(s, 0.0).astype(np.float32)

    # Avoid exact zeros (which would erase edges); keep tiny epsilon instead
    eps = 1e-12
    s[s < eps] = eps

    return s


def build_and_save_keyword_graph(
    paths_config: str = "configs/paths.yaml",
    use_post_weights: bool = True,
    use_salience: bool = True,
) -> None:
    """
    Build an influence- and salience-weighted keyword graph and save it as a
    sparse adjacency matrix W \in R_+^{V x V}, exactly matching the methodology:

        For each post p with token sequence s_p = (t_{p,1},...,t_{p,L_p}),
        we consider ONLY unordered adjacent bigrams:

            E_p = {
               ( min{π(t_{p,k}), π(t_{p,k+1})},
                 max{π(t_{p,k}), π(t_{p,k+1})} )
               : 1 <= k < L_p, π(t_{p,k}) != π(t_{p,k+1})
            }.

        Define δ^{(p)}_{ij} = I{(i,j) ∈ E_p}, i.e. at most 1 per post.

        The edge weight is then:

            ω(i,j) = s_i s_j ∑_p w_p δ^{(p)}_{ij},    i ≠ j,

        where w_p is the post influence weight, and s_i is the salience of word i.

    Implementation details:
      - We build ω(i,j) only for i < j (upper triangle), then symmetrize.
      - Self-loops are set to zero.
      - For ablations:
          * use_post_weights=False  -> w_p = 1 for all posts.
          * use_salience=False      -> s_i = 1 for all i (removes s_i s_j factor).
    """
    data_paths: Dict[str, str] = load_paths(paths_config)

    # Handle vocab path key name difference
    if "vocab_json" in data_paths:
        vocab_path = Path(data_paths["vocab_json"])
    else:
        vocab_path = Path(data_paths["vocab_path"])

    tokens_dir = Path(data_paths["tokens_dir"])
    tokens_csv_path = tokens_dir / "post_tokens.csv"
    weights_array_path = Path(data_paths["weights_array"])
    salience_path = Path(data_paths["salience_scores"])
    graph_path = Path(data_paths["graph_path"])

    # ------------------------------
    # Load vocabulary and salience
    # ------------------------------
    print(f"[Graph] Loading vocabulary from: {vocab_path}")

    # --- Vocabulary and token index mapping π ---
    # token_to_id : dict mapping token string -> vocab index i
    # This implements π(t), where π(·) maps each token t to its index i in [V].
    token_to_id = _load_vocab(vocab_path)
    vocab_size = len(token_to_id)
    print(f"[Graph] Vocab size: {vocab_size}")

    print(f"[Graph] Loading salience scores from: {salience_path}")
    # Loading s into the graph builder
    s = _load_salience(salience_path, vocab_size=vocab_size, use_salience=use_salience)
    # If use_salience=False, _load_salience returns np.ones(V), which is exactly the ablation setting s_i≡1.
    print(
        f"[Graph] Salience stats: min={s.min():.6e}, "
        f"max={s.max():.6e}, mean={s.mean():.6e}"
    )

    # ------------------------------
    # Load tokenized posts and weights
    # ------------------------------
    print(f"[Graph] Loading tokenized posts from: {tokens_csv_path}")
    # --- Load cleaned token sequences s_p and apply π ---
    df_tokens = _load_post_tokens(tokens_csv_path)
    num_posts = df_tokens.shape[0]
    print(f"[Graph] Number of tokenized posts: {num_posts}")

    print(f"[Graph] Loading post weights from: {weights_array_path}")
    post_weights = _load_post_weights(weights_array_path) # load all w_p values

    if post_weights.shape[0] != num_posts:
        raise ValueError(
            f"Mismatch between number of posts in tokens ({num_posts}) and "
            f"length of post weights array ({post_weights.shape[0]})."
        )

    # Optional: verify doc_index is 0..N-1 in order
    expected_indices = np.arange(num_posts)
    actual_indices = df_tokens["doc_index"].to_numpy()
    if not np.array_equal(expected_indices, actual_indices):
        print(
            "[Graph] WARNING: doc_index column is not strictly 0..N-1 in order. "
            "We will still align by row order, but this may indicate a mismatch."
        )

    # ------------------------------
    # Build ω(i,j) using adjacent bigrams only
    # ------------------------------
    edge_weights: Dict[Tuple[int, int], float] = defaultdict(float)

    print("[Graph] Building co-occurrence edges from adjacent bigrams...")
    for row_idx, row in df_tokens.iterrows():
        token_str = row["tokens"]
        if not isinstance(token_str, str) or not token_str.strip():
            continue

        # Map tokens to ids, skipping OOV tokens
        tokens = token_str.split()
        token_ids: List[int] = []
        # tokens = (t_{p,1}, ..., t_{p,L_p})
        # token_to_id[tok] = π(t), so token_ids[k] = π(t_{p,k})
        for tok in tokens:
            if tok in token_to_id:
                token_ids.append(token_to_id[tok])

        L = len(token_ids) # L = L_p = sequence length for post p
        if L < 2:
            # skip posts with L_p < 2 (cannot form adjacent bigrams)
            continue

        # w_p = static influence weight for post p (computed in influence_weights.py
        # from iTF, iIDF, HN-style decay, and normalization). Here we load the 1-D
        # array post_weights and extract w_p for this row; if use_post_weights=False,
        # this enforces the ablation w_p ≡ 1. These weights scale each post's
        # contribution when building the influence-weighted graph W.

        w_p = float(post_weights[row_idx]) if use_post_weights else 1.0
        if w_p <= 0.0:
            continue

        # Collect unique adjacent pairs (unordered) for this post: δ^{(p)}_{ij} ∈ {0,1}
        pairs_in_post: set[Tuple[int, int]] = set()
        # E_p = { (min{π(t_{p,k}), π(t_{p,k+1})},
        #          max{π(t_{p,k}), π(t_{p,k+1})}) :
        #          1 ≤ k < L_p,  π(t_{p,k}) ≠ π(t_{p,k+1}) }
        # Unordered adjacent bigrams for post p.

        for k in range(L - 1):# loops over 1 ≤ k < L_p.
            i_id = token_ids[k] # use π(t_{p,k}) and π(t_{p,k+1}).
            j_id = token_ids[k + 1]
            if i_id == j_id:# enforces π(t_{p,k}) ≠ π(t_{p,k+1}).
                continue  # no self-pair here

            # unordered pair: (min, max)
            u, v = (i_id, j_id) if i_id < j_id else (j_id, i_id) # takes min(·), max(·) to make the pair unordered.
            pairs_in_post.add((u, v))# this constructs exactly the set E_p of unordered adjacent bigrams for post p.

        # For each unique (i,j) in this post, add w_p * s_i * s_j (eq.6 from paper (explain in docoumnet))
        for (u, v) in pairs_in_post:
            contrib = w_p * float(s[u]) * float(s[v])
            edge_weights[(u, v)] += contrib

    print(f"[Graph] Number of unique undirected edges (upper triangle): {len(edge_weights)}")

    if not edge_weights:
        raise ValueError("No edges were created in the keyword graph (edge_weights is empty).")

    # ------------------------------
    # Convert to symmetric adjacency matrix
    # ------------------------------

    # Graph G = ([V], E, W):
    #   E = { (i,j) : i < j and ω(i,j) > 0 }  — only store edges with positive weight.
    #   W ∈ ℝ⁺^{V×V} is the adjacency matrix:
    #       W[i,j] = ω(i,j) for i ≠ j,
    #       W[i,i] = 0.
    # edge_weights[(u,v)] is constructed only for u < v, matching the definition of E.

    rows: List[int] = []
    cols: List[int] = []
    data: List[float] = []

    for (u, v), w_uv in edge_weights.items():
        # upper and lower symmetric entries
        rows.append(u)
        cols.append(v)
        data.append(w_uv)

        if u != v:
            rows.append(v)
            cols.append(u)
            data.append(w_uv)

    adj_coo: coo_matrix = coo_matrix(
        (np.array(data, dtype=np.float32), (np.array(rows), np.array(cols))),
        shape=(vocab_size, vocab_size),
    )
    adj_csr: csr_matrix = adj_coo.tocsr()

    # Remove any self-loops (just in case)
    adj_csr.setdiag(0.0)
    adj_csr.eliminate_zeros()

    # Ensure output directory exists and save
    graph_path.parent.mkdir(parents=True, exist_ok=True)
    save_npz(graph_path, adj_csr)

    print(f"[Graph] Saved keyword graph adjacency to: {graph_path}")
    print(
        f"[Graph] Adjacency shape: {adj_csr.shape}, "
        f"nnz (non-zeros): {adj_csr.nnz}"
    )

    # Save simple metadata for inspection and experiments
    meta = {
        "vocab_size": int(vocab_size),
        "num_posts": int(num_posts),
        "num_edges_undirected": int(len(edge_weights)),
        "edge_type": "adjacent_bigrams",
        "use_post_weights": bool(use_post_weights),
        "use_salience": bool(use_salience),
        "graph_path": str(graph_path),
    }

    meta_path = graph_path.parent / "keyword_graph_meta.json"
    with meta_path.open("w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)

    print(f"[Graph] Saved graph metadata to: {meta_path}")
    print("[Graph] Keyword graph construction done.\n")
