# src/evaluation/topic_top_posts.py

from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, List, Any

import numpy as np
import pandas as pd

from src.data_pipeline.combine_cities import load_paths

logger = logging.getLogger(__name__)


def evaluate_top_posts_per_topic(
    paths_config: str = "configs/paths.yaml",
    top_n_posts: int = 5,
    top_m_words: int = 10,
) -> Dict[str, Any]:
    """
    Select representative posts for each topic based on the *dominant* topic
    activity per post.

    For each post p, we compute a topic-activity vector x_p ∈ R^K by pooling
    topic loadings U_word,: over its tokens (optionally scaled by influence
    weights if available). We then assign each post to its dominant topic:

        k*(p) = argmax_k x_p[k].

    For each topic k, we rank only those posts with k*(p) = k by x_p[k] and
    keep the top-N as representative examples.

    This avoids the situation where a single very strong post appears as the
    top example for many topics.
    """
    logger = logging.getLogger("evaluate_top_posts_per_topic")
    logger.info("Starting top-posts-per-topic evaluation ...")

    # --------------------------------------------------------------
    # 1) Load paths and core artifacts
    # --------------------------------------------------------------
    data_paths: Dict[str, str] = load_paths(paths_config)

    tokens_csv_path = Path(data_paths["tokens_dir"]) / "post_tokens.csv"
    if not tokens_csv_path.exists():
        raise FileNotFoundError(f"Tokenized posts not found: {tokens_csv_path}")

    weights_path = Path(data_paths["weights_array"])
    if not weights_path.exists():
        logger.warning(
            "Influence weights array not found at %s; proceeding with w_p = 1.",
            weights_path,
        )
        post_weights = None
    else:
        post_weights = np.load(weights_path).astype(np.float32)

    logger.info("Loading tokenized posts from: %s", tokens_csv_path)
    df_tokens = pd.read_csv(tokens_csv_path, encoding="utf-8-sig")

    required_cols = ["doc_index", "tokens"]
    for col in required_cols:
        if col not in df_tokens.columns:
            raise ValueError(
                f"Expected column '{col}' in post_tokens.csv but not found."
            )

    num_posts = df_tokens.shape[0]
    logger.info("Number of posts: %d", num_posts)

    if post_weights is not None and post_weights.shape[0] != num_posts:
        raise ValueError(
            f"Length of post weights ({post_weights.shape[0]}) does not match "
            f"number of posts ({num_posts})."
        )

    # --------------------------------------------------------------
    # 2) Load final U from model state directory
    # --------------------------------------------------------------
    state_dir = Path(data_paths["model_state_dir"])
    U_path = state_dir / "U_final.npy"
    if not U_path.exists():
        raise FileNotFoundError(f"Final U not found at: {U_path}")

    U = np.load(U_path)
    if U.ndim != 2:
        raise ValueError(f"U_final.npy must be 2D (V x K); got shape {U.shape}")

    V, K = U.shape
    logger.info("Loaded U with shape (V=%d, K=%d)", V, K)

    # --------------------------------------------------------------
    # 3) Build token -> vocab index mapping
    # --------------------------------------------------------------
    vocab_json_key = "vocab_json" if "vocab_json" in data_paths else "vocab_path"
    vocab_path = Path(data_paths[vocab_json_key])
    if not vocab_path.exists():
        raise FileNotFoundError(f"Vocab JSON not found at: {vocab_path}")

    import json

    with vocab_path.open("r", encoding="utf-8") as f:
        vocab_obj = json.load(f)
    token_to_id: Dict[str, int] = vocab_obj.get("token_to_id", {})
    id_to_token_list: List[str] = vocab_obj.get("id_to_token", [])
    if not token_to_id or not id_to_token_list:
        raise ValueError(
            f"Invalid vocab JSON at {vocab_path}: missing token_to_id/id_to_token."
        )

    # --------------------------------------------------------------
    # 4) Compute x_p for each post p (topic activity vector)
    # --------------------------------------------------------------
    X = np.zeros((num_posts, K), dtype=np.float32)

    skipped_empty = 0
    for idx, row in df_tokens.iterrows():
        tok_str = row["tokens"]
        if not isinstance(tok_str, str) or not tok_str.strip():
            skipped_empty += 1
            continue

        toks = tok_str.split()
        # map tokens to vocab indices, skip OOV
        word_ids = [token_to_id[t] for t in toks if t in token_to_id]
        if not word_ids:
            skipped_empty += 1
            continue

        # sum U[word_id,:] over all tokens in the post
        topic_vec = np.sum(U[word_ids, :], axis=0)  # (K,)

        # apply influence weight if available
        if post_weights is not None:
            w_p = float(post_weights[idx])
            topic_vec = w_p * topic_vec

        X[idx, :] = topic_vec

    logger.info(
        "Computed topic activity for all posts. Skipped %d empty/OOV posts.",
        skipped_empty,
    )

    # --------------------------------------------------------------
    # 5) Assign each post to its *dominant* topic
    # --------------------------------------------------------------
    dominant_topic = np.argmax(X, axis=1)  # shape (num_posts,)

    # --------------------------------------------------------------
    # 6) Rank posts within each dominant topic and select top-N
    # --------------------------------------------------------------
    rows_out: List[Dict[str, Any]] = []

    # optional extra columns if present
    extra_cols = []
    for extra in ["city", "博主id"]:
        if extra in df_tokens.columns:
            extra_cols.append(extra)

    for k in range(K):
        # posts where topic k is dominant
        mask_k = (dominant_topic == k)
        idx_k = np.where(mask_k)[0]

        if idx_k.size == 0:
            logger.warning("Topic %d has no dominant posts; skipping.", k)
            continue

        scores_k = X[idx_k, k]  # (num_posts_for_topic_k,)
        order = np.argsort(-scores_k)  # descending
        top_idx = idx_k[order[:top_n_posts]]

        for rank, p_idx in enumerate(top_idx, start=1):
            row_src = df_tokens.iloc[p_idx]
            row_out: Dict[str, Any] = {
                "topic_id": k,
                "rank": rank,
                "doc_index": int(row_src["doc_index"]),
                "score": float(X[p_idx, k]),
                "tokens": row_src["tokens"],
            }
            for extra in extra_cols:
                row_out[extra] = row_src[extra]
            rows_out.append(row_out)

        # Log one example for sanity check
        best_idx = top_idx[0]
        example_tokens = df_tokens.iloc[best_idx]["tokens"].split()
        example_preview = " ".join(example_tokens[:20])
        logger.info(
            "[TopPosts] Topic %2d | #dominant_posts=%d | top score=%.3f | example: %s...",
            k,
            idx_k.size,
            float(X[best_idx, k]),
            example_preview,
        )

    # --------------------------------------------------------------
    # 7) Save to CSV
    # --------------------------------------------------------------
    # Reuse the evaluation root directory
    data_paths = load_paths(paths_config)
    eval_root = Path(data_paths["topic_eval_overall_metrics"]).parent
    out_path = eval_root / f"topic_top_posts_per_topic_K{K}.csv"
    out_path.parent.mkdir(parents=True, exist_ok=True)

    df_out = pd.DataFrame(rows_out)
    df_out.to_csv(out_path, index=False, encoding="utf-8-sig")

    logger.info("Saved top-%d posts per topic to: %s", top_n_posts, out_path)

    summary = {
        "K": int(K),
        "num_topics_with_posts": int(len(set(df_out["topic_id"])) if not df_out.empty else 0),
        "num_posts": int(num_posts),
        "top_n_posts": int(top_n_posts),
    }
    logger.info("Top-posts-per-topic evaluation summary: %s", summary)

    return summary
