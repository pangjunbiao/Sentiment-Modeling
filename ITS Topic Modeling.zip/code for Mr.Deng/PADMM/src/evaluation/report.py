# src/evaluation/report.py

from __future__ import annotations

from pathlib import Path
from typing import List, Dict, Any

import numpy as np
import pandas as pd

from src.data_pipeline.combine_cities import load_paths
from src.evaluation.topics_io import (
    load_id2token,
    load_final_H,
    extract_top_words,
    load_docs_tokens,
)
from src.evaluation.coherence import compute_topic_coherence
from src.evaluation.diversity import compute_topic_diversity


def _add_suffix(path: Path, tag: str | None) -> Path:
    """
    If tag is not None, insert _{tag} before the extension.

    Example:
        path = full_model_overall_metrics.csv
        tag  = 'K10'
        -> full_model_overall_metrics_K10.csv
    """
    if tag is None:
        return path
    stem = path.stem      # e.g. full_model_overall_metrics
    suffix = path.suffix  # .csv
    return path.with_name(f"{stem}_{tag}{suffix}")


def evaluate_full_model(
    paths_config: str = "configs/paths.yaml",
    top_m: int = 10,
    tag: str | None = None,
) -> Dict[str, Any]:
    """
    Evaluate the trained full model (with H, gamma, weights, etc.)
    on topic-quality metrics:

      - Topic Coherence (NPMI)
      - Topic Coherence (C_v-style)
      - Topic Diversity (TD)

    Saves:
      - topic_eval_top_words:         top-m words per topic
      - topic_eval_topic_metrics:     per-topic NPMI / C_v
      - topic_eval_overall_metrics:   averages + TD

    If `tag` is not None (e.g. 'K10'), we append it to filenames:
      full_model_overall_metrics_K10.csv, etc.
    """
    # ------------------------------------------------------------------
    # 1) Resolve paths from config
    # ------------------------------------------------------------------
    data_paths = load_paths(paths_config)

    base_top_words = Path(data_paths["topic_eval_top_words"])
    base_topic_metrics = Path(data_paths["topic_eval_topic_metrics"])
    base_overall_metrics = Path(data_paths["topic_eval_overall_metrics"])

    top_words_csv = _add_suffix(base_top_words, tag)
    topic_metrics_csv = _add_suffix(base_topic_metrics, tag)
    overall_metrics_csv = _add_suffix(base_overall_metrics, tag)

    top_words_csv.parent.mkdir(parents=True, exist_ok=True)
    topic_metrics_csv.parent.mkdir(parents=True, exist_ok=True)
    overall_metrics_csv.parent.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # 2) Load vocab, final H, and tokenized documents
    # ------------------------------------------------------------------
    print("[Eval] Loading vocab (id2token)...")
    id2token: List[str] = load_id2token(paths_config=paths_config)

    print("[Eval] Loading final H from model state...")
    H = load_final_H(paths_config=paths_config)
    K, V = H.shape
    print(f"[Eval] H shape: (K={K}, V={V})")

    print("[Eval] Loading tokenized documents...")
    docs_tokens: List[List[str]] = load_docs_tokens(paths_config=paths_config)
    print(f"[Eval] Number of documents: {len(docs_tokens)}")

    # ------------------------------------------------------------------
    # 3) Extract top-m words per topic
    # ------------------------------------------------------------------
    print(f"[Eval] Extracting top-{top_m} words for each topic...")
    topic_word_indices, topic_word_tokens = extract_top_words(
        H, id2token, top_m=top_m
    )

    # ------------------------------------------------------------------
    # 4) Compute coherence metrics (NPMI, C_v)
    # ------------------------------------------------------------------
    print("[Eval] Computing topic coherence (NPMI, C_v)...")
    coh_results: Dict[str, Any] = compute_topic_coherence(
        topic_word_tokens=topic_word_tokens,
        docs_tokens=docs_tokens,
    )

    per_topic_npmi: List[float] = coh_results["per_topic_npmi"]
    per_topic_c_v: List[float] = coh_results["per_topic_c_v"]
    avg_npmi: float = coh_results["avg_npmi"]
    avg_c_v: float = coh_results["avg_c_v"]
    union_words: List[str] = coh_results["union_words"]

    # ------------------------------------------------------------------
    # 5) Compute topic diversity (TD)
    # ------------------------------------------------------------------
    print("[Eval] Computing topic diversity (TD)...")
    td_info: Dict[str, Any] = compute_topic_diversity(
        union_words=union_words,
        num_topics=K,
        top_m=top_m,
    )
    topic_diversity: float = td_info["topic_diversity"]

    # ------------------------------------------------------------------
    # 6) Save top words per topic
    # ------------------------------------------------------------------
    print(f"[Eval] Saving top words per topic to: {top_words_csv}")
    top_rows: List[Dict[str, Any]] = []
    for k, words in enumerate(topic_word_tokens):
        row: Dict[str, Any] = {"topic_id": k}
        for i, w in enumerate(words):
            row[f"word_{i+1}"] = w
        top_rows.append(row)

    df_top = pd.DataFrame(top_rows)
    df_top.to_csv(top_words_csv, index=False, encoding="utf-8-sig")

    # ------------------------------------------------------------------
    # 7) Save per-topic metrics
    # ------------------------------------------------------------------
    print(f"[Eval] Saving per-topic metrics to: {topic_metrics_csv}")
    df_metrics = pd.DataFrame(
        {
            "topic_id": list(range(K)),
            "npmi": per_topic_npmi,
            "c_v": per_topic_c_v,
        }
    )
    df_metrics.to_csv(topic_metrics_csv, index=False, encoding="utf-8-sig")

    # ------------------------------------------------------------------
    # 8) Save overall metrics (averages + TD)
    # ------------------------------------------------------------------
    print(f"[Eval] Saving overall metrics to: {overall_metrics_csv}")
    df_overall = pd.DataFrame(
        [
            {
                "avg_npmi": float(avg_npmi),
                "avg_c_v": float(avg_c_v),
                "topic_diversity": float(topic_diversity),
                "num_unique_words": int(td_info["num_unique_words"]),
                "num_topics": int(td_info["num_topics"]),
                "top_m": int(td_info["top_m"]),
            }
        ]
    )
    df_overall.to_csv(overall_metrics_csv, index=False, encoding="utf-8-sig")

    # ------------------------------------------------------------------
    # 9) Print summary for quick inspection
    # ------------------------------------------------------------------
    print("[Eval] ===== Topic Quality Summary (Full Model) =====")
    print(f"[Eval] Avg NPMI        : {avg_npmi:.4f}")
    print(f"[Eval] Avg C_v         : {avg_c_v:.4f}")
    print(f"[Eval] Topic Diversity : {topic_diversity:.4f}")
    print(f"[Eval] Num topics (K)  : {K}")
    print(f"[Eval] Top-m per topic : {top_m}")
    print("[Eval] ==============================================\n")

    # Return metrics so the sweep can log them if desired
    return {
        "avg_npmi": float(avg_npmi),
        "avg_c_v": float(avg_c_v),
        "topic_diversity": float(topic_diversity),
        "num_topics": int(K),
        "top_m": int(top_m),
    }
