# src/evaluation/topic_event_keywords.py

from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, List, Any

import numpy as np
import pandas as pd

from src.data_pipeline.combine_cities import load_paths

logger = logging.getLogger(__name__)


def _pick_latest_top_posts_csv(eval_root: Path) -> Path:
    """
    Find the most recent topic_top_posts_per_topic_K*.csv in eval_root.

    This lets you reuse the same code for K=10,15,20,30, etc.
    """
    candidates = list(eval_root.glob("topic_top_posts_per_topic_K*.csv"))
    if not candidates:
        raise FileNotFoundError(
            f"No topic_top_posts_per_topic_K*.csv found in {eval_root}. "
            f"Please run --stage eval_top_posts first."
        )
    # Pick the most recently modified file
    candidates.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return candidates[0]


def evaluate_topic_event_keywords(
    paths_config: str = "configs/paths.yaml",
    max_posts_per_topic: int = 5,
    top_m_keywords: int = 10,
) -> Dict[str, Any]:
    """
    Aggregate event-style keywords from the top posts per topic.

    Pipeline:
      1) Load data/processed/eval/topic_top_posts_per_topic_K*.csv
         (the most recent one).
      2) For each topic k, take up to `max_posts_per_topic` posts
         (rank 1..max_posts_per_topic).
      3) Collect all tokens from those posts.
      4) Remove a small Chinese stopword list and obvious noise tokens.
      5) Count token frequencies and keep top_m_keywords per topic.
      6) Save the resulting keywords to
         data/processed/eval/topic_event_keywords_K{K}.csv.

    The final CSV is meant for *paper-ready* tables, where you can manually
    translate or gloss the Chinese keywords into English.
    """
    logger_main = logging.getLogger("evaluate_topic_event_keywords")
    logger_main.info("Starting topic event-keyword aggregation ...")

    # --------------------------------------------------------------
    # 1) Resolve paths and locate the top-posts CSV
    # --------------------------------------------------------------
    data_paths: Dict[str, str] = load_paths(paths_config)
    eval_root = Path(data_paths["topic_eval_overall_metrics"]).parent
    eval_root.mkdir(parents=True, exist_ok=True)

    top_posts_csv = _pick_latest_top_posts_csv(eval_root)
    logger_main.info("Using top-posts CSV: %s", top_posts_csv)

    df = pd.read_csv(top_posts_csv, encoding="utf-8-sig")
    if "topic_id" not in df.columns or "tokens" not in df.columns:
        raise ValueError(
            f"{top_posts_csv} must contain 'topic_id' and 'tokens' columns."
        )
    if "rank" not in df.columns:
        # In principle we always write rank, but check to be safe
        logger_main.warning(
            "No 'rank' column in %s; assuming all rows are already top posts.",
            top_posts_csv,
        )
        df["rank"] = 1

    # Determine K from the data
    topic_ids = sorted(df["topic_id"].unique().tolist())
    K = len(topic_ids)
    logger_main.info("Found %d distinct topics in %s", K, top_posts_csv)

    # --------------------------------------------------------------
    # 2) Define a small Chinese stopword list and noise filters
    # --------------------------------------------------------------
    # This is a minimalist list just to remove obvious function words.
    # You can extend this manually if desired.
    chinese_stopwords = {
        "的", "了", "在", "是", "和", "也", "有", "就", "还",
        "都", "很", "又", "但", "一个", "这个", "那个",
        "我们", "你们", "他们", "自己",
        "啊", "呢", "吧", "吗", "呀", "哦",
    }

    def is_noise_token(tok: str) -> bool:
        # Remove empty tokens and pure punctuation
        if not tok:
            return True
        # crude check for punctuation-like tokens
        if all(ch in ".,!?;:，。！？；：…~～" for ch in tok):
            return True
        return False

    # --------------------------------------------------------------
    # 3) For each topic, gather tokens from top posts and count
    # --------------------------------------------------------------
    from collections import Counter

    rows_out: List[Dict[str, Any]] = []

    for k in topic_ids:
        df_k = df[df["topic_id"] == k].copy()

        # Restrict to top posts by rank
        df_k = df_k.sort_values(by="rank", ascending=True)
        df_k = df_k.head(max_posts_per_topic)

        if df_k.empty:
            logger_main.warning("Topic %d has no posts in %s; skipping.", k, top_posts_csv)
            continue

        counter = Counter()
        for _, row in df_k.iterrows():
            tok_str = row["tokens"]
            if not isinstance(tok_str, str) or not tok_str.strip():
                continue
            toks = tok_str.split()
            for tok in toks:
                if is_noise_token(tok):
                    continue
                if tok in chinese_stopwords:
                    continue
                counter[tok] += 1

        if not counter:
            logger_main.warning("Topic %d has no valid tokens after filtering; skipping.", k)
            continue

        # Take top-m keywords by frequency
        top_keywords = [w for (w, _) in counter.most_common(top_m_keywords)]
        # If fewer than top_m_keywords, pad with empty strings for a clean table
        if len(top_keywords) < top_m_keywords:
            top_keywords += [""] * (top_m_keywords - len(top_keywords))

        row_out: Dict[str, Any] = {"topic_id": int(k)}
        for i, w in enumerate(top_keywords, start=1):
            row_out[f"keyword_{i}"] = w
        rows_out.append(row_out)

        # Log an example preview
        preview = " ".join(top_keywords[:5])
        logger_main.info(
            "[EventKeywords] Topic %2d | #posts_used=%d | example keywords: %s",
            k,
            df_k.shape[0],
            preview,
        )

    # --------------------------------------------------------------
    # 4) Save result to CSV
    # --------------------------------------------------------------
    if not rows_out:
        raise RuntimeError("No topic produced any keywords. Check inputs and filters.")

    df_out = pd.DataFrame(rows_out)
    out_path = eval_root / f"topic_event_keywords_K{K}.csv"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    df_out.to_csv(out_path, index=False, encoding="utf-8-sig")

    logger_main.info(
        "Saved topic event keywords for K=%d (max_posts_per_topic=%d, top_m_keywords=%d) to: %s",
        K,
        max_posts_per_topic,
        top_m_keywords,
        out_path,
    )

    summary: Dict[str, Any] = {
        "K": int(K),
        "num_topics": int(len(df_out)),
        "max_posts_per_topic": int(max_posts_per_topic),
        "top_m_keywords": int(top_m_keywords),
        "csv_path": str(out_path),
    }
    logger_main.info("Topic event keyword evaluation summary: %s", summary)
    return summary
