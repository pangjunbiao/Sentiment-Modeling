# src/evaluation/topics_io.py

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Any, Tuple

import json
import numpy as np
import pandas as pd

from src.data_pipeline.combine_cities import load_paths


# ---------------------------------------------------------------------------
# Load vocab → id2token (ROBUST to different vocab.json formats)
# ---------------------------------------------------------------------------

def load_id2token(paths_config: str = "configs/paths.yaml") -> List[str]:
    """
    Load the vocabulary file (vocab.json) and return id2token list.

    Supported formats for vocab.json:

    1) {"token_to_id": {token: id, ...}}
       -> this is your current format

    2) {"id_to_token": {id: token, ...}}

    3) {token: id, ...}  (mapping directly at top level)

    4) ["token0", "token1", ...]  (list of tokens)

    Returns
    -------
    id2token : list of str
        id2token[i] = token with integer ID i.
    """
    data_paths = load_paths(paths_config)
    vocab_path = Path(data_paths["vocab_json"])

    if not vocab_path.exists():
        raise FileNotFoundError(f"vocab.json not found at: {vocab_path}")

    with vocab_path.open("r", encoding="utf-8") as f:
        obj = json.load(f)

    # Case 1: {"token_to_id": {...}}  <-- YOUR CURRENT FORMAT
    if isinstance(obj, dict) and "token_to_id" in obj:
        token_to_id = obj["token_to_id"]
        if not isinstance(token_to_id, dict):
            raise ValueError("vocab_json['token_to_id'] must be a dict.")

        int_ids = [v for v in token_to_id.values() if isinstance(v, int)]
        if not int_ids:
            raise ValueError("No integer IDs found in vocab_json['token_to_id'].")

        vocab_size = max(int_ids) + 1
        id2token: List[str] = [""] * vocab_size
        for token, tid in token_to_id.items():
            if not isinstance(tid, int):
                continue
            if 0 <= tid < vocab_size:
                id2token[tid] = token
        return id2token

    # Case 2: {"id_to_token": {...}}
    if isinstance(obj, dict) and "id_to_token" in obj:
        id_to_token = obj["id_to_token"]
        if not isinstance(id_to_token, dict):
            raise ValueError("vocab_json['id_to_token'] must be a dict.")

        int_ids: List[int] = []
        for k in id_to_token.keys():
            try:
                int_ids.append(int(k))
            except Exception:
                continue

        if not int_ids:
            raise ValueError("No integer IDs found in vocab_json['id_to_token'].")

        vocab_size = max(int_ids) + 1
        id2token: List[str] = [""] * vocab_size
        for k, token in id_to_token.items():
            try:
                tid = int(k)
            except Exception:
                continue
            if 0 <= tid < vocab_size:
                id2token[tid] = token
        return id2token

    # Case 3: {token: id, ...} at top level
    if isinstance(obj, dict):
        token_to_id = {k: v for k, v in obj.items() if isinstance(v, int)}
        if token_to_id:
            int_ids = list(token_to_id.values())
            vocab_size = max(int_ids) + 1
            id2token: List[str] = [""] * vocab_size
            for token, tid in token_to_id.items():
                if 0 <= tid < vocab_size:
                    id2token[tid] = token
            return id2token

    # Case 4: ["token0", "token1", ...]
    if isinstance(obj, list) and all(isinstance(t, str) for t in obj):
        # assume index = id
        return list(obj)

    # If we reach here, we couldn't interpret the structure
    raise ValueError(
        f"Could not interpret vocab.json structure at {vocab_path}. "
        f"Expected one of: "
        f"{{'token_to_id': {{...}}}}, "
        f"{{'id_to_token': {{...}}}}, "
        f"{{token: id, ...}}, or [token0, token1, ...]."
    )


# ---------------------------------------------------------------------------
# Load final H from saved model state
# ---------------------------------------------------------------------------

def load_final_H(paths_config: str = "configs/paths.yaml") -> np.ndarray:
    """
    Load the final topic-word matrix H from the saved model state directory.

    Priority:
      1) If H_final.npy exists, use that.
      2) Otherwise, look for per-iteration checkpoints with either:
         - "H_iter_XXXX.npy"  (new trainer naming)
         - "iter_XXXX_H.npy"  (older naming)
         and pick the largest XXXX.

    IMPORTANT: Internally the trainer saves H as shape (V, K) = (vocab_size, num_topics).
    For evaluation we want H_eval to have shape (K, V) so that rows index topics.
    So if we detect H is (V, K) with V >> K, we transpose before returning.
    """
    data_paths = load_paths(paths_config)
    state_dir = Path(data_paths["model_state_dir"])

    if not state_dir.exists():
        raise FileNotFoundError(f"Model state directory not found: {state_dir}")

    # 1) Prefer H_final.npy
    h_final_path = state_dir / "H_final.npy"
    candidates: List[Tuple[int, Path]] = []

    if h_final_path.exists():
        candidates.append((10**9, h_final_path))  # big "iteration" so it always wins

    # 2) Also gather per-iteration candidates from both naming styles

    # New naming: H_iter_XXXX.npy
    for p in state_dir.glob("H_iter_*.npy"):
        # e.g. "H_iter_0010" -> ["H", "iter", "0010"]
        stem = p.stem
        parts = stem.split("_")
        if len(parts) >= 3 and parts[1] == "iter":
            try:
                iter_num = int(parts[2])
            except ValueError:
                continue
            candidates.append((iter_num, p))

    # Old naming: iter_XXXX_H.npy
    for p in state_dir.glob("iter_*_H.npy"):
        # e.g. "iter_0010_H" -> ["iter", "0010", "H"]
        stem = p.stem
        parts = stem.split("_")
        if len(parts) >= 3 and parts[0] == "iter":
            try:
                iter_num = int(parts[1])
            except ValueError:
                continue
            candidates.append((iter_num, p))

    if not candidates:
        raise FileNotFoundError(
            f"No H_final.npy, and no per-iteration H files found in state dir: {state_dir}"
        )

    # Pick the highest "iteration" (H_final wins because we gave it 10**9)
    candidates.sort(key=lambda x: x[0])
    latest_iter, latest_path = candidates[-1]

    if latest_path.name == "H_final.npy":
        print(f"[Eval] Using final H at: {latest_path}")
    else:
        print(f"[Eval] Using H from iteration {latest_iter} at: {latest_path}")

    H_raw = np.load(latest_path)

    # --- Shape fix: trainer saves H as (V, K); evaluation wants (K, V) ---
    # Heuristic: If first dimension is much larger than second, assume (V, K) and transpose.
    if H_raw.shape[0] > H_raw.shape[1]:
        H = H_raw.T
    else:
        H = H_raw

    # Now H should be (K, V) where rows = topics, cols = vocab terms
    return H


# ---------------------------------------------------------------------------
# Extract top-m words per topic from H
# ---------------------------------------------------------------------------

def extract_top_words(
    H: np.ndarray,
    id2token: List[str],
    top_m: int = 10,
):
    """
    Given H (K x V) and id2token, extract top-m words per topic.

    Returns:
        topic_word_indices: List[List[int]]  (K lists of indices)
        topic_word_tokens:  List[List[str]]  (K lists of tokens)
    """
    K, V = H.shape
    topic_word_indices: List[List[int]] = []
    topic_word_tokens: List[List[str]] = []

    for k in range(K):
        row = H[k, :]
        # largest top_m entries
        top_idx = np.argsort(-row)[:top_m]  # descending
        topic_word_indices.append(top_idx.tolist())
        topic_word_tokens.append([id2token[j] for j in top_idx])

    return topic_word_indices, topic_word_tokens


# ---------------------------------------------------------------------------
# Load tokenized documents (for coherence computation)
# ---------------------------------------------------------------------------

def load_docs_tokens(paths_config: str = "configs/paths.yaml") -> List[List[str]]:
    """
    Load the tokenized posts CSV and return a list of token lists.

    We assume a CSV like:
        doc_index, city, 博主id, tokens

    where 'tokens' is a space-separated string of tokens.
    """
    data_paths = load_paths(paths_config)
    token_csv = Path(data_paths["tokenized_posts"])

    if not token_csv.exists():
        raise FileNotFoundError(f"Tokenized posts CSV not found: {token_csv}")

    df = pd.read_csv(token_csv, encoding="utf-8-sig")
    if "tokens" not in df.columns:
        raise ValueError(f"'tokens' column not found in: {token_csv}")

    docs_tokens: List[List[str]] = []
    for s in df["tokens"]:
        if isinstance(s, str):
            docs_tokens.append(s.split())
        else:
            docs_tokens.append([])

    return docs_tokens
