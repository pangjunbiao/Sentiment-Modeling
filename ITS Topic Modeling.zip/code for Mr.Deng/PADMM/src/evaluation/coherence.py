# src/evaluation/coherence.py

from __future__ import annotations

from typing import Dict, List, Tuple

import numpy as np


def _build_cooccurrence_counts(
    docs_tokens: List[List[str]],
    union_words: List[str],
) -> Tuple[np.ndarray, Dict[Tuple[int, int], int], int]:
    """
    Build document-frequency and co-occurrence counts restricted
    to the union of all topic words.

    Returns:
        df_counts : shape (M,), doc frequency for each union word
        cooc_counts : dict[(i,j)] -> doc co-occurrence count
        N_docs : number of documents
    """
    word2small = {w: i for i, w in enumerate(union_words)}
    M = len(union_words)

    df_counts = np.zeros(M, dtype=np.int64)
    cooc_counts: Dict[Tuple[int, int], int] = {}
    N_docs = len(docs_tokens)

    for tokens in docs_tokens:
        # keep only words in union_words, then unique them
        unique_words = sorted({w for w in tokens if w in word2small})
        if not unique_words:
            continue

        ids = [word2small[w] for w in unique_words]

        # document frequency
        for idx in ids:
            df_counts[idx] += 1

        # co-occurrence (unordered pairs)
        for a in range(len(ids)):
            i = ids[a]
            for b in range(a + 1, len(ids)):
                j = ids[b]
                if i > j:
                    i, j = j, i
                key = (i, j)
                cooc_counts[key] = cooc_counts.get(key, 0) + 1

    return df_counts, cooc_counts, N_docs


def _compute_topic_npmi_and_cv(
    topic_tokens: List[str],
    union_words: List[str],
    df_counts: np.ndarray,
    cooc_counts: Dict[Tuple[int, int], int],
    N_docs: int,
) -> Tuple[float, float]:
    """
    Compute NPMI and a C_v-style coherence for a single topic.

    - NPMI: average normalized PMI over word pairs from topic_tokens.
    - C_v (approx): average cosine similarity between NPMI-based
      context vectors, following the spirit of Röder et al. (2015).

    Returns:
        (avg_npmi, avg_c_v)
    """
    eps = 1e-12
    if N_docs == 0:
        return 0.0, 0.0

    word2small = {w: i for i, w in enumerate(union_words)}
    ids = [word2small[w] for w in topic_tokens if w in word2small]
    m = len(ids)
    if m < 2:
        return 0.0, 0.0

    npmi_mat = np.zeros((m, m), dtype=float)
    npmi_sum = 0.0
    pair_count = 0

    # probabilities
    p = df_counts / float(N_docs)

    for a in range(m):
        i = ids[a]
        p_i = max(p[i], eps)
        for b in range(a + 1, m):
            j = ids[b]
            p_j = max(p[j], eps)

            key = (min(i, j), max(i, j))
            df_ij = cooc_counts.get(key, 0)
            if df_ij == 0:
                continue

            p_ij = max(df_ij / float(N_docs), eps)

            pmi = np.log(p_ij / (p_i * p_j))
            npmi = pmi / (-np.log(p_ij))

            npmi_sum += npmi
            pair_count += 1

            # For C_v we emphasise *positive* association:
            val = max(npmi, 0.0)
            npmi_mat[a, b] = val
            npmi_mat[b, a] = val

    avg_npmi = npmi_sum / pair_count if pair_count > 0 else 0.0

    # If there was no co-occurrence, C_v is 0
    if pair_count == 0:
        return avg_npmi, 0.0

    # C_v-like: cosine between word context vectors
    norms = np.linalg.norm(npmi_mat, axis=1)
    cv_sum = 0.0
    cv_pairs = 0

    for a in range(m):
        for b in range(a + 1, m):
            if norms[a] < eps or norms[b] < eps:
                continue
            cos_sim = float(
                np.dot(npmi_mat[a], npmi_mat[b]) / (norms[a] * norms[b])
            )
            cv_sum += cos_sim
            cv_pairs += 1

    avg_cv = cv_sum / cv_pairs if cv_pairs > 0 else 0.0
    return avg_npmi, avg_cv


def compute_topic_coherence(
    topic_word_tokens: List[List[str]],
    docs_tokens: List[List[str]],
) -> Dict[str, object]:
    """
    High-level entry point: compute coherence metrics (NPMI, C_v)
    for a *set* of topics.

    Args:
        topic_word_tokens: list of topics; each topic is a list of its top-m tokens.
        docs_tokens: list of documents; each document is a list of tokens.

    Returns:
        {
            "per_topic_npmi": [float] * K,
            "per_topic_c_v": [float] * K,
            "avg_npmi": float,
            "avg_c_v": float,
            "union_words": List[str],   # union of all topic words (for TD, etc.)
        }
    """
    # union of all words appearing in any topic
    union_words = sorted({w for topic in topic_word_tokens for w in topic})

    if len(union_words) == 0 or len(docs_tokens) == 0:
        return {
            "per_topic_npmi": [0.0 for _ in topic_word_tokens],
            "per_topic_c_v": [0.0 for _ in topic_word_tokens],
            "avg_npmi": 0.0,
            "avg_c_v": 0.0,
            "union_words": [],
        }

    df_counts, cooc_counts, N_docs = _build_cooccurrence_counts(
        docs_tokens, union_words
    )

    per_topic_npmi: List[float] = []
    per_topic_cv: List[float] = []

    for words in topic_word_tokens:
        npmi_k, cv_k = _compute_topic_npmi_and_cv(
            words, union_words, df_counts, cooc_counts, N_docs
        )
        per_topic_npmi.append(npmi_k)
        per_topic_cv.append(cv_k)

    avg_npmi = float(np.mean(per_topic_npmi)) if per_topic_npmi else 0.0
    avg_c_v = float(np.mean(per_topic_cv)) if per_topic_cv else 0.0

    return {
        "per_topic_npmi": per_topic_npmi,
        "per_topic_c_v": per_topic_cv,
        "avg_npmi": avg_npmi,
        "avg_c_v": avg_c_v,
        "union_words": union_words,
    }
