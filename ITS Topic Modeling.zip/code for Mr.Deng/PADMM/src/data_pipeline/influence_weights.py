# src/data_pipeline/influence_weights.py

from __future__ import annotations

import ast
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd

from src.data_pipeline.combine_cities import load_paths


def _parse_comment_time_list(raw_value) -> List[pd.Timestamp]:
    """
    Parse the '评论时间列表' field into a list of pandas Timestamps.

    The raw format is typically a Python list-like string, e.g.:
        "['2019-10-25 17:30:22', '2019-10-25 18:31:10']"
    but may also be "[]", "[no]", or NaN.

    We:
    - Safely literal_eval if it looks like a list.
    - Convert each element to a Timestamp (dropping invalid ones).
    - Return a sorted list of timestamps.
    """
    if pd.isna(raw_value):
        return []

    s = str(raw_value).strip()
    if not s or s in ("[]", "[no]", "nan", "NaN", "None"):
        return []

    if s.startswith("[") and s.endswith("]"):
        try:
            obj = ast.literal_eval(s)
        except Exception:
            return []

        if not isinstance(obj, list):
            return []

        times: List[pd.Timestamp] = []
        for item in obj:
            ts = pd.to_datetime(item, errors="coerce")
            if not pd.isna(ts):
                times.append(ts)

        times.sort()
        return times

    # If not a list-like string, try to parse as a single timestamp
    ts_single = pd.to_datetime(s, errors="coerce")
    if pd.isna(ts_single):
        return []
    return [ts_single]


# ---------------------------------------------------------------------
# 1) iTF_p : engagement per reach (paper-style, r_p = 0)
#     iTF_p = (c_p + l_p) / (F_p + eps_f)
# ---------------------------------------------------------------------
def _compute_itf(
    likes: float,
    comments: float,
    followers: float,
    use_log_scale: bool = True,  # kept for backward compatibility, ignored
) -> float:
    """
    Compute interaction-based term frequency (iTF) for a post.

    Paper-style implementation (with r_p = 0):

        iTF_p = (c_p + l_p) / (F_p + eps_f),

    where:
      - c_p: comments
      - l_p: likes
      - F_p: followers
      - eps_f > 0: small constant for numerical stability.

    We do NOT apply log here so that the code matches the paper formula.
    """
    c_p = max(comments, 0.0)
    l_p = max(likes, 0.0)
    F_p = max(followers, 0.0)

    eps_f = 1.0  # ε_f in the paper (can be tuned if needed)
    numerator = c_p + l_p
    denominator = F_p + eps_f

    itf_raw = numerator / denominator if denominator > 0.0 else 0.0
    return float(itf_raw)


# ---------------------------------------------------------------------
# 2) iIDF_p : burstiness / arrival rate (piecewise, per paper)
#
# For T_p comments and inter-comment gaps Δτ_{p,j} in hours:
#
#   T_p = number of comments
#   gaps = Δτ_{p,j} for j = 1,...,T_p-1
#
#   If T_p >= 3:
#       iIDF_p = log( 1 + T_p * (sum_j gaps_j / τ_0) )
#
#   If T_p < 3:
#       iIDF_p = log( 1 + T_p * (max_j gaps_j / τ_0) )
#
# If there are no valid gaps, we fall back to a default gap τ_0.
# ---------------------------------------------------------------------
def _compute_burstiness_iidf(
    comment_times: List[pd.Timestamp],
    tau_default_hours: float = 24.0,
    min_comments_for_burstiness: int = 2,  # kept for signature compatibility
) -> float:
    """
    Compute burstiness-based iIDF_p according to the paper's piecewise definition.

    - comment_times: sorted list of timestamps of comments for a post.
    - tau_default_hours: τ_0, reference time scale in hours.
    """
    T_p = len(comment_times)
    tau0 = float(tau_default_hours)

    # No comments: no burstiness information
    if T_p == 0:
        return 0.0

    # Compute inter-comment gaps Δτ_{p,j} in hours
    gaps: List[float] = []
    for t_prev, t_next in zip(comment_times[:-1], comment_times[1:]):
        delta_hours = (t_next - t_prev).total_seconds() / 3600.0
        if delta_hours > 0:
            gaps.append(delta_hours)

    # If there are no positive gaps (e.g., only one comment or same timestamps),
    # fall back to using τ_0 as a default gap.
    if not gaps:
        default_gap = tau0
        if T_p >= 3:
            # sum of (T_p - 1) identical gaps
            gap_sum = float(max(T_p - 1, 1) * default_gap)
            return float(np.log(1.0 + T_p * (gap_sum / tau0)))
        else:
            # T_p < 3 branch uses max gap
            max_gap = float(default_gap)
            return float(np.log(1.0 + T_p * (max_gap / tau0)))

    # Now we have at least one positive gap
    if T_p >= 3:
        gap_sum = float(np.sum(gaps))
        return float(np.log(1.0 + T_p * (gap_sum / tau0)))
    else:
        max_gap = float(np.max(gaps))
        return float(np.log(1.0 + T_p * (max_gap / tau0)))


# ---------------------------------------------------------------------
# Helper: mean inter-comment gap \bar{Δτ}_p for HN-like decay
#   \bar{Δτ}_p = (1 / max{1, T_p - 1}) * sum_j Δτ_{p,j}
# ---------------------------------------------------------------------
def _compute_mean_gap_hours(
    comment_times: List[pd.Timestamp],
    tau_default_hours: float = 24.0,
) -> float:
    """
    Compute the mean inter-comment gap in hours:

        mean_gap = (1 / max{1, T_p - 1}) * sum_j Δτ_{p,j}.

    If there are no gaps, return tau_default_hours as a neutral default.
    """
    T_p = len(comment_times)
    if T_p <= 1:
        return float(tau_default_hours)

    gaps: List[float] = []
    for t_prev, t_next in zip(comment_times[:-1], comment_times[1:]):
        delta_hours = (t_next - t_prev).total_seconds() / 3600.0
        if delta_hours > 0:
            gaps.append(delta_hours)

    if not gaps:
        return float(tau_default_hours)

    gap_sum = float(np.sum(gaps))
    denom = max(1, T_p - 1)
    return gap_sum / denom


# ---------------------------------------------------------------------
# Legacy age-based time decay (no longer used in the main formula,
# but kept for compatibility in case other code imports it).
# ---------------------------------------------------------------------
def _compute_time_decay(
    post_time: pd.Timestamp,
    dataset_max_time: pd.Timestamp,
    lambda_per_day: float = 0.05,
    use_time_decay: bool = True,
) -> float:
    """
    Legacy age-based distance-decay factor based on post age.

    Currently not used in the main w_p formula (which follows the
    Hacker-News-style gap-based decay), but kept for backward compatibility.
    """
    if (not use_time_decay) or pd.isna(post_time) or pd.isna(dataset_max_time):
        return 1.0

    age_days = (dataset_max_time - post_time).total_seconds() / (3600.0 * 24.0)
    if age_days < 0:
        age_days = 0.0

    decay = float(np.exp(-lambda_per_day * age_days))
    return decay


def compute_and_save_influence_weights(
    paths_config: str = "configs/paths.yaml",
    use_log_itf: bool = True,          # kept in signature; no log is applied in _compute_itf
    tau_default_hours: float = 24.0,   # τ_0 in the paper
    min_comments_for_burstiness: int = 2,
    lambda_per_day: float = 0.05,      # kept for compatibility; not used in new decay
    use_time_decay: bool = True,
) -> None:
    """
    High-level function to compute influence weights w_p for each post.

    Paper-style steps:
    1. iTF_p  = (c_p + l_p) / (F_p + ε_f)
    2. iIDF_p = piecewise log(1 + T_p * (gap-sum or gap-max)/τ_0)
    3. Y_p    = iTF_p * iIDF_p
    4. time_decay_p = 1 / ((mean_gap_p / τ_0 + 2)^g)   (Hacker-News-style)
       with g = 1.5
    5. \hat{w}_p = Y_p * time_decay_p
    6. w_p       = \hat{w}_p / max_q \hat{w}_q

    Outputs:
      - NumPy array of w_p aligned with DataFrame rows (weights_array.npy)
      - CSV with columns (..., iTF, iIDF, time_decay, w_p)
    """
    data_paths: Dict[str, str] = load_paths(paths_config)

    clean_path = Path(data_paths["clean_combined"])
    if not clean_path.exists():
        raise FileNotFoundError(
            f"Cleaned combined file not found: {clean_path}. "
            f"Run the 'preprocess' stage first."
        )

    print(f"[Influence] Loading cleaned data from: {clean_path}")
    df = pd.read_csv(clean_path, encoding="utf-8-sig")

    # Ensure 发布时间 is datetime
    if "发布时间" in df.columns:
        df["发布时间"] = pd.to_datetime(df["发布时间"], errors="coerce")
        dataset_max_time = df["发布时间"].max()
    else:
        dataset_max_time = pd.NaT  # kept for compatibility, unused in new decay

    # Prepare containers
    itf_list: List[float] = []
    iidf_list: List[float] = []
    decay_list: List[float] = []
    w_hat_list: List[float] = []  # unnormalized \hat{w}_p

    print("[Influence] Computing iTF, iIDF, and time decay for each post...")

    # Hyperparameter for Hacker-News-style decay
    g = 1.5  # as in the paper

    for idx, row in df.iterrows():
        likes = float(row.get("点赞", 0.0) or 0.0)
        comments = float(row.get("评论数", 0.0) or 0.0)
        followers = float(row.get("粉丝数", 0.0) or 0.0)

        # 1) iTF_p
        itf = _compute_itf(
            likes=likes,
            comments=comments,
            followers=followers,
            use_log_scale=use_log_itf,
        )

        # 2) iIDF_p
        comment_times = _parse_comment_time_list(row.get("评论时间列表", "[]"))
        iidf = _compute_burstiness_iidf(
            comment_times=comment_times,
            tau_default_hours=tau_default_hours,
            min_comments_for_burstiness=min_comments_for_burstiness,
        )

        # 3) mean gap and Hacker-News-style time decay
        mean_gap = _compute_mean_gap_hours(
            comment_times=comment_times,
            tau_default_hours=tau_default_hours,
        )

        if use_time_decay:
            denom = (mean_gap / float(tau_default_hours)) + 2.0
            time_decay = float(1.0 / (denom ** g))
        else:
            time_decay = 1.0

        # 4) \hat{w}_p = Y_p * time_decay = iTF_p * iIDF_p * time_decay
        w_hat_p = itf * iidf * time_decay

        itf_list.append(itf)
        iidf_list.append(iidf)
        decay_list.append(time_decay)
        w_hat_list.append(w_hat_p)

    # Convert to array and normalize: w_p = \hat{w}_p / max_q \hat{w}_q
    weights_array = np.array(w_hat_list, dtype=np.float32)
    max_w = float(weights_array.max()) if weights_array.size > 0 else 0.0
    if max_w > 0.0:
        weights_array = weights_array / max_w
        w_list = weights_array.tolist()
    else:
        # All zero or empty; keep zeros
        w_list = weights_array.tolist()

    # Attach components back to a DataFrame for CSV export
    df_weights = pd.DataFrame(
        {
            "city": df.get("city", pd.Series([""] * len(df))),
            "序号": df.get("序号", pd.Series([0] * len(df))),
            "博主id": df.get("博主id", pd.Series([""] * len(df))),
            "发布时间": df.get("发布时间", pd.Series([pd.NaT] * len(df))),
            "粉丝数": df.get("粉丝数", pd.Series([0] * len(df))),
            "点赞": df.get("点赞", pd.Series([0] * len(df))),
            "评论数": df.get("评论数", pd.Series([0] * len(df))),
            "iTF": itf_list,
            "iIDF": iidf_list,
            "time_decay": decay_list,
            "w_p": w_list,
        }
    )

    # Save outputs
    weights_array_path = Path(data_paths["weights_array"])
    weights_array_path.parent.mkdir(parents=True, exist_ok=True)
    np.save(weights_array_path, weights_array)

    weights_csv_path = Path(data_paths["weights_csv"])
    weights_csv_path.parent.mkdir(parents=True, exist_ok=True)
    df_weights.to_csv(weights_csv_path, index=False, encoding="utf-8-sig")

    print(
        f"[Influence] Saved influence weights array to: {weights_array_path} "
        f"(shape: {weights_array.shape})"
    )
    print(
        f"[Influence] Saved detailed weights CSV to: {weights_csv_path} "
        f"(rows: {df_weights.shape[0]}, columns: {df_weights.shape[1]})"
    )
    print("[Influence] Done.\n")
