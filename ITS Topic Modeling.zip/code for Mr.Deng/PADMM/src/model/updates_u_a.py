# src/model/updates_u_a.py
from __future__ import annotations

import logging
from typing import Dict, Any

import numpy as np
from scipy.sparse import csr_matrix

from src.model.poisson_topic_model import PoissonTopicModel

logger = logging.getLogger(__name__)


# ======================================================================
# Compute λS, λL, λR, θ_ij for a pair (i, j)
# ======================================================================

def _compute_theta_ij(
    u_i: np.ndarray,
    u_j: np.ndarray,
    h_i: np.ndarray,
    h_j: np.ndarray,
    a: np.ndarray,
    eps: float,
):
    """
    For one edge (i,j), compute:
        λ_S(k) = a_k * u_ik * u_jk
        λ_L(k) = u_ik * h_jk
        λ_R(k) = h_ik * u_jk

    θ_ij = sum_k (λ_S + λ_L + λ_R) + eps
    """
    lambda_S = a * (u_i * u_j)
    lambda_L = u_i * h_j
    lambda_R = h_i * u_j

    theta_ij = float(np.sum(lambda_S + lambda_L + lambda_R) + eps)
    return lambda_S, lambda_L, lambda_R, theta_ij


# ======================================================================
# Majorization–Minimization update for (U, A)
# ======================================================================

def pdf_mm_update_UA(
    model: PoissonTopicModel,
    num_inner_iters: int,
    u_decor_lr: float,
) -> None:
    """
    MM updates for U and A consistent with the PDF formulation.

    Steps:
    (1) Responsibilities:
            P^S = λS / θ
            P^L = λL / θ
            P^R = λR / θ

    (2) A update:
            a_k ← a_k * ( Σ W_ij P^S ) / ( Σ u_ik u_jk )

    (3) U update:
            U_{ik} ← U_{ik} * Numer_{ik} / Denom_{ik}

    (4) Normalize columns & compensate a

    (5) Optional decorrelation gradient:
            U ← U − lr * γ * ∂R/∂U
    """
    if not isinstance(model.W, csr_matrix):
        raise ValueError("model.W must be a csr_matrix.")

    if model.U is None or model.H is None or model.a is None:
        raise ValueError("U, H, a must be initialized.")

    W = model.W.tocoo()
    U = model.U
    H = model.H
    a = model.a

    eps = float(model.config.epsilon)
    gamma_u = float(getattr(model.config, "gamma", 0.0))

    V, K = U.shape

    # ===============================================================
    # Outer MM Loop
    # ===============================================================
    for it in range(num_inner_iters):

        num_a = np.zeros(K)
        num_U = np.zeros((V, K))

        # Denominator for A update:
        sumU = U.sum(axis=0)
        sumU2 = (U * U).sum(axis=0)
        denom_a = 0.5 * (sumU**2 - sumU2)
        denom_a = np.maximum(denom_a, eps)

        # ----------------------------------------------------------
        # Loop over edges (i < j).....Nominator for update A
        # ----------------------------------------------------------
        rows, cols, data = W.row, W.col, W.data
        for idx in range(len(data)):
            i = int(rows[idx])
            j = int(cols[idx])

            if i >= j:
                continue

            w_ij = float(data[idx])
            if w_ij <= 0:
                continue

            u_i = U[i]
            u_j = U[j]
            h_i = H[i]
            h_j = H[j]

            λS, λL, λR, θ = _compute_theta_ij(u_i, u_j, h_i, h_j, a, eps)
            θ = max(θ, eps)

            # Responsibilities according to paper and P is created here for A Nominator
            P_S = λS / θ
            P_L = λL / θ
            P_R = λR / θ

            # A numerator
            num_a += w_ij * P_S

            # U numerators
            num_U[i] += w_ij * (P_S + P_L)
            num_U[j] += w_ij * (P_S + P_R)

        # ----------------------------------------------------------
        # A update complete with Nominator and denominator
        # ----------------------------------------------------------
        num_a = np.maximum(num_a, eps)
        a = a * (num_a / denom_a)
        a = np.maximum(a, eps)

        # ----------------------------------------------------------
        # U update complete (u dominator as well)
        # ----------------------------------------------------------
        sumU = U.sum(axis=0)
        sumH = H.sum(axis=0)
        sum_aU = a * sumU

        denom_U = np.empty((V, K))
        for k in range(K):
            denom_U[:, k] = (sum_aU[k] - a[k] * U[:, k]) + (sumH[k] - H[:, k])

        denom_U = np.maximum(denom_U, eps)
        num_U = np.maximum(num_U, eps)

        U = U * (num_U / denom_U)
        U = np.maximum(U, eps)

        # ----------------------------------------------------------
        # Normalize columns & compensate a
        # ----------------------------------------------------------
        col_sums = U.sum(axis=0)
        col_sums = np.maximum(col_sums, eps)

        U = U / col_sums
        a = a * (col_sums**2)
        a = np.maximum(a, eps)

        # ----------------------------------------------------------
        # OPTIONAL: Decorrelate U if gamma > 0
        # ----------------------------------------------------------
        if gamma_u > 0 and u_decor_lr > 0:
            G = U.T @ U
            G_off = G - np.diag(np.diag(G))
            grad_R = 4 * (U @ G_off)

            U = U - u_decor_lr * gamma_u * grad_R
            U = np.maximum(U, eps)

            # Renormalize after decorrelation
            col_sums = U.sum(axis=0)
            col_sums = np.maximum(col_sums, eps)
            U = U / col_sums
            a = a * (col_sums**2)
            a = np.maximum(a, eps)

    # Save final values
    model.U = U
    model.a = a


# ======================================================================
# Wrapper
# ======================================================================

def u_update_step(model: PoissonTopicModel, training_cfg: Dict[str, Any]) -> None:
    """
    Wrapper for MM updates of (U, A)
    """

    raw_iters = training_cfg.get("u_mm_inner_iters",
                                 training_cfg.get("ua_mm_inner_iters", 1))

    if isinstance(raw_iters, dict):
        raw_iters = raw_iters.get("num_inner_iters", 1)

    num_inner_iters = int(raw_iters)
    u_decor_lr = float(training_cfg.get("u_decor_lr", 1e-2))

    logger.info(f"PDF-MM update: inner_iters={num_inner_iters}, decor_lr={u_decor_lr}")

    pdf_mm_update_UA(
        model=model,
        num_inner_iters=num_inner_iters,
        u_decor_lr=u_decor_lr,
    )
