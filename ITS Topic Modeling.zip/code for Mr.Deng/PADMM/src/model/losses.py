# src/model/losses.py
from __future__ import annotations

import logging
from typing import Dict, Any

import numpy as np
from scipy.sparse import csr_matrix

from src.model.poisson_topic_model import PoissonTopicModel

logger = logging.getLogger(__name__)


# -----------------------------------------------------------
# Data Term (PDF Poisson Edge Likelihood)
# -----------------------------------------------------------

def data_term(model: PoissonTopicModel) -> float:
    """
    Correct PDF data-fidelity term:

        L = sum_{i<j} [ Θ_ij – W_ij * log(Θ_ij) ]

    All weighting (influence, decay, salience) is already baked into W
    during the graph construction stage. No extra weighting should
    appear here.
    """

    if model.U is None or model.H is None or model.a is None:
        raise ValueError("U, H, a must be initialized")

    # Make sure upper-triangle cache is ready
    if model._upper_i is None or model._upper_j is None or model._upper_w is None:
        model._prepare_upper_triangle_cache()

    # Compute Theta from model (same as methodology)
    Theta = model.compute_theta()   # (V, V)

    # Cached upper-triangle entries of W
    i_idx = model._upper_i
    j_idx = model._upper_j
    w_vals = model._upper_w

    eps = float(model.config.epsilon)

    # ---- sum_{i<j} Θ_ij ----
    total_sum = float(Theta.sum())
    diag_sum = float(np.trace(Theta))
    theta_offdiag_sum = 0.5 * (total_sum - diag_sum)

    # ---- KL term: sum_{i<j} W_ij log Θ_ij ----
    theta_vals = Theta[i_idx, j_idx]
    log_theta = np.log(theta_vals + eps)
    kl_term = float(np.sum(w_vals * log_theta))

    # final PDF loss
    return float(theta_offdiag_sum - kl_term)


# -----------------------------------------------------------
# U Regularizer
# -----------------------------------------------------------

def u_reg_term(model: PoissonTopicModel) -> float:
    lam_u = float(getattr(model.config, "lambda_u", 0.0))
    if lam_u <= 0:
        return 0.0
    if model.U is None:
        raise ValueError("U must be initialized for u_reg_term.")
    return float(lam_u * np.sum(model.U ** 2))


# -----------------------------------------------------------
# H L1 Sparsity # So this is exactly $\lambda_H \|H\|_1$.
# # And compute_loss_components adds it into the total loss:
# -----------------------------------------------------------

def h_l1_term(model: PoissonTopicModel) -> float:
    lam_h = float(getattr(model.config, "lambda_h", 0.0))
    if lam_h <= 0:
        return 0.0
    if model.H is None:
        raise ValueError("H must be initialized for h_l1_term.")
    return float(lam_h * np.sum(np.abs(model.H)))


# --------------------------------------------------------------------------------
# U Decorrelaton (γ term)... Decorrelator (after equation 8 decorrelator equation part)
# --------------------------------------------------------------------------------

def u_decorrelation_term(model: PoissonTopicModel) -> float:
    gamma = float(getattr(model.config, "gamma", 0.0))
    if gamma <= 0:
        return 0.0
    if model.U is None:
        raise ValueError("U must be initialized for u_decorrelation_term.")

    U = model.U
    G = U.T @ U
    G_off = G - np.diag(np.diag(G))
    return float(np.sum(G_off ** 2))


# -----------------------------------------------------------
# Total Loss
# -----------------------------------------------------------

def compute_loss_components(model: PoissonTopicModel) -> Dict[str, float]:
    data = data_term(model)
    r_u = u_reg_term(model)
    r_h = h_l1_term(model)

    # ---------------------------

    #after equation 8 the decorrelator part of code
    # --------------------------
    R_dec = u_decorrelation_term(model)

    gamma = float(getattr(model.config, "gamma", 0.0))
    decor_scaled = 0.5 * gamma * R_dec

    total = data + r_u + r_h + decor_scaled

    return {
        "total": float(total),
        "data": float(data),
        "u_reg": float(r_u),
        "h_l1": float(r_h),
        "u_decor_raw": float(R_dec),
        "u_decor_scaled": float(decor_scaled),
    }


def total_loss(model: PoissonTopicModel) -> float:
    return compute_loss_components(model)["total"]
