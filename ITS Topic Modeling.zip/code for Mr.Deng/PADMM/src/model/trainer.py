# src/model/trainer.py

from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, Any
import csv  # <-- NEW

import numpy as np
import yaml

from src.data_pipeline.combine_cities import load_paths
from src.model.poisson_topic_model import (
    PoissonTopicModelConfig,
    build_poisson_topic_model,
)
from src.model.initialization import initialize_model
# CHANGED: import the high-level wrapper instead of pdf_mm_update_UA
from src.model.updates_u_a import u_update_step
from src.model.admm_h import admm_step_for_H
from src.model.losses import compute_loss_components

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------
# Helper: load YAML config
# ---------------------------------------------------------------------

def _load_model_and_training_config(
    model_config_path: str = "configs/model.yaml",
) -> tuple[PoissonTopicModelConfig, Dict[str, Any]]:
    """
    Load model + training configuration from a YAML file.

    Expected structure:

        model:
          num_topics: 10
          lambda_u: 0.0
          lambda_h: 1e-3
          gamma: 0.1
          epsilon: 1e-8

        training:
          num_outer_iters: 100
          u_mm_inner_iters: 1
          u_decor_lr: 0.01
          admm_rho: 1.0
          admm_inner_iters: 5
          lr_h: 1e-3
          random_seed: 0
          log_every: 1
          checkpoint_every: 10
          # no_h_model: false   # <-- OPTIONAL (used only in No-H ablation)

    """
    cfg_path = Path(model_config_path)
    if not cfg_path.exists():
        raise FileNotFoundError(
            f"Model/training config not found at: {cfg_path}. "
            f"Please create configs/model.yaml."
        )

    with cfg_path.open("r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    if "model" not in cfg:
        raise ValueError("configs/model.yaml must contain a top-level 'model' section.")
    model_cfg_dict = cfg["model"]
    model_cfg = PoissonTopicModelConfig(**model_cfg_dict)

    training_cfg: Dict[str, Any] = cfg.get("training", {})
    return model_cfg, training_cfg


# ---------------------------------------------------------------------
# Helper: save checkpoints
# ---------------------------------------------------------------------

def _save_model_state(
    model,
    data_paths: Dict[str, str],
    outer_iter: int,
    tag: str = "iter",
) -> None:
    """
    Save the current model state (U, H, a, Z, Gamma) to the model_state_dir.

    Files will be named like:

        U_iter_0005.npy, H_iter_0005.npy, a_iter_0005.npy, ...

    For the final snapshot, tag='final' and outer_iter can be ignored.
    """
    state_dir = Path(data_paths["model_state_dir"])
    state_dir.mkdir(parents=True, exist_ok=True)

    if tag == "final":
        suffix = "final"
    else:
        suffix = f"{tag}_{outer_iter:04d}"

    def _save_if_not_none(name: str, arr) -> None:
        if arr is None:
            return
        path = state_dir / f"{name}_{suffix}.npy"
        np.save(path, arr)

    _save_if_not_none("U", model.U)
    _save_if_not_none("H", model.H)
    _save_if_not_none("a", model.a)
    _save_if_not_none("Z", model.Z)
    _save_if_not_none("Gamma", getattr(model, "Gamma", None))  # legacy, safe

    logger.info("Saved model state (suffix=%s) to directory: %s", suffix, state_dir)


# ---------------------------------------------------------------------
# Main training entry point
# ---------------------------------------------------------------------

def train_model(
    paths_config: str = "configs/paths.yaml",
    model_config_path: str = "configs/model.yaml",
) -> None:
    """
    Train the Poisson Deconvolution Factorization (PDF) model on the
    influence-weighted keyword graph.

    Pipeline:

      1) Load paths (including graph and salience locations).
      2) Load model & training config from YAML.
      3) Build PoissonTopicModel (using W and salience s).
      4) Initialize variables (U, H, a, Z, Y/Gamma).
      5) For each outer iteration:
            - MM update for (U, a),
            - ADMM update for H (unless no_h_model=True),
            - compute and log loss components,
            - periodically save checkpoints.
      6) Save final model snapshot.

    This function is called from main.py when stage == "train_model".
    """
    logger_main = logging.getLogger("train_model")
    logger_main.info("Starting PDF training pipeline ...")

    # 1) Load data paths (graph, salience, model_state_dir, etc.)
    data_paths: Dict[str, str] = load_paths(paths_config)

    if "model_state_dir" not in data_paths:
        raise KeyError(
            "paths.yaml must contain a key 'model_state_dir' specifying "
            "where to save model checkpoints."
        )
    if "model_dir" not in data_paths:
        raise KeyError(
            "paths.yaml must contain a key 'model_dir' specifying "
            "where to save training_loss.csv and plots."
        )

    # Directory + CSV path for training loss
    model_dir = Path(data_paths["model_dir"])      # e.g. data/processed/model
    model_dir.mkdir(parents=True, exist_ok=True)
    loss_csv_path = model_dir / "training_loss.csv"

    logger_main.info("Training loss CSV will be written to: %s", loss_csv_path)

    # Overwrite existing CSV and write header
    with loss_csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["iter", "total", "data", "u_reg", "h_l1", "decor_scaled"])

    # 2) Load model+training config
    model_cfg, training_cfg = _load_model_and_training_config(model_config_path)

    num_outer_iters = int(training_cfg.get("num_outer_iters", 100))
    log_every = int(training_cfg.get("log_every", 1))
    checkpoint_every = int(training_cfg.get("checkpoint_every", 10))

    # IMPORTANT: this flag is only used by the No-H ablation.
    # In your normal full model, you DO NOT set it in configs/model.yaml.
    no_h_model = bool(training_cfg.get("no_h_model", False))

    logger_main.info("Model config: %s", model_cfg)
    logger_main.info("Training for %d outer iterations", num_outer_iters)
    logger_main.info("no_h_model flag: %s", no_h_model)

    # 3) Build model (loads W and salience)
    model = build_poisson_topic_model(
        paths_config=paths_config,
        model_config=model_cfg,
    )

    # 4) Initialize (U, H, a, Z, Y/Gamma)
    initialize_model(model, training_cfg)

    # If we are in the *structural-only* No-H ablation:
    #   Θ = U diag(a) U^T, H ≡ 0, and we skip ADMM.
    if no_h_model:
        logger_main.info(
            "No-H ablation active (no_h_model=True): "
            "zeroing H, Z, Y and disabling ADMM H-updates."
        )
        V, K = model.U.shape
        H_zero = np.zeros((V, K), dtype=np.float64)
        model.H = H_zero
        model.Z = np.zeros_like(H_zero)
        # New ADMM dual variable
        if hasattr(model, "Y"):
            model.Y = np.zeros_like(H_zero)
        # Legacy name, kept for backward compatibility
        if hasattr(model, "Gamma"):
            model.Gamma = np.zeros_like(H_zero)

    # 5) Outer iterations: MM for (U,a), then ADMM for H (unless no_h_model)
    for it in range(1, num_outer_iters + 1):
        logger_main.info("=== Outer iteration %d / %d ===", it, num_outer_iters)

        # 5.1) MM update for U and a
        logger_main.info("Step 1: MM update for U and a")
        # CHANGED: use the wrapper that reads config and calls pdf_mm_update_UA correctly
        u_update_step(model, training_cfg)

        # 5.2) ADMM update for H  (or skip if no_h_model)
        if no_h_model:
            logger_main.info(
                "Step 2: ADMM update for H SKIPPED (No-H structural-only ablation)."
            )
            # For logging / CSV we still compute loss components
            loss_components = compute_loss_components(model)
        else:
            logger_main.info("Step 2: ADMM update for H")
            loss_components = admm_step_for_H(model, training_cfg)

        # 5.3) Compute and log loss (after both blocks)
        if it % log_every == 0:
            comps = compute_loss_components(model)
            logger_main.info(
                "Iter %d: total=%.4f | data=%.4f | u_reg=%.4f | h_l1=%.4f | u_decor_scaled=%.6f",
                it,
                comps["total"],
                comps["data"],
                comps["u_reg"],
                comps["h_l1"],
                comps["u_decor_scaled"],
            )

            # NEW: append this iteration's losses to CSV
            with loss_csv_path.open("a", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(
                    [
                        it,
                        comps["total"],
                        comps["data"],
                        comps["u_reg"],
                        comps["h_l1"],
                        # plot_training_loss.py expects a column named 'decor_scaled'
                        comps["u_decor_scaled"],
                    ]
                )

        # 5.4) Checkpoint
        if it % checkpoint_every == 0:
            _save_model_state(model, data_paths, it, tag="iter")

    # 6) Final snapshot
    _save_model_state(model, data_paths, outer_iter=num_outer_iters, tag="final")

    logger_main.info("PDF training completed. Final model state saved.")
