# src/model/inspect_topics.py

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


def inspect_topics(
        vocab_path: str = r"C:\Users\Sabir\PycharmProjects\PADMM\data\processed\vocab\vocab.json",
        U_path: str = r"C:\Users\Sabir\PycharmProjects\PADMM\data\processed\model\state\U_final.npy",
        top_m: int = 10,
) -> None:
    """
    Print top-m words per topic based on the final U matrix.

    Assumes:
      - vocab_path points to vocab.json with "id_to_token" list
      - U_path is a numpy array of shape (V, K) saved by trainer.py
    """
    vocab_path = Path(vocab_path)
    U_path = Path(U_path)

    if not vocab_path.exists():
        raise FileNotFoundError(f"vocab.json not found at: {vocab_path}")
    if not U_path.exists():
        raise FileNotFoundError(f"U_final.npy not found at: {U_path}")

    # Load vocab
    with vocab_path.open("r", encoding="utf-8") as f:
        vocab_obj = json.load(f)
    id_to_token = vocab_obj["id_to_token"]
    V_vocab = len(id_to_token)

    # Load U
    U = np.load(U_path)  # shape (V, K)
    V, K = U.shape
    if V != V_vocab:
        raise ValueError(
            f"Mismatch: U has V={V}, but vocab has V={V_vocab}. "
            f"Check that you are using the correct U_final.npy and vocab.json."
        )

    print(f"Loaded U with shape {U.shape} (V x K)")
    print(f"Vocabulary size: {V_vocab}")
    print(f"Showing top {top_m} words per topic.\n")

    for k in range(K):
        col = U[:, k]
        # Get indices of top-m entries (largest values)
        top_ids = np.argsort(-col)[:top_m]

        print(f"=== Topic {k} ===")
        for idx in top_ids:
            token = id_to_token[idx]
            weight = col[idx]
            print(f"{token:20s}  {weight:.4f}")
        print()


if __name__ == "__main__":
    inspect_topics()
