# src/experiments/baselines/run_lda.py

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List

import yaml
import numpy as np
import pandas as pd

from src.data_pipeline.combine_cities import load_paths
from src.evaluation.topics_io import load_docs_tokens
from src.evaluation.coherence import compute_topic_coherence
from src.evaluation.diversity import compute_topic_diversity

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------
# 1) Load LDA baseline config
# ---------------------------------------------------------------------
def _load_lda_config(
    baselines_config: str = "configs/experiments_baselines.yaml",
) -> Dict[str, Any]:
    """
    Load LDA baseline configuration from experiments_baselines.yaml.

    Expected structure:

      baselines:
        lda:
          num_topics: 20
          passes: 20
          iterations: 1000
          random_state: 42
          top_m: 10
          tag: "lda_K20"
    """
    cfg_path = Path(baselines_config)
    if not cfg_path.exists():
        raise FileNotFoundError(f"Baselines config not found: {cfg_path}")

    with cfg_path.open("r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}

    lda_cfg = (cfg.get("baselines") or {}).get("lda")
    if lda_cfg is None:
        raise KeyError(
            "No 'baselines.lda' section found in configs/experiments_baselines.yaml"
        )

    return lda_cfg


# ---------------------------------------------------------------------
# 2) Main LDA baseline runner
# ---------------------------------------------------------------------
def run_lda_baseline(
    paths_config: str = "configs/paths.yaml",
    baselines_config: str = "configs/experiments_baselines.yaml",
) -> None:
    """
    Train an LDA baseline on the same preprocessed tokenized corpus as
    the main PDF model and evaluate it on:

      - NPMI
      - C_v
      - Topic Diversity (TD)

    Output files (under eval/baselines):

      {tag}_top_words.csv
      {tag}_topic_metrics.csv
      {tag}_overall_metrics.csv

    where 'tag' comes from experiments_baselines.yaml (e.g. 'lda_K20').
    """
    logger.info("Starting LDA baseline...")

    # --------------------------------------------------------------
    # 2.1 Load config + paths
    # --------------------------------------------------------------
    lda_cfg = _load_lda_config(baselines_config=baselines_config)
    num_topics = int(lda_cfg.get("num_topics", 20))   # match main model by default
    passes = int(lda_cfg.get("passes", 20))
    iterations = int(lda_cfg.get("iterations", 1000))
    random_state = int(lda_cfg.get("random_state", 42))
    top_m = int(lda_cfg.get("top_m", 10))
    tag = str(lda_cfg.get("tag", f"lda_K{num_topics}"))

    logger.info(
        "LDA baseline config: num_topics=%d, passes=%d, iterations=%d, "
        "random_state=%d, top_m=%d, tag=%s",
        num_topics,
        passes,
        iterations,
        random_state,
        top_m,
        tag,
    )

    data_paths = load_paths(paths_config)

    # Reuse your eval directory root, then create a 'baselines' subdir
    eval_root = Path(data_paths["topic_eval_overall_metrics"]).parent
    baseline_dir = eval_root / "baselines"
    baseline_dir.mkdir(parents=True, exist_ok=True)

    top_words_csv = baseline_dir / f"{tag}_top_words.csv"
    topic_metrics_csv = baseline_dir / f"{tag}_topic_metrics.csv"
    overall_metrics_csv = baseline_dir / f"{tag}_overall_metrics.csv"

    # --------------------------------------------------------------
    # 2.2 Load tokenized documents (same as full model evaluation)
    # --------------------------------------------------------------
    print("[LDA] Loading tokenized documents...")
    docs_tokens: List[List[str]] = load_docs_tokens(paths_config=paths_config)
    print(f"[LDA] Number of documents: {len(docs_tokens)}")

    # --------------------------------------------------------------
    # 2.3 Train LDA using gensim
    # --------------------------------------------------------------
    try:
        from gensim import corpora, models
    except ImportError as e:
        raise ImportError(
            "gensim is required for the LDA baseline. "
            "Please install it via: pip install gensim"
        ) from e

    print("[LDA] Building dictionary and corpus...")
    dictionary = corpora.Dictionary(docs_tokens)
    corpus = [dictionary.doc2bow(doc) for doc in docs_tokens]

    print("[LDA] Training LDA model...")
    lda_model = models.LdaModel(
        corpus=corpus,
        id2word=dictionary,
        num_topics=num_topics,
        passes=passes,
        iterations=iterations,
        random_state=random_state,
    )
    print("[LDA] Training done.")

    # --------------------------------------------------------------
    # 2.4 Extract top-m words per topic
    # --------------------------------------------------------------
    print(f"[LDA] Extracting top-{top_m} words for each topic...")
    topic_word_tokens: List[List[str]] = []
    for k in range(num_topics):
        # show_topic returns list of (word, prob)
        top_terms = lda_model.show_topic(k, topn=top_m)
        topic_word_tokens.append([w for (w, _) in top_terms])

    # --------------------------------------------------------------
    # 2.5 Compute coherence (NPMI, C_v)
    # --------------------------------------------------------------
    print("[LDA] Computing topic coherence (NPMI, C_v)...")
    coh_results = compute_topic_coherence(
        topic_word_tokens=topic_word_tokens,
        docs_tokens=docs_tokens,
    )

    per_topic_npmi = coh_results["per_topic_npmi"]
    per_topic_c_v = coh_results["per_topic_c_v"]
    avg_npmi = coh_results["avg_npmi"]
    avg_c_v = coh_results["avg_c_v"]
    union_words = coh_results["union_words"]

    # --------------------------------------------------------------
    # 2.6 Compute topic diversity (TD)
    # --------------------------------------------------------------
    print("[LDA] Computing topic diversity (TD)...")
    td_info = compute_topic_diversity(
        union_words=union_words,
        num_topics=num_topics,
        top_m=top_m,
    )
    topic_diversity = td_info["topic_diversity"]

    # --------------------------------------------------------------
    # 2.7 Save top words per topic
    # --------------------------------------------------------------
    print(f"[LDA] Saving top words per topic to: {top_words_csv}")
    top_rows: List[Dict[str, Any]] = []
    for k, words in enumerate(topic_word_tokens):
        row: Dict[str, Any] = {"topic_id": k}
        for i, w in enumerate(words):
            row[f"word_{i+1}"] = w
        top_rows.append(row)

    df_top = pd.DataFrame(top_rows)
    df_top.to_csv(top_words_csv, index=False, encoding="utf-8-sig")

    # --------------------------------------------------------------
    # 2.8 Save per-topic metrics
    # --------------------------------------------------------------
    print(f"[LDA] Saving per-topic metrics to: {topic_metrics_csv}")
    df_metrics = pd.DataFrame(
        {
            "topic_id": list(range(num_topics)),
            "npmi": per_topic_npmi,
            "c_v": per_topic_c_v,
        }
    )
    df_metrics.to_csv(topic_metrics_csv, index=False, encoding="utf-8-sig")

    # --------------------------------------------------------------
    # 2.9 Save overall metrics
    # --------------------------------------------------------------
    print(f"[LDA] Saving overall metrics to: {overall_metrics_csv}")
    df_overall = pd.DataFrame(
        [
            {
                "avg_npmi": float(avg_npmi),
                "avg_c_v": float(avg_c_v),
                "topic_diversity": float(topic_diversity),
                "num_unique_words": int(td_info["num_unique_words"]),
                "num_topics": int(td_info["num_topics"]),
                "top_m": int(td_info["top_m"]),
                "tag": tag,
            }
        ]
    )
    df_overall.to_csv(overall_metrics_csv, index=False, encoding="utf-8-sig")

    # --------------------------------------------------------------
    # 2.10 Print summary
    # --------------------------------------------------------------
    print("[LDA] ===== Topic Quality Summary (LDA baseline) =====")
    print(f"[LDA] Avg NPMI        : {avg_npmi:.4f}")
    print(f"[LDA] Avg C_v         : {avg_c_v:.4f}")
    print(f"[LDA] Topic Diversity : {topic_diversity:.4f}")
    print(f"[LDA] Num topics (K)  : {num_topics}")
    print(f"[LDA] Top-m per topic : {top_m}")
    print("[LDA] ================================================\n")

    logger.info(
        "LDA baseline finished. avg_npmi=%.4f, avg_c_v=%.4f, TD=%.4f",
        avg_npmi,
        avg_c_v,
        topic_diversity,
    )
