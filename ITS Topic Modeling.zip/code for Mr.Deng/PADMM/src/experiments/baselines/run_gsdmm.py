# src/experiments/baselines/run_gsdmm.py

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import List, Dict, Any

import numpy as np
import yaml

from src.data_pipeline.combine_cities import load_paths
from src.evaluation.coherence import compute_topic_coherence
from src.evaluation.diversity import compute_topic_diversity
from src.evaluation.topics_io import load_docs_tokens


logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Simple GSDMM implementation (Movie Group Process)
# ---------------------------------------------------------------------------

@dataclass
class GSDMMConfig:
    K: int = 10
    alpha: float = 0.1
    beta: float = 0.1
    n_iters: int = 50
    random_state: int = 42


class GSDMM:
    """
    Collapsed Gibbs sampler for GSDMM.

    We assume:
      - Each document belongs to exactly one cluster (topic).
      - Documents are short (good for Weibo / tweets type text).
    """

    def __init__(self, cfg: GSDMMConfig):
        self.cfg = cfg
        self.word2id: Dict[str, int] = {}
        self.id2word: List[str] = []
        self.n_kv: np.ndarray | None = None  # (K, V) word counts
        self.n_k: np.ndarray | None = None   # (K,) total words per cluster
        self.m_k: np.ndarray | None = None   # (K,) docs per cluster
        self.z_d: List[int] | None = None    # doc assignments

    def _build_vocab(self, docs_tokens: List[List[str]]) -> List[List[int]]:
        """
        Build word↔id mapping and convert docs to integer ids.
        """
        word2id: Dict[str, int] = {}
        id2word: List[str] = []

        docs_int: List[List[int]] = []
        for doc in docs_tokens:
            doc_ids: List[int] = []
            for w in doc:
                if w not in word2id:
                    wid = len(word2id)
                    word2id[w] = wid
                    id2word.append(w)
                else:
                    wid = word2id[w]
                doc_ids.append(wid)
            docs_int.append(doc_ids)

        self.word2id = word2id
        self.id2word = id2word
        return docs_int

    def fit(self, docs_tokens: List[List[str]]) -> None:
        """
        Run Gibbs sampling for GSDMM.
        """
        cfg = self.cfg
        rng = np.random.default_rng(cfg.random_state)

        # 1) Build vocabulary and integer docs
        docs_int = self._build_vocab(docs_tokens)
        N = len(docs_int)
        V = len(self.word2id)
        K = cfg.K
        alpha = cfg.alpha
        beta = cfg.beta

        # 2) Initialize counts
        n_kv = np.zeros((K, V), dtype=np.int32)
        n_k = np.zeros(K, dtype=np.int32)
        m_k = np.zeros(K, dtype=np.int32)
        z_d: List[int] = []

        # Random initialization of cluster assignments
        for doc in docs_int:
            if len(doc) == 0:
                # empty doc: assign to a random cluster but no counts added
                k = rng.integers(0, K)
                z_d.append(k)
                m_k[k] += 1
                continue

            k = rng.integers(0, K)
            z_d.append(k)
            m_k[k] += 1
            for w in doc:
                n_kv[k, w] += 1
                n_k[k] += 1

        # 3) Gibbs sampling
        for it in range(cfg.n_iters):
            for d_idx, doc in enumerate(docs_int):
                if len(doc) == 0:
                    continue

                old_k = z_d[d_idx]

                # remove doc from old cluster
                m_k[old_k] -= 1
                for w in doc:
                    n_kv[old_k, w] -= 1
                    n_k[old_k] -= 1

                # compute probabilities for each cluster
                probs = np.zeros(K, dtype=np.float64)

                for k in range(K):
                    # (m_k + alpha)
                    cluster_prior = (m_k[k] + alpha) / (N - 1 + K * alpha)

                    # likelihood term (product over words)
                    # we approximate using the standard formula for GSDMM:
                    # ∏_{i=1}^{n_d} (n_kw + β + i - 1) / (n_k + Vβ + i - 1)
                    n_k_total = n_k[k]
                    term_log = 0.0
                    for w in doc:
                        n_kw = n_kv[k, w]
                        term_log += np.log(n_kw + beta) - np.log(
                            n_k_total + V * beta
                        )
                        n_k_total += 1

                    probs[k] = np.log(cluster_prior) + term_log

                # stabilize / exponentiate
                max_log = probs.max()
                probs = np.exp(probs - max_log)
                probs_sum = probs.sum()
                if probs_sum <= 0:
                    probs[:] = 1.0 / K
                else:
                    probs /= probs_sum

                # sample new cluster
                new_k = int(rng.choice(np.arange(K), p=probs))
                z_d[d_idx] = new_k
                m_k[new_k] += 1
                for w in doc:
                    n_kv[new_k, w] += 1
                    n_k[new_k] += 1

            logger.info(
                "GSDMM iter %03d: active clusters=%d",
                it + 1,
                int((m_k > 0).sum()),
            )

        self.n_kv = n_kv
        self.n_k = n_k
        self.m_k = m_k
        self.z_d = z_d

    def topic_word_dist(self) -> np.ndarray:
        """
        Return topic-word distribution matrix Φ with shape (K, V).
        """
        if self.n_kv is None or self.n_k is None:
            raise RuntimeError("Model not fitted yet.")

        K, V = self.n_kv.shape
        beta = self.cfg.beta

        phi = (self.n_kv + beta) / (self.n_k[:, None] + beta * V)
        return phi


# ---------------------------------------------------------------------------
# Run GSDMM baseline
# ---------------------------------------------------------------------------

def run_gsdmm_baseline(
    paths_config: str = "configs/paths.yaml",
    baselines_config: str = "configs/experiments_baselines.yaml",
) -> None:
    """
    Run GSDMM baseline:

      - Train GSDMM on tokenized documents.
      - Extract topic-word distributions.
      - Compute NPMI, C_v, and Topic Diversity (TD).
      - Save CSVs in data/processed/eval/baselines/ with tag from YAML.
    """
    logger.info("Starting GSDMM baseline evaluation...")

    # ------------------------------------------------------------------
    # 1) Load baseline config
    # ------------------------------------------------------------------
    tag = "gsdmm_K10"
    cfg_gsdmm = GSDMMConfig()
    top_m = 10

    abl_path = Path(baselines_config)
    if abl_path.exists():
        with abl_path.open("r", encoding="utf-8") as f:
            baselines_cfg = yaml.safe_load(f) or {}
        gsdmm_cfg: Dict[str, Any] = (baselines_cfg.get("baselines") or {}).get("gsdmm", {})

        tag = gsdmm_cfg.get("tag", tag)
        cfg_gsdmm.K = int(gsdmm_cfg.get("num_topics", cfg_gsdmm.K))
        cfg_gsdmm.alpha = float(gsdmm_cfg.get("alpha", cfg_gsdmm.alpha))
        cfg_gsdmm.beta = float(gsdmm_cfg.get("beta", cfg_gsdmm.beta))
        cfg_gsdmm.n_iters = int(gsdmm_cfg.get("n_iters", cfg_gsdmm.n_iters))
        cfg_gsdmm.random_state = int(gsdmm_cfg.get("random_state", cfg_gsdmm.random_state))
        top_m = int(gsdmm_cfg.get("top_m", top_m))

    logger.info(
        "GSDMM baseline config: tag=%s, K=%d, alpha=%.3f, beta=%.3f, n_iters=%d, top_m=%d",
        tag,
        cfg_gsdmm.K,
        cfg_gsdmm.alpha,
        cfg_gsdmm.beta,
        cfg_gsdmm.n_iters,
        top_m,
    )

    # ------------------------------------------------------------------
    # 2) Load tokenized documents
    # ------------------------------------------------------------------
    docs_tokens = load_docs_tokens(paths_config=paths_config)
    logger.info("Loaded %d documents for GSDMM baseline.", len(docs_tokens))

    # Remove empty docs (if any)
    docs_tokens = [doc for doc in docs_tokens if len(doc) > 0]
    if not docs_tokens:
        raise ValueError("No non-empty documents available for GSDMM baseline.")

    # ------------------------------------------------------------------
    # 3) Fit GSDMM
    # ------------------------------------------------------------------
    model = GSDMM(cfg_gsdmm)
    logger.info("Training GSDMM model (this may take some time)...")
    model.fit(docs_tokens)
    logger.info("GSDMM training complete.")

    # 4) Topic-word distribution
    phi = model.topic_word_dist()  # shape (K, V)
    K, V = phi.shape
    id2word = model.id2word

    # ------------------------------------------------------------------
    # 5) Extract top-m words per topic
    # ------------------------------------------------------------------
    topic_word_tokens: List[List[str]] = []
    topic_word_indices: List[List[int]] = []
    for k in range(K):
        row = phi[k, :]
        top_idx = np.argsort(-row)[:top_m]
        topic_word_indices.append(top_idx.tolist())
        topic_word_tokens.append([id2word[j] for j in top_idx])

    # ------------------------------------------------------------------
    # 6) Compute coherence and diversity
    # ------------------------------------------------------------------
    logger.info("Computing topic coherence (NPMI, C_v) for GSDMM...")
    coh_results = compute_topic_coherence(
        topic_word_tokens=topic_word_tokens,
        docs_tokens=docs_tokens,
    )

    per_topic_npmi = coh_results["per_topic_npmi"]
    per_topic_c_v = coh_results["per_topic_c_v"]
    avg_npmi = coh_results["avg_npmi"]
    avg_c_v = coh_results["avg_c_v"]
    union_words = coh_results["union_words"]

    logger.info("Computing topic diversity (TD) for GSDMM...")
    td_info = compute_topic_diversity(
        union_words=union_words,
        num_topics=K,
        top_m=top_m,
    )
    topic_diversity = td_info["topic_diversity"]

    # ------------------------------------------------------------------
    # 7) Save CSVs under data/processed/eval/baselines/
    # ------------------------------------------------------------------
    data_paths = load_paths(paths_config)
    full_top_words = Path(data_paths["topic_eval_top_words"])
    baseline_dir = full_top_words.parent / "baselines"
    baseline_dir.mkdir(parents=True, exist_ok=True)

    top_words_csv = baseline_dir / f"{tag}_top_words.csv"
    topic_metrics_csv = baseline_dir / f"{tag}_topic_metrics.csv"
    overall_metrics_csv = baseline_dir / f"{tag}_overall_metrics.csv"

    # top words
    rows_top: List[Dict[str, Any]] = []
    for k, words in enumerate(topic_word_tokens):
        row: Dict[str, Any] = {"topic_id": k}
        for i, w in enumerate(words):
            row[f"word_{i+1}"] = w
        rows_top.append(row)
    import pandas as pd
    df_top = pd.DataFrame(rows_top)
    df_top.to_csv(top_words_csv, index=False, encoding="utf-8-sig")

    # per-topic metrics
    df_metrics = pd.DataFrame(
        {
            "topic_id": list(range(K)),
            "npmi": per_topic_npmi,
            "c_v": per_topic_c_v,
        }
    )
    df_metrics.to_csv(topic_metrics_csv, index=False, encoding="utf-8-sig")

    # overall metrics
    df_overall = pd.DataFrame(
        [
            {
                "avg_npmi": float(avg_npmi),
                "avg_c_v": float(avg_c_v),
                "topic_diversity": float(topic_diversity),
                "num_unique_words": int(td_info["num_unique_words"]),
                "num_topics": int(td_info["num_topics"]),
                "top_m": int(td_info["top_m"]),
            }
        ]
    )
    df_overall.to_csv(overall_metrics_csv, index=False, encoding="utf-8-sig")

    # ------------------------------------------------------------------
    # 8) Log summary
    # ------------------------------------------------------------------
    print("[GSDMM] ===== Topic Quality Summary (GSDMM baseline) =====")
    print(f"[GSDMM] Avg NPMI        : {avg_npmi:.4f}")
    print(f"[GSDMM] Avg C_v         : {avg_c_v:.4f}")
    print(f"[GSDMM] Topic Diversity : {topic_diversity:.4f}")
    print(f"[GSDMM] Num topics (K)  : {K}")
    print(f"[GSDMM] Top-m per topic : {top_m}")
    print("[GSDMM] ===============================================\n")

    logger.info(
        "GSDMM baseline finished. avg_npmi=%.4f, avg_c_v=%.4f, TD=%.4f",
        avg_npmi,
        avg_c_v,
        topic_diversity,
    )
