# src/experiments/baselines/run_hdp.py

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List

import yaml
import numpy as np
import pandas as pd
from gensim.corpora import Dictionary
from gensim.models import HdpModel

from src.data_pipeline.combine_cities import load_paths
from src.evaluation.coherence import compute_topic_coherence
from src.evaluation.diversity import compute_topic_diversity


logger = logging.getLogger(__name__)


def _load_docs_tokens(paths_config: str = "configs/paths.yaml") -> List[List[str]]:
    """
    Load tokenized documents from tokenized_posts CSV.

    Expects:
        data_paths["tokenized_posts"] -> CSV with 'tokens' column
    where 'tokens' is a space-separated string.
    """
    data_paths = load_paths(paths_config)
    token_csv = Path(data_paths["tokenized_posts"])

    if not token_csv.exists():
        raise FileNotFoundError(f"Tokenized posts CSV not found: {token_csv}")

    df = pd.read_csv(token_csv, encoding="utf-8-sig")
    if "tokens" not in df.columns:
        raise ValueError(f"'tokens' column not found in: {token_csv}")

    docs_tokens: List[List[str]] = []
    for s in df["tokens"]:
        if isinstance(s, str):
            docs_tokens.append(s.split())
        else:
            docs_tokens.append([])

    return docs_tokens


def run_hdp_baseline(
    paths_config: str = "configs/paths.yaml",
    baselines_config: str = "configs/experiments_baselines.yaml",
) -> None:
    """
    HDP baseline using gensim.models.HdpModel.

    Steps:
      1) Load tokenized documents.
      2) Build gensim Dictionary + corpus.
      3) Fit HDP model.
      4) Take top-K topics (from config), extract top-M words per topic.
      5) Compute coherence (NPMI, C_v) and topic diversity (TD).
      6) Save CSVs under data/processed/eval/baselines/.
    """
    logger.info("Starting HDP baseline evaluation...")

    # ------------------------------------------------------------------
    # 1) Load baseline settings (tag, K, etc.) from experiments_baselines.yaml
    # ------------------------------------------------------------------
    tag = "hdp_K10"
    top_k_topics = 10
    top_m = 10
    min_df = 5
    max_df_ratio = 0.5

    baselines_path = Path(baselines_config)
    if baselines_path.exists():
        try:
            with baselines_path.open("r", encoding="utf-8") as f:
                cfg_all = yaml.safe_load(f) or {}
            hdp_cfg: Dict[str, Any] = (cfg_all.get("baselines") or {}).get("hdp", {})
            tag = hdp_cfg.get("tag", tag)
            top_k_topics = int(hdp_cfg.get("top_k_topics", top_k_topics))
            top_m = int(hdp_cfg.get("top_m", top_m))
            min_df = int(hdp_cfg.get("min_df", min_df))
            max_df_ratio = float(hdp_cfg.get("max_df_ratio", max_df_ratio))
        except Exception as e:
            logger.warning(
                "Could not read HDP config from %s (%s). Using defaults.",
                baselines_path,
                e,
            )

    logger.info(
        "HDP baseline config: tag=%s, top_k_topics=%d, top_m=%d, min_df=%d, max_df_ratio=%.2f",
        tag,
        top_k_topics,
        top_m,
        min_df,
        max_df_ratio,
    )

    # ------------------------------------------------------------------
    # 2) Load documents and build Dictionary + corpus
    # ------------------------------------------------------------------
    docs_tokens = _load_docs_tokens(paths_config=paths_config)
    logger.info("Loaded %d documents for HDP baseline.", len(docs_tokens))

    dictionary = Dictionary(docs_tokens)
    dictionary.filter_extremes(no_below=min_df, no_above=max_df_ratio)
    logger.info(
        "Dictionary built: %d tokens before filtering, %d after.",
        dictionary.num_docs,
        len(dictionary),
    )

    corpus = [dictionary.doc2bow(doc) for doc in docs_tokens]
    logger.info("Corpus size: %d documents.", len(corpus))

    # ------------------------------------------------------------------
    # 3) Fit HDP model
    # ------------------------------------------------------------------
    logger.info("Training gensim HdpModel (this may take some time)...")
    hdp = HdpModel(corpus=corpus, id2word=dictionary)
    logger.info("HDP model trained: %s", hdp)

    # ------------------------------------------------------------------
    # 4) Extract top-K topics and top-M words per topic
    # ------------------------------------------------------------------
    logger.info(
        "Extracting top-%d topics and top-%d words per topic from HDP...",
        top_k_topics,
        top_m,
    )

    # show_topics returns list of (topic_id, [(word, prob), ...])
    hdp_topics = hdp.show_topics(
        num_topics=top_k_topics, num_words=top_m, formatted=False
    )

    topic_word_tokens: List[List[str]] = []
    for topic_id, word_probs in hdp_topics:
        words = [w for (w, _p) in word_probs]
        topic_word_tokens.append(words)

    K = len(topic_word_tokens)
    if K == 0:
        raise RuntimeError("HDP returned zero topics; cannot evaluate baseline.")

    # ------------------------------------------------------------------
    # 5) Compute coherence (NPMI, C_v) and diversity (TD)
    # ------------------------------------------------------------------
    logger.info("Computing topic coherence (NPMI, C_v) for HDP...")
    coh_results = compute_topic_coherence(
        topic_word_tokens=topic_word_tokens,
        docs_tokens=docs_tokens,
    )

    per_topic_npmi = coh_results["per_topic_npmi"]
    per_topic_c_v = coh_results["per_topic_c_v"]
    avg_npmi = float(coh_results["avg_npmi"])
    avg_c_v = float(coh_results["avg_c_v"])
    union_words = coh_results["union_words"]

    logger.info("Computing topic diversity (TD) for HDP...")
    td_info = compute_topic_diversity(
        union_words=union_words,
        num_topics=K,
        top_m=top_m,
    )
    topic_diversity = float(td_info["topic_diversity"])

    # ------------------------------------------------------------------
    # 6) Save CSVs
    # ------------------------------------------------------------------
    base_dir = Path("data/processed/eval/baselines")
    base_dir.mkdir(parents=True, exist_ok=True)

    top_words_csv = base_dir / f"{tag}_top_words.csv"
    topic_metrics_csv = base_dir / f"{tag}_topic_metrics.csv"
    overall_metrics_csv = base_dir / f"{tag}_overall_metrics.csv"

    # (a) top words per topic
    rows_top: List[Dict[str, Any]] = []
    for k, words in enumerate(topic_word_tokens):
        row: Dict[str, Any] = {"topic_id": k}
        for i, w in enumerate(words):
            row[f"word_{i+1}"] = w
        rows_top.append(row)
    df_top = pd.DataFrame(rows_top)
    df_top.to_csv(top_words_csv, index=False, encoding="utf-8-sig")

    # (b) per-topic metrics
    df_metrics = pd.DataFrame(
        {
            "topic_id": list(range(K)),
            "npmi": per_topic_npmi,
            "c_v": per_topic_c_v,
        }
    )
    df_metrics.to_csv(topic_metrics_csv, index=False, encoding="utf-8-sig")

    # (c) overall metrics
    df_overall = pd.DataFrame(
        [
            {
                "avg_npmi": avg_npmi,
                "avg_c_v": avg_c_v,
                "topic_diversity": topic_diversity,
                "num_unique_words": int(td_info["num_unique_words"]),
                "num_topics": int(td_info["num_topics"]),
                "top_m": int(td_info["top_m"]),
            }
        ]
    )
    df_overall.to_csv(overall_metrics_csv, index=False, encoding="utf-8-sig")

    # ------------------------------------------------------------------
    # 7) Log summary
    # ------------------------------------------------------------------
    print("[HDP] ===== Topic Quality Summary (HDP baseline) =====")
    print(f"[HDP] Avg NPMI        : {avg_npmi:.4f}")
    print(f"[HDP] Avg C_v         : {avg_c_v:.4f}")
    print(f"[HDP] Topic Diversity : {topic_diversity:.4f}")
    print(f"[HDP] Num topics (K)  : {K}")
    print(f"[HDP] Top-m per topic : {top_m}")
    print("[HDP] ===============================================\n")

    logger.info(
        "HDP baseline finished. avg_npmi=%.4f, avg_c_v=%.4f, TD=%.4f",
        avg_npmi,
        avg_c_v,
        topic_diversity,
    )
