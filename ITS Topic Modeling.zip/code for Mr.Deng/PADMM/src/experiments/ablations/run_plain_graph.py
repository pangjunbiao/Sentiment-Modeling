# src/experiments/ablations/run_plain_graph.py

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict

import yaml

from src.data_pipeline.combine_cities import load_paths
from src.graph.keyword_graph import build_and_save_keyword_graph
from src.model.trainer import train_model
from src.evaluation.report import evaluate_full_model


def run_plain_graph_ablation(
    paths_config: str = "configs/paths.yaml",
    ablation_config: str = "configs/experiments_ablation.yaml",
    top_m: int = 10,
) -> None:
    """
    Plain co-occurrence graph ablation:

    Goal:
      Remove BOTH:
        - influence weights w_p
        - salience scaling s_i s_j

      so the keyword graph becomes a simple adjacency-based co-occurrence
      graph built only from unordered adjacent bigrams:

          ω_plain(i,j) = sum_p δ^{(p)}_{ij},

      where δ^{(p)}_{ij} = 1 if (i,j) appears as an adjacent pair in post p.

    Procedure:
      1) Create a new keyword graph file with:
           use_post_weights = False, use_salience = False
      2) Temporarily point paths.yaml.data.graph_path / keyword_graph
         to this new graph.
      3) Train the model normally on this plain graph.
      4) Evaluate topic quality with a tag (e.g. 'plainGraph').
      5) Restore the original paths.yaml.
    """

    logger = logging.getLogger("run_plain_graph_ablation")
    logger.info("Starting: Plain co-occurrence graph ablation")

    # --------------------------------------------------------------
    # 1) Resolve current paths and choose filename for plain graph
    # --------------------------------------------------------------
    data_paths = load_paths(paths_config)
    orig_graph_path = Path(data_paths["graph_path"])

    graph_plain = orig_graph_path.with_name(
        orig_graph_path.stem + "_plainGraph.npz"
    )

    logger.info(f"PlainGraph: base graph_path     = {orig_graph_path}")
    logger.info(f"PlainGraph: plain graph_path    = {graph_plain}")

    # --------------------------------------------------------------
    # 2) Read ablation tag from experiments_ablation.yaml (optional)
    # --------------------------------------------------------------
    tag = "plainGraph"
    abl_path = Path(ablation_config)
    if abl_path.exists():
        try:
            with abl_path.open("r", encoding="utf-8") as f:
                ab_cfg = yaml.safe_load(f) or {}
            abl_info: Dict[str, Any] = (ab_cfg.get("ablations") or {}).get(
                "plain_graph", {}
            )
            tag = abl_info.get("tag", tag)
        except Exception as e:
            logger.warning(
                "Could not read experiments_ablation.yaml (%s). "
                "Using default tag '%s'.",
                e,
                tag,
            )

    # --------------------------------------------------------------
    # 3) Backup original configs/paths.yaml
    # --------------------------------------------------------------
    paths_cfg_path = Path(paths_config)
    if not paths_cfg_path.exists():
        raise FileNotFoundError(f"Paths config not found: {paths_cfg_path}")

    original_text = paths_cfg_path.read_text(encoding="utf-8")

    try:
        # ----------------------------------------------------------
        # 4) Modify paths.yaml so graph_path/keyword_graph point to plain graph
        # ----------------------------------------------------------
        cfg = yaml.safe_load(original_text) or {}
        if "data" not in cfg:
            raise KeyError("Expected 'data' section in paths.yaml for plain-graph ablation.")

        data_cfg = cfg["data"]

        data_cfg["graph_path"] = str(graph_plain)
        # keep alias key consistent if present
        data_cfg["keyword_graph"] = str(graph_plain)

        with paths_cfg_path.open("w", encoding="utf-8") as f:
            yaml.safe_dump(cfg, f, sort_keys=False, allow_unicode=True)

        logger.info(
            "PlainGraph ablation: updated paths.yaml to use plain graph at %s",
            graph_plain,
        )

        # ----------------------------------------------------------
        # 5) Rebuild keyword graph with NO weights and NO salience
        # ----------------------------------------------------------
        logger.info(
            "PlainGraph ablation: building keyword graph with "
            "use_post_weights=False, use_salience=False ..."
        )

        build_and_save_keyword_graph(
            paths_config=paths_config,
            use_post_weights=False,
            use_salience=False,
        )

        logger.info("PlainGraph ablation: keyword graph rebuilt.")

        # ----------------------------------------------------------
        # 6) Train model using plain graph
        # ----------------------------------------------------------
        logger.info("PlainGraph ablation: starting training...")
        train_model(paths_config=paths_config)
        logger.info("PlainGraph ablation: training finished.")

        # ----------------------------------------------------------
        # 7) Evaluate with tag (e.g. 'plainGraph')
        # ----------------------------------------------------------
        logger.info("PlainGraph ablation: starting evaluation...")
        evaluate_full_model(
            paths_config=paths_config,
            top_m=top_m,
            tag=tag,
        )
        logger.info("PlainGraph ablation: evaluation finished.")

    finally:
        # ----------------------------------------------------------
        # 8) Restore original paths.yaml
        # ----------------------------------------------------------
        with paths_cfg_path.open("w", encoding="utf-8") as f:
            f.write(original_text)

        logger.info("PlainGraph ablation: restored original configs/paths.yaml")
        logger.info("Finished: Plain co-occurrence graph ablation")
