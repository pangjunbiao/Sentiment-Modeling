# src/experiments/ablations/run_no_weights.py

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict

import yaml

from src.data_pipeline.combine_cities import load_paths
from src.graph.keyword_graph import build_and_save_keyword_graph
from src.model.trainer import train_model
from src.evaluation.report import evaluate_full_model

logger = logging.getLogger(__name__)


def run_no_weights_ablation(
    paths_config: str = "configs/paths.yaml",
    ablation_config: str = "configs/experiments_ablation.yaml",
    top_m: int = 10,
) -> None:
    """
    No-Influence-Weights ablation for the PDF model.

    In the *full* model:
      - The keyword graph W_ij already includes post influence weights w_p
        (and salience s_i s_j) when we build it.

    For this ablation we want:
      - Same pipeline, same salience,
      - BUT graph W built *without* influence weights (effectively w_p = 1).

    Implementation:
      1) Backup the current graph file (full model W with weights).
      2) Rebuild W with use_post_weights = False (but keep salience ON).
      3) Train the model normally on this new W.
      4) Evaluate topic quality with a tag (e.g. "noWeights").
      5) Restore the original graph file so the full model is unaffected.
    """

    logger.info("Starting: No-weights ablation (build W without influence weights)")

    # --------------------------------------------------------------
    # 1) Load ablation tag from experiments_ablation.yaml (optional)
    # --------------------------------------------------------------
    tag = "noWeights"
    abl_path = Path(ablation_config)

    if abl_path.exists():
        try:
            with abl_path.open("r", encoding="utf-8") as f:
                ab_cfg = yaml.safe_load(f) or {}
            abl_info: Dict[str, Any] = (ab_cfg.get("ablations") or {}).get(
                "no_weights", {}
            )
            tag = abl_info.get("tag", tag)
        except Exception as e:
            logger.warning(
                "Could not read experiments_ablation.yaml (%s). "
                "Using default tag '%s'.",
                e,
                tag,
            )

    # --------------------------------------------------------------
    # 2) Locate graph file and back it up
    # --------------------------------------------------------------
    data_paths = load_paths(paths_config)
    graph_path = Path(data_paths["graph_path"])

    if not graph_path.exists():
        raise FileNotFoundError(
            f"Keyword graph adjacency not found at: {graph_path}. "
            f"Run the 'keyword_graph' stage for the full model first."
        )

    backup_graph_path = graph_path.with_name(graph_path.stem + "_backup_full_model.npz")

    logger.info("Backing up full-model graph from %s to %s", graph_path, backup_graph_path)
    graph_path.replace(backup_graph_path)

    try:
        # ----------------------------------------------------------
        # 3) Rebuild W with NO influence weights (w_p = 1)
        #    but keep salience as in the methodology.
        # ----------------------------------------------------------
        logger.info(
            "Rebuilding keyword graph WITHOUT influence weights "
            "(use_post_weights=False, use_salience=True) ..."
        )

        build_and_save_keyword_graph(
            paths_config=paths_config,
            use_post_weights=False,   # <-- this is the actual ablation
            use_salience=True,        # keep salience; only weights are removed
        )

        if not graph_path.exists():
            raise FileNotFoundError(
                f"No-weights graph was not created at: {graph_path}"
            )

        logger.info("No-weights graph built and saved to: %s", graph_path)

        # ----------------------------------------------------------
        # 4) Train model on the new (no-weights) graph
        # ----------------------------------------------------------
        logger.info("No-weights ablation: starting training...")
        train_model(paths_config=paths_config)
        logger.info("No-weights ablation: training finished.")

        # ----------------------------------------------------------
        # 5) Evaluate model and tag outputs as 'noWeights'
        # ----------------------------------------------------------
        logger.info("No-weights ablation: starting evaluation...")
        evaluate_full_model(
            paths_config=paths_config,
            top_m=top_m,
            tag=tag,  # e.g. "noWeights"
        )
        logger.info("No-weights ablation: evaluation finished.")

    finally:
        # ----------------------------------------------------------
        # 6) Restore original (full-model) graph
        # ----------------------------------------------------------
        if backup_graph_path.exists():
            logger.info(
                "Restoring original full-model graph from %s to %s",
                backup_graph_path,
                graph_path,
            )
            # Replace the no-weights graph with the backup
            if graph_path.exists():
                graph_path.unlink()
            backup_graph_path.replace(graph_path)

        logger.info("Finished: No-weights ablation (original graph restored)")
