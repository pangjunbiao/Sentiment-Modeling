# src/graph/salience.py

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict

import numpy as np

from src.data_pipeline.combine_cities import load_paths


def _load_vocab_and_freq(vocab_path: Path) -> Dict[str, np.ndarray]:
    """
    Load vocabulary JSON and return:
      - token_to_id : mapping token -> index
      - freqs       : np.ndarray of shape (V,), corpus frequency per token index

    Expects vocab.json structure:
    {
      "token_to_id": { "<token>": <id>, ... },
      "id_to_token": [ "<token0>", "<token1>", ... ],
      "freq": { "<token>": <frequency>, ... }
    }

    If 'freq' is missing, we fall back to uniform frequencies.
    """
    if not vocab_path.exists():
        raise FileNotFoundError(f"Vocabulary file not found: {vocab_path}")

    with vocab_path.open("r", encoding="utf-8") as f:
        vocab_obj = json.load(f)

    token_to_id: Dict[str, int] = vocab_obj.get("token_to_id", {})
    if not token_to_id:
        raise ValueError(f"No 'token_to_id' found in vocab JSON: {vocab_path}")

    V = len(token_to_id)
    freqs = np.zeros(V, dtype=np.float64)

    freq_dict = vocab_obj.get("freq", {})
    if not freq_dict:
        # Fallback: uniform frequencies if none provided
        freqs[:] = 1.0
        return {"token_to_id": token_to_id, "freqs": freqs}

    for tok, idx in token_to_id.items():
        f_val = freq_dict.get(tok, 0.0)
        try:
            freqs[idx] = float(f_val)
        except Exception:
            freqs[idx] = 0.0

    return {"token_to_id": token_to_id, "freqs": freqs}


def compute_and_save_salience(
    paths_config: str = "configs/paths.yaml",
    method: str = "idf",
    normalize: bool = True,
    cap_percentile: float = 95.0,
) -> None:
    """
    Compute salience scores s_i for each vocabulary term, matching the
    methodology's idea of "capped IDF / domain-prior boost".

    Default method: 'idf'

      - Load vocab frequencies from vocab.json.
      - Let f_i be the corpus frequency of term i (>= 0).
      - Define an IDF-like score:
            f_i_clamped = max(f_i, 1)
            f_max       = max_i f_i_clamped
            raw_i       = log(1 + f_max / f_i_clamped)
        So:
          * very frequent terms -> small salience
          * rarer terms        -> larger salience

      - Optionally cap at a given percentile (e.g. 95th) to avoid
        extremely large values for ultra-rare tokens (capped IDF).
      - Optionally normalize to [0, 1] by dividing by max(raw_i).

    The resulting vector s (length V) is then used in the keyword graph:

        ω(i,j) = s_i s_j sum_p w_p δ^{(p)}_{ij}.

    Parameters
    ----------
    paths_config : str
        Path to paths.yaml.
    method : str
        'idf' (default) or 'degree' (experimental).
        For strict methodology alignment, use 'idf'.
    normalize : bool
        If True, rescale salience to [0, 1].
    cap_percentile : float
        Percentile for capping IDF-like scores (only for method='idf').
    """
    data_paths: Dict[str, str] = load_paths(paths_config)

    # Handle both "vocab_json" and "vocab_path" keys
    if "vocab_json" in data_paths:
        vocab_path = Path(data_paths["vocab_json"])
    else:
        vocab_path = Path(data_paths["vocab_path"])

    salience_path = Path(data_paths["salience_scores"])
    salience_path.parent.mkdir(parents=True, exist_ok=True)

    print(f"[Salience] Loading vocabulary from: {vocab_path}")
    vocab_info = _load_vocab_and_freq(vocab_path)
    # s_i salience score (IDF-like).
    # f_clamped = max(freq_i, 1); f_max = max_i f_clamped.
    # Computes: s_i = log(1 + f_max / f_i), boosting rare/domain words
    # and down-weighting common background terms. Optional percentile cap
    # implements the “capped IDF” described in the methodology.

    freqs = vocab_info["freqs"]
    V = freqs.shape[0]

    method = method.lower().strip()

    if method == "idf":
        # ----- IDF-like salience (recommended, matches methodology) -----
        # Ensure strictly positive frequencies
        f_clamped = np.maximum(freqs, 1.0)
        f_max = float(f_clamped.max())

        # raw_i = log(1 + f_max / f_i)
        raw_scores = np.log1p(f_max / f_clamped)

        # Optional capping: capped IDF
        if cap_percentile is not None and 0.0 < cap_percentile < 100.0:
            cap_val = float(np.percentile(raw_scores, cap_percentile))
            raw_scores = np.minimum(raw_scores, cap_val)

        # s ∈ ℝ⁺ᴱ : final salience vector (s₁,…,s_V) used in ω(i,j).
        scores = raw_scores.astype(np.float32)

    elif method == "degree":
        # ----- Optional: degree-based salience from an existing graph -----
        # NOTE: this requires that the keyword graph has already been built.
        from scipy.sparse import load_npz, csr_matrix

        graph_path = Path(data_paths["graph_path"])
        if not graph_path.exists():
            raise FileNotFoundError(
                f"[Salience] method='degree' requires an existing graph at {graph_path}. "
                f"Run the keyword_graph stage first or use method='idf'."
            )

        print(f"[Salience] Loading keyword graph from: {graph_path}")
        adj: csr_matrix = load_npz(graph_path).tocsr()
        if adj.shape[0] != V:
            raise ValueError(
                f"[Salience] Graph vocab size {adj.shape[0]} does not match "
                f"vocab size {V} from vocab."
            )
        scores = np.array(adj.sum(axis=1)).ravel().astype(np.float32)
        scores = np.maximum(scores, 0.0)

    else:
        raise ValueError(f"Unknown salience method: {method}")

    # Avoid all-zero vectors; enforce tiny epsilon
    eps = 1e-12
    scores = np.maximum(scores, eps)

    if normalize:
        max_val = float(scores.max())
        if max_val > 0:
            scores = scores / max_val

    np.save(salience_path, scores)
    print(f"[Salience] Saved salience scores to: {salience_path}")
    print(
        f"[Salience] Salience stats: min={scores.min():.6e}, "
        f"max={scores.max():.6e}, mean={scores.mean():.6e}"
    )

    # Save metadata
    meta = {
        "vocab_path": str(vocab_path),
        "salience_path": str(salience_path),
        "vocab_size": int(V),
        "method": method,
        "normalize": bool(normalize),
        "cap_percentile": float(cap_percentile) if method == "idf" else None,
        "min": float(scores.min()),
        "max": float(scores.max()),
        "mean": float(scores.mean()),
    }

    meta_path = salience_path.parent / "keyword_salience_meta.json"
    with meta_path.open("w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)

    print(f"[Salience] Saved salience metadata to: {meta_path}")
    print("[Salience] Done.\n")
