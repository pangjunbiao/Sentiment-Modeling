# src/data_pipeline/combine_cities.py

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Dict

import pandas as pd
import yaml


def load_paths(config_path: str = "configs/paths.yaml") -> Dict[str, str]:
    """
    Load path configuration from a YAML file.

    Expected structure in paths.yaml:

    data:
      raw_dir: data/raw
      beijing_csv: data/raw/beijing.csv
      shanghai_csv: data/raw/shanghai.csv
      xiamen_csv: data/raw/xiamen.csv
      combined_raw: data/raw/all_cities.csv
    """
    config_file = Path(config_path)
    if not config_file.exists():
        raise FileNotFoundError(f"Config file not found: {config_file}")

    with config_file.open("r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    if "data" not in cfg:
        raise KeyError("paths.yaml must have a top-level 'data' key.")

    return cfg["data"]


def read_city_csv(path: Path, city_name: str) -> pd.DataFrame:
    """
    Robust CSV reader that automatically handles Chinese encodings.

    Strategy:
    1) Try normal encodings (UTF-8, GBK, GB2312).
       - Accept only if we see the expected Chinese column names.
    2) If that fails (e.g., Xiamen), fall back to:
       - Read as latin1 (no error),
       - Then "repair" mojibake by re-decoding strings via latin1->gbk.

    This ensures that even a weirdly encoded file like xiamen.csv
    ends up with the same clean columns as Beijing/Shanghai.
    """
    if not path.exists():
        raise FileNotFoundError(f"City CSV not found: {path}")

    # Columns that *must* be present for us to accept an encoding
    required_cols = ["序号", "昵称", "博主id", "发布时间", "粉丝数", "点赞", "评论数", "正文"]

    # 1) Try standard encodings first
    normal_encodings = ["utf-8-sig", "utf-8", "gbk", "gb2312"]
    for enc in normal_encodings:
        try:
            print(f"Trying encoding: {enc} for {path.name}")
            df = pd.read_csv(path, encoding=enc)
        except Exception as e:
            print(f"  -> Failed with encoding {enc}: {e}")
            continue

        ok_cols = sum(col in df.columns for col in required_cols)
        if ok_cols >= 5:
            print(f"Successfully loaded {path.name} with encoding: {enc}")
            df["city"] = city_name
            return df
        else:
            print(
                f"  -> Encoding {enc} loaded file but header does not match "
                f"expected columns (only {ok_cols} / {len(required_cols)} matched)."
            )

    # 2) Fallback: latin1 + gbk "repair" (for files like xiamen.csv)
    print(
        f"No standard encoding worked cleanly for {path.name}. "
        f"Trying latin1 + gbk mojibake repair..."
    )
    try:
        df = pd.read_csv(path, encoding="latin1")
    except Exception as e:
        raise ValueError(
            f"Could not decode file {path} even with latin1: {e}"
        )

    def fix_mojibake(val):
        if not isinstance(val, str):
            return val
        try:
            # Interpret current text as latin1 bytes, then decode as gbk
            return val.encode("latin1").decode("gbk")
        except Exception:
            # If anything fails, return original string
            return val

    # Fix column names
    df.columns = [fix_mojibake(c) for c in df.columns]

    # Fix all object columns
    for col in df.columns:
        if df[col].dtype == object:
            df[col] = df[col].map(fix_mojibake)

    # Check again that we now have the right header
    ok_cols = sum(col in df.columns for col in required_cols)
    if ok_cols >= 5:
        print(
            f"Successfully repaired {path.name} via latin1->gbk; "
            f"recognized key columns."
        )
        df["city"] = city_name
        return df

    # If still not good, give up with a clear error
    raise ValueError(
        f"Could not decode file {path} with a valid encoding that yields "
        f"expected Chinese column names, even after latin1->gbk repair."
    )

def combine_raw_city_csvs(
    beijing_path: str,
    shanghai_path: str,
    xiamen_path: str,
    output_path: str,
) -> None:
    """
    Combine Beijing, Shanghai, and Xiamen raw CSVs into a single CSV
    with a 'city' column.

    This is the first step of the pipeline, producing all_cities.csv
    that later preprocessing will consume.
    """
    beijing_csv = Path(beijing_path)
    shanghai_csv = Path(shanghai_path)
    xiamen_csv = Path(xiamen_path)
    out_csv = Path(output_path)

    beijing_df = read_city_csv(beijing_csv, city_name="beijing")
    shanghai_df = read_city_csv(shanghai_csv, city_name="shanghai")
    xiamen_df = read_city_csv(xiamen_csv, city_name="xiamen")

    combined = pd.concat(
        [beijing_df, shanghai_df, xiamen_df],
        axis=0,
        ignore_index=True,
        sort=False,  # keep existing column order where possible
    )

    out_csv.parent.mkdir(parents=True, exist_ok=True)
    combined.to_csv(out_csv, index=False, encoding="utf-8-sig")

    print(
        f"Combined CSV written to: {out_csv} "
        f"(rows: {len(combined)}, columns: {len(combined.columns)})"
    )


def parse_args() -> argparse.Namespace:
    """
    Optional CLI so you can run this file directly if needed:

    python -m src.data_pipeline.combine_cities
    or
    python src/data_pipeline/combine_cities.py
    """
    parser = argparse.ArgumentParser(
        description="Combine city-level Weibo CSVs into a single all_cities.csv"
    )
    parser.add_argument(
        "--config",
        type=str,
        default="configs/paths.yaml",
        help="Path to YAML file containing data paths.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    data_paths = load_paths(args.config)

    combine_raw_city_csvs(
        beijing_path=data_paths["beijing_csv"],
        shanghai_path=data_paths["shanghai_csv"],
        xiamen_path=data_paths["xiamen_csv"],
        output_path=data_paths["combined_raw"],
    )


if __name__ == "__main__":
    main()
