# src/data_pipeline/vocab_builder.py

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Dict, List

import pandas as pd
from src.data_pipeline.combine_cities import load_paths

# Jieba
try:
    import jieba
except ImportError:
    raise ImportError("Install jieba: pip install jieba")


# -------------------------------------------------------------
# 1. EXTENDED STOPWORD LIST (VERY IMPORTANT)
# -------------------------------------------------------------

# Chinese function words that destroy topics if not removed
CHINESE_STOPWORDS = set([
    "的", "了", "在", "是", "我", "你", "他", "她", "它", "也", "和", "或", "被", "有",
    "这", "那", "就", "都", "很", "还", "呢", "嘛", "啊", "哦", "呀",
    "一个", "没有", "不是", "什么",
])

# Punctuation tokens to remove
PUNCT_TOKENS = set([
    "，","。","、","！","？","；","：","《","》","（","）","“","”","…","—","-","~",
    ",",".","!","?",";",":","(",")","[","]","{","}",
])


def _is_bad_token(tok: str) -> bool:
    """
    Returns True if token should be removed:
        - punctuation
        - function words
        - whitespace
    """
    if not tok:
        return True
    if tok in PUNCT_TOKENS:
        return True
    if tok in CHINESE_STOPWORDS:
        return True
    if tok.strip() == "":
        return True
    return False


# -------------------------------------------------------------
# 2. Tokenizer
# -------------------------------------------------------------
def _tokenize_text(text: str) -> List[str]:
    """
    Tokenize Chinese text using jieba with the following improvements:
        - lowercase
        - remove punctuation tokens
        - remove stopwords
        - remove empty tokens
    """
    if not isinstance(text, str):
        return []

    text = text.strip().lower()
    if not text:
        return []

    tokens = jieba.lcut(text)
    cleaned = []
    for tok in tokens:
        tok = tok.strip()
        if _is_bad_token(tok):
            continue
        cleaned.append(tok)

    return cleaned


# -------------------------------------------------------------
# 3. Build Vocabulary with stopword removal
# -------------------------------------------------------------
def _build_vocabulary(
    all_token_lists: List[List[str]],
    min_freq: int = 3,
    max_vocab_size: int | None = None,
) -> Dict[str, int]:

    counter = Counter()
    for tokens in all_token_lists:
        counter.update(tokens)

    # Remove tokens with freq < min_freq
    items = [(tok, freq) for tok, freq in counter.items() if freq >= min_freq]

    # Sort frequency desc, then lexicographically
    items.sort(key=lambda x: (-x[1], x[0]))

    if max_vocab_size is not None:
        items = items[:max_vocab_size]

    vocab = {tok: idx for idx, (tok, _) in enumerate(items)}
    return vocab


# -------------------------------------------------------------
# 4. Main builder
# -------------------------------------------------------------
def build_and_save_vocab_and_tokens(
    paths_config: str = "configs/paths.yaml",
    min_freq: int = 3,
    max_vocab_size: int | None = None,
) -> None:

    data_paths: Dict[str, str] = load_paths(paths_config)

    clean_path = Path(data_paths["clean_combined"])
    if not clean_path.exists():
        raise FileNotFoundError(
            f"Cleaned combined file not found: {clean_path}. "
            f"Run the preprocess stage first."
        )

    print(f"[Vocab] Loading cleaned dataset: {clean_path}")
    df = pd.read_csv(clean_path, encoding="utf-8-sig")

    if "正文" not in df.columns:
        raise ValueError("Column '正文' not found in cleaned data")

    # ---------------------------------------------------------
    # 4.1 Tokenization
    # ---------------------------------------------------------
    print("[Vocab] Tokenizing posts with enhanced cleaning...")
    all_token_lists = []
    for text in df["正文"]:
        toks = _tokenize_text(text)
        all_token_lists.append(toks)

    # ---------------------------------------------------------
    # 4.2 Vocabulary
    # ---------------------------------------------------------
    print("[Vocab] Building vocabulary with stopword removal...")

    vocab = _build_vocabulary(
        all_token_lists=all_token_lists,
        min_freq=min_freq,
        max_vocab_size=max_vocab_size,
    )

    # Frequencies for inspection
    freq_counter = Counter()
    for tokens in all_token_lists:
        freq_counter.update(tokens)

    vocab_items = []
    for tok, tok_id in vocab.items():
        freq = freq_counter.get(tok, 0)
        vocab_items.append((tok_id, tok, freq))

    vocab_items.sort(key=lambda x: x[0])

    # ---------------------------------------------------------
    # 4.3 Paths
    # ---------------------------------------------------------
    vocab_path = Path(data_paths["vocab_path"])
    vocab_stats_path = Path(data_paths["vocab_stats"])
    tokens_dir = Path(data_paths["tokens_dir"])
    tokens_dir.mkdir(parents=True, exist_ok=True)
    tokens_csv_path = tokens_dir / "post_tokens.csv"

    # Save vocab.json
    print(f"[Vocab] Saving vocab to: {vocab_path}")
    vocab_path.parent.mkdir(parents=True, exist_ok=True)

    vocab_json = {
        "token_to_id": {tok: i for tok, i in vocab.items()},
        "id_to_token": [tok for _, tok, _ in vocab_items],
        "freq": {tok: freq_counter.get(tok, 0) for tok in vocab},
    }

    with vocab_path.open("w", encoding="utf-8") as f:
        json.dump(vocab_json, f, ensure_ascii=False, indent=2)

    # Save stats
    print(f"[Vocab] Saving vocab stats to: {vocab_stats_path}")
    df_vocab_stats = pd.DataFrame(
        {
            "token_id": [vid for vid, _, _ in vocab_items],
            "token": [tok for _, tok, _ in vocab_items],
            "frequency": [freq for _, _, freq in vocab_items],
        }
    )
    vocab_stats_path.parent.mkdir(parents=True, exist_ok=True)
    df_vocab_stats.to_csv(vocab_stats_path, index=False, encoding="utf-8-sig")

    # Save per-post tokenization
    print(f"[Vocab] Saving tokenized posts to: {tokens_csv_path}")
    tokens_str_list = [" ".join(toks) for toks in all_token_lists]

    df_tokens = pd.DataFrame(
        {
            "doc_index": list(range(len(df))),
            "city": df.get("city", pd.Series([""] * len(df))),
            "博主id": df.get("博主id", pd.Series([""] * len(df))),
            "tokens": tokens_str_list,
        }
    )
    df_tokens.to_csv(tokens_csv_path, index=False, encoding="utf-8-sig")

    print(f"[Vocab] Done. Vocabulary size = {len(vocab)}, posts tokenized = {len(df_tokens)}\n")
