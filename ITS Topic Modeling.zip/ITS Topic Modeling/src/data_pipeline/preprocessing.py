# src/data_pipeline/preprocessing.py

from __future__ import annotations

import ast
import re
from pathlib import Path
from typing import Dict, List

import pandas as pd

from src.data_pipeline.combine_cities import load_paths
from src.data_pipeline.loader import load_all_cities


# Columns we want to keep and use going forward
PREFERRED_COLUMNS: List[str] = [
    "序号",          # index within city (can be useful but not critical)
    "city",         # added in combine_cities.py
    "博主id",        # user ID
    "昵称",          # nickname
    "用户介绍",        # user bio
    "微博认证",        # verification / role
    "发布时间",        # post time
    "影响力",         # platform influence score (optional but nice)
    "粉丝数",         # followers
    "关注",          # following count
    "点赞",          # likes
    "评论数",         # total comment count
    "正文",          # main text (we will clean this)
    "评论",          # comments list (string-encoded list; kept for later)
    "24小时内评论",      # comments within 24 hours
    "评论时间列表",       # comment timestamps (string-encoded list)
]


_WHITESPACE_RE = re.compile(r"\s+")


def _normalize_whitespace(text: str) -> str:
    """
    Collapse all whitespace (spaces, tabs, newlines) into single spaces
    and strip leading/trailing spaces.
    """
    return _WHITESPACE_RE.sub(" ", text).strip()


def _clean_main_text(raw_value) -> str:
    """
    Clean the '正文' field into a plain text string.

    In some files, 正文 may appear as a Python list-like string: "['text']".
    We try to parse it safely; if it is a list, we join elements into a single string.
    Otherwise, we fall back to a simple string cleanup.

    Extra steps:
      - Normalize whitespace (remove \n, \r, \t and collapse multiple spaces).
      - Strip outer brackets/quotes if the value looks like "[xxx]" from Excel.
    """
    if pd.isna(raw_value):
        return ""

    s = str(raw_value).strip()

    if not s or s.lower() == "nan":
        return ""

    # Try to parse as a Python literal list, e.g. "['text1', 'text2']"
    if s.startswith("[") and s.endswith("]"):
        try:
            obj = ast.literal_eval(s)
            if isinstance(obj, list):
                # Join list elements into one string with spaces
                joined = " ".join(str(x).strip() for x in obj if x is not None)
                return _normalize_whitespace(joined)
        except Exception:
            # If parsing fails, fall through to fallback cleaning
            pass

    # Fallback: just return the raw string, but strip outer brackets/quotes
    s = s.strip("[]\"'")  # remove stray [] and quotes that sometimes appear
    s = _normalize_whitespace(s)
    return s


def clean_all_cities_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """
    Clean and standardize the combined dataset:

    - Keep only preferred columns (drop garbled duplicate columns).
    - Ensure numeric columns are numeric and non-NaN (fill with 0).
    - Parse 发布时间 as datetime.
    - Clean 正文 into plain text (remove list wrappers, normalize whitespace).
    - Drop rows with completely empty 正文 (they cannot contribute to the graph).

    This prepares the data for influence weighting and graph construction.
    """
    # Keep only the columns we care about and that actually exist
    present_cols = [col for col in PREFERRED_COLUMNS if col in df.columns]
    missing_preferred = [col for col in PREFERRED_COLUMNS if col not in df.columns]

    if missing_preferred:
        print(
            "[Preprocess] [WARNING] Some preferred columns are missing and will be skipped: "
            + ", ".join(missing_preferred)
        )

    cleaned = df[present_cols].copy()

    # Ensure city is string
    if "city" in cleaned.columns:
        cleaned["city"] = cleaned["city"].astype(str)

    # Numeric columns to enforce as integers
    numeric_cols = ["序号", "粉丝数", "关注", "点赞", "评论数"]
    for col in numeric_cols:
        if col in cleaned.columns:
            cleaned[col] = (
                pd.to_numeric(cleaned[col], errors="coerce")
                .fillna(0)
                .astype(int)
            )

    # Parse 发布时间 as datetime
    if "发布时间" in cleaned.columns:
        cleaned["发布时间"] = pd.to_datetime(cleaned["发布时间"], errors="coerce")

    # Clean 正文 into plain text
    if "正文" in cleaned.columns:
        cleaned["正文"] = cleaned["正文"].fillna("").apply(_clean_main_text)

        # Drop rows where the cleaned main text is completely empty
        before = cleaned.shape[0]
        cleaned = cleaned[cleaned["正文"].str.len() > 0].copy()
        after = cleaned.shape[0]
        dropped = before - after
        if dropped > 0:
            print(f"[Preprocess] Dropped {dropped} rows with empty main text.")

    return cleaned


def preprocess_and_save(paths_config: str = "configs/paths.yaml") -> None:
    """
    High-level preprocessing function:

    - Load all_cities.csv (combined raw).
    - Clean and standardize the DataFrame.
    - Save cleaned CSV to data/processed/all_cities_clean.csv (or as configured).
    """
    data_paths: Dict[str, str] = load_paths(paths_config)

    # Load combined raw dataset
    df_raw = load_all_cities(paths_config)

    print("\n[Preprocess] Cleaning combined dataset...")
    df_clean = clean_all_cities_dataframe(df_raw)

    # Output path for cleaned CSV
    clean_path = Path(data_paths["clean_combined"])
    clean_path.parent.mkdir(parents=True, exist_ok=True)

    # Save as UTF-8 with BOM to be safe for Windows + Chinese
    df_clean.to_csv(clean_path, index=False, encoding="utf-8-sig")

    print(
        f"[Preprocess] Cleaned dataset saved to: {clean_path} "
        f"(rows: {df_clean.shape[0]}, columns: {df_clean.shape[1]})"
    )

    # Optionally, show a tiny summary
    print("\n[Preprocess] Sample of cleaned data (first 3 rows):")
    print(df_clean.head(3))
    print("[Preprocess] Done.\n")
