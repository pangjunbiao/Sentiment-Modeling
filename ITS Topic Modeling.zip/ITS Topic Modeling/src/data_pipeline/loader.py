# src/data_pipeline/loader.py

from __future__ import annotations

from pathlib import Path
from typing import List, Dict

import pandas as pd

from src.data_pipeline.combine_cities import load_paths


# Core columns that are required for your methodology
CORE_COLUMNS: List[str] = [
    "city",          # added in combine_cities.py
    "博主id",         # user ID
    "昵称",           # nickname
    "粉丝数",         # followers
    "点赞",           # likes
    "评论数",         # total comment count
    "发布时间",         # post time
    "正文",           # main text
    "评论",           # comments list (string-encoded list)
    "评论时间列表",       # comment timestamps (string-encoded list)
]

# Optional but useful columns; we warn if they are missing but do not fail.
OPTIONAL_COLUMNS: List[str] = [
    "影响力",
    "微博认证",
    "用户介绍",
    "24小时内评论",
]


def load_all_cities(paths_config: str = "configs/paths.yaml") -> pd.DataFrame:
    """
    Load the combined all_cities.csv produced by combine_cities.py.

    - Uses paths from configs/paths.yaml.
    - Ensures required columns for the methodology are present.
    """
    data_paths: Dict[str, str] = load_paths(paths_config)
    combined_path = Path(data_paths["combined_raw"])

    if not combined_path.exists():
        raise FileNotFoundError(
            f"Combined raw file not found: {combined_path}. "
            f"Run the 'combine_cities' stage first."
        )

    # We saved all_cities.csv as UTF-8 with BOM in combine_cities.py
    df = pd.read_csv(combined_path, encoding="utf-8-sig")

    # Check core columns
    missing_core = [col for col in CORE_COLUMNS if col not in df.columns]
    if missing_core:
        raise ValueError(
            "The combined dataset is missing required columns: "
            + ", ".join(missing_core)
        )

    # Warn if optional columns are missing
    missing_optional = [col for col in OPTIONAL_COLUMNS if col not in df.columns]
    if missing_optional:
        print(
            "[WARNING] The combined dataset is missing some optional columns: "
            + ", ".join(missing_optional)
        )

    return df


def summarize_raw_dataframe(df: pd.DataFrame) -> None:
    """
    Print a brief summary of the combined raw dataset.
    This is just for sanity checking after loading.
    """
    print("\n=== Combined Raw Dataset Summary ===")
    print(f"Shape: {df.shape[0]} rows x {df.shape[1]} columns")

    # City distribution
    if "city" in df.columns:
        print("\nPosts per city:")
        print(df["city"].value_counts())

    # Show a few column names
    print("\nColumns:")
    print(list(df.columns))

    # Quick look at numeric engagement stats
    for col in ["粉丝数", "点赞", "评论数"]:
        if col in df.columns:
            # convert to numeric robustly for description
            numeric_series = pd.to_numeric(df[col], errors="coerce")
            print(f"\nDescriptive stats for {col}:")
            print(numeric_series.describe())

    print("\nFirst 3 rows (truncated):")
    print(df.head(3))
    print("====================================\n")
