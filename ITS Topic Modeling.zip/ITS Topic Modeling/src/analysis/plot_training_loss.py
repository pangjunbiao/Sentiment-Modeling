# src/analysis/plot_training_loss.py

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from src.data_pipeline.combine_cities import load_paths


def plot_training_loss(
    paths_config: str = "configs/paths.yaml",
    drop_outliers: bool = True,
    outlier_factor: float = 10.0,
) -> Path:
    """
    Plot training loss curves in a cleaner, paper-style format.

    - Reads training_loss.csv.
    - Optionally removes extreme outliers (e.g., the first huge iteration).
    - Figure has TWO subplots:
        (1) total loss + data term
        (2) decor term only
    - Saves PNG next to the CSV.

    Returns:
        Path to the saved PNG.
    """
    data_paths = load_paths(paths_config)
    csv_path = Path(data_paths["training_log_csv"])

    if not csv_path.exists():
        raise FileNotFoundError(
            f"Training loss CSV not found at: {csv_path}. "
            f"Run the train_model stage first."
        )

    df = pd.read_csv(csv_path)

    required_cols = {"iter", "total", "data", "decor_scaled"}
    if not required_cols.issubset(df.columns):
        raise ValueError(
            f"training_loss.csv at {csv_path} is missing columns. "
            f"Expected at least: {required_cols}, got: {set(df.columns)}"
        )

    df_plot = df.copy()

    # Drop extreme outliers so early spikes don't ruin the scale
    if drop_outliers:
        median_total = df_plot["total"].median()
        thresh = outlier_factor * median_total
        mask = df_plot["total"] <= thresh
        dropped = (~mask).sum()
        if dropped > 0:
            print(
                f"[Plot] Dropping {dropped} outlier rows with "
                f"total > {thresh:.2f} (median={median_total:.2f})."
            )
        df_plot = df_plot[mask]
        if df_plot.empty:
            print("[Plot] All rows dropped as outliers; using full data instead.")
            df_plot = df

    png_path = csv_path.with_suffix(".png")

    # --------- Make a 2-row figure ---------
    fig, axes = plt.subplots(2, 1, sharex=True, figsize=(8, 6))

    # (1) total + data in the top subplot
    ax0 = axes[0]
    ax0.plot(df_plot["iter"], df_plot["total"], label="total loss")
    ax0.plot(df_plot["iter"], df_plot["data"], label="data term")
    ax0.set_ylabel("Loss value")
    ax0.set_title("Training loss (total & data)")
    ax0.grid(True)
    ax0.legend()

    # (2) decor term in the bottom subplot
    ax1 = axes[1]
    ax1.plot(df_plot["iter"], df_plot["decor_scaled"], label="decor term")
    ax1.set_xlabel("Iteration")
    ax1.set_ylabel("Loss value")
    ax1.set_title("Decorrelation penalty")
    ax1.grid(True)
    ax1.legend()

    plt.tight_layout()
    fig.savefig(png_path, dpi=150)
    plt.close(fig)

    print(f"[Plot] Saved training loss curve to: {png_path}")
    return png_path
