# src/utils/logging_utils.py

from __future__ import annotations

import logging
from pathlib import Path


def setup_logging(
    log_dir: str = "logs",
    log_name: str = "pipeline.log",
    level: int = logging.INFO,
) -> None:
    """
    Configure logging to write both to console and to a log file.

    Log format example:
        2025-01-01 12:34:56 | INFO | main | Starting stage: all
    """
    Path(log_dir).mkdir(parents=True, exist_ok=True)
    log_path = Path(log_dir) / log_name

    log_format = "%(asctime)s | %(levelname)s | %(name)s | %(message)s"

    # Clear existing handlers (important if main.py is re-run in the same process)
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)

    logging.basicConfig(
        level=level,
        format=log_format,
        handlers=[
            logging.FileHandler(log_path, encoding="utf-8"),
            logging.StreamHandler(),
        ],
    )

    logging.getLogger(__name__).info(f"Logging initialized. Log file: {log_path}")
