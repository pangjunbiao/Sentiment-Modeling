# src/evaluation/topic_sharpness.py

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Iterable, Tuple, Any

import numpy as np
import pandas as pd
import yaml  # NEW: to read model.num_topics

from src.data_pipeline.combine_cities import load_paths
from src.evaluation.topics_io import load_final_H


def _compute_topic_sharpness(
    H: np.ndarray,
    top_ms: Iterable[int] = (10, 25),
    eps: float = 1e-12,
) -> Dict[str, Any]:
    """
    Compute topic sharpness statistics from the topic-word matrix H.

    Parameters
    ----------
    H : np.ndarray
        Topic-word matrix of shape (K, V), where each row corresponds to a topic
        and each column to a vocabulary term. If the input H is (V, K), it
        should be transposed before calling this function.
    top_ms : iterable of int
        Values of m for which we compute the cumulative probability mass of
        the top-m words in each topic.
    eps : float
        Small constant for numerical stability in log computations.

    Returns
    -------
    stats : dict
        {
          "K": int,
          "V": int,
          "entropy": List[float],              # per-topic entropy
          "top_mass": Dict[m, List[float]],   # per-topic top-m mass
          "mean_entropy": float,
          "mean_top_mass": Dict[m, float],
        }
    """
    K, V = H.shape
    top_ms = list(top_ms)

    # Normalize each topic-row to a probability distribution over words
    row_sums = H.sum(axis=1, keepdims=True)
    # Avoid division by zero: if a row is all zeros, make it uniform
    zero_rows = (row_sums <= 0)
    row_sums[zero_rows] = 1.0
    P = H / row_sums  # shape (K, V)

    # Entropy per topic
    # We add eps to avoid log(0); this has negligible effect when P > 0
    entropy = -np.sum(P * np.log(P + eps), axis=1)  # shape (K,)

    # Top-m mass per topic
    top_mass: Dict[int, List[float]] = {m: [] for m in top_ms}
    for k in range(K):
        pk = P[k, :]
        # sort in descending order
        order = np.argsort(-pk)
        for m in top_ms:
            m_eff = min(m, V)
            idx_m = order[:m_eff]
            mass_m = float(pk[idx_m].sum())
            top_mass[m].append(mass_m)

    mean_entropy = float(np.mean(entropy))
    mean_top_mass = {m: float(np.mean(top_mass[m])) for m in top_ms}

    return {
        "K": int(K),
        "V": int(V),
        "entropy": entropy.tolist(),
        "top_mass": top_mass,
        "mean_entropy": mean_entropy,
        "mean_top_mass": mean_top_mass,
    }


def _ensure_topics_as_rows(
    H: np.ndarray,
    paths_config: str = "configs/paths.yaml",
) -> np.ndarray:
    """
    Ensure H has shape (K, V), with topics as rows.

    We use model.num_topics from configs/model.yaml to detect which dimension
    corresponds to K. If H is (V, K), we transpose it. If no consistent match
    is found, we fall back to the original shape (first dimension as topics).
    """
    # Default: assume current orientation is correct
    H_topics = H
    K_raw, V_raw = H.shape

    # Try to read num_topics from model.yaml
    model_cfg_path = Path("configs/model.yaml")
    K_cfg = None
    if model_cfg_path.exists():
        with model_cfg_path.open("r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f) or {}
        model_section = cfg.get("model", {})
        if "num_topics" in model_section:
            try:
                K_cfg = int(model_section["num_topics"])
            except Exception:
                K_cfg = None

    # If we have a configured K, try to align shapes
    if K_cfg is not None:
        if K_raw == K_cfg:
            # Already (K, V)
            H_topics = H
        elif V_raw == K_cfg:
            # Likely (V, K); transpose to (K, V)
            H_topics = H.T
        # else: unexpected, keep H as-is

    # If we don't have K_cfg or shapes are mismatched, we just trust H as-is.
    return H_topics


def evaluate_topic_sharpness(
    paths_config: str = "configs/paths.yaml",
    top_ms: Tuple[int, int] = (10, 25),
    tag: str | None = None,
) -> Dict[str, Any]:
    """
    Evaluate topic sharpness for the *current* trained model (whatever K is
    in configs/model.yaml) by:

      - Loading the latest saved H from the model state directory.
      - Ensuring topics correspond to rows (shape (K, V)).
      - Computing per-topic entropy and top-m mass.
      - Saving per-topic and overall statistics to CSV.
      - Returning a small dict with overall statistics.

    Parameters
    ----------
    paths_config : str
        Path to the paths.yaml config file.
    top_ms : (int, int)
        Tuple of m values, e.g. (10, 25), for top-m mass.
    tag : str or None
        Optional suffix to distinguish different experiments (e.g. "K15").
        If provided, we append "_{tag}" to the CSV filenames.

    Returns
    -------
    overall_stats : dict
        {
          "K": int,
          "mean_entropy": float,
          "mean_top10_mass": float,
          "mean_top25_mass": float,
        }
    """
    # ------------------------------------------------------------------
    # 1) Resolve paths and load H
    # ------------------------------------------------------------------
    data_paths = load_paths(paths_config)

    per_topic_base = Path(data_paths["topic_sharpness_per_topic"])
    overall_base = Path(data_paths["topic_sharpness_overall"])

    per_topic_base.parent.mkdir(parents=True, exist_ok=True)
    overall_base.parent.mkdir(parents=True, exist_ok=True)

    # If tag is provided, append it to filenames
    if tag is not None and len(tag) > 0:
        per_topic_csv = per_topic_base.with_name(
            per_topic_base.stem + f"_{tag}" + per_topic_base.suffix
        )
        overall_csv = overall_base.with_name(
            overall_base.stem + f"_{tag}" + overall_base.suffix
        )
    else:
        per_topic_csv = per_topic_base
        overall_csv = overall_base

    print("[Sharpness] Loading final H from model state...")
    H_raw = load_final_H(paths_config=paths_config)
    H = _ensure_topics_as_rows(H_raw, paths_config=paths_config)
    K, V = H.shape
    print(f"[Sharpness] H shape (topics × vocab): (K={K}, V={V})")

    # ------------------------------------------------------------------
    # 2) Compute sharpness statistics
    # ------------------------------------------------------------------
    print(f"[Sharpness] Computing entropy and top-m mass for m={top_ms} ...")
    stats = _compute_topic_sharpness(H, top_ms=top_ms)

    entropy = stats["entropy"]           # List[float], length K
    top_mass = stats["top_mass"]         # Dict[m, List[float]]
    mean_entropy = stats["mean_entropy"]
    mean_top_mass = stats["mean_top_mass"]

    # ------------------------------------------------------------------
    # 3) Save per-topic CSV
    # ------------------------------------------------------------------
    print(f"[Sharpness] Saving per-topic sharpness to: {per_topic_csv}")
    rows: List[Dict[str, Any]] = []
    for k in range(K):
        row: Dict[str, Any] = {
            "topic_id": k,
            "entropy": entropy[k],
        }
        for m in top_ms:
            row[f"top{m}_mass"] = top_mass[m][k]
        rows.append(row)

    df_topics = pd.DataFrame(rows)
    df_topics.to_csv(per_topic_csv, index=False, encoding="utf-8-sig")

    # ------------------------------------------------------------------
    # 4) Save overall CSV
    # ------------------------------------------------------------------
    print(f"[Sharpness] Saving overall sharpness summary to: {overall_csv}")
    overall_row: Dict[str, Any] = {
        "K": int(K),
        "V": int(V),
        "mean_entropy": mean_entropy,
    }
    # For convenience, create explicit columns for each m
    for m in top_ms:
        overall_row[f"mean_top{m}_mass"] = mean_top_mass[m]

    df_overall = pd.DataFrame([overall_row])
    df_overall.to_csv(overall_csv, index=False, encoding="utf-8-sig")

    # ------------------------------------------------------------------
    # 5) Print quick summary and return
    # ------------------------------------------------------------------
    print("[Sharpness] ===== Topic Sharpness Summary =====")
    print(f"[Sharpness] K               : {K}")
    print(f"[Sharpness] Mean entropy    : {mean_entropy:.4f}")
    for m in top_ms:
        print(f"[Sharpness] Mean top-{m} mass : {mean_top_mass[m]:.4f}")
    print("[Sharpness] ==================================\n")

    # Return a compact summary for possible further use
    overall_stats: Dict[str, Any] = {
        "K": int(K),
        "mean_entropy": float(mean_entropy),
    }
    # assume exactly 2 values in top_ms for naming
    if len(top_ms) >= 1:
        overall_stats[f"mean_top{top_ms[0]}_mass"] = float(mean_top_mass[top_ms[0]])
    if len(top_ms) >= 2:
        overall_stats[f"mean_top{top_ms[1]}_mass"] = float(mean_top_mass[top_ms[1]])

    return overall_stats
