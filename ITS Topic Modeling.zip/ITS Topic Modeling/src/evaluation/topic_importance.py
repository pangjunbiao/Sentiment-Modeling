# src/evaluation/topic_importance.py

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np
import pandas as pd

from src.data_pipeline.combine_cities import load_paths

logger = logging.getLogger(__name__)


def _load_final_A(paths_config: str = "configs/paths.yaml") -> np.ndarray:
    """
    Load the final diagonal topic-importance matrix A_final from the model state.

    We assume paths.yaml contains a key 'model_state_dir' pointing to the directory
    where U_final.npy, H_final.npy, A_final.npy are saved, e.g.:

        data:
          model_state_dir: data/processed/model/state
    """
    data_paths: Dict[str, str] = load_paths(paths_config)

    state_dir_key = "model_state_dir"
    if state_dir_key not in data_paths:
        raise KeyError(
            f"Key '{state_dir_key}' not found in paths.yaml. "
            f"Please add it, e.g. data.{state_dir_key}: data/processed/model/state"
        )

    state_dir = Path(data_paths[state_dir_key])
    A_path = state_dir / "A_final.npy"

    if not A_path.exists():
        raise FileNotFoundError(f"A_final.npy not found at: {A_path}")

    logger.info("Loading A_final from: %s", A_path)
    A = np.load(A_path)

    # A may be stored as 1D (diag) or 2D diagonal
    if A.ndim == 1:
        a = A.astype(np.float64)
    elif A.ndim == 2:
        if A.shape[0] != A.shape[1]:
            raise ValueError(
                f"Expected square A, got shape={A.shape}. "
                f"If you store only the diagonal, use 1D instead."
            )
        a = np.diag(A).astype(np.float64)
    else:
        raise ValueError(f"Unexpected A array ndim={A.ndim}; expected 1D or 2D.")

    return a


def _load_final_U(paths_config: str = "configs/paths.yaml") -> np.ndarray:
    """
    Load the final topic–word matrix U_final from the model state directory.

    We assume the same data.model_state_dir as for A_final, with a file:
        U_final.npy
    """
    data_paths: Dict[str, str] = load_paths(paths_config)

    state_dir_key = "model_state_dir"
    if state_dir_key not in data_paths:
        raise KeyError(
            f"Key '{state_dir_key}' not found in paths.yaml. "
            f"Please add it, e.g. data.{state_dir_key}: data/processed/model/state"
        )

    state_dir = Path(data_paths[state_dir_key])
    U_path = state_dir / "U_final.npy"

    if not U_path.exists():
        raise FileNotFoundError(f"U_final.npy not found at: {U_path}")

    logger.info("Loading U_final from: %s", U_path)
    U = np.load(U_path)

    if U.ndim != 2:
        raise ValueError(f"Expected U_final to be 2D, got shape={U.shape}")

    return U


def _load_vocab(paths_config: str = "configs/paths.yaml") -> Tuple[Dict[str, int], List[str]]:
    """
    Load vocabulary JSON and return (token_to_id, id_to_token) from vocab.json.
    """
    data_paths: Dict[str, str] = load_paths(paths_config)
    vocab_json_key = "vocab_json" if "vocab_json" in data_paths else "vocab_path"
    vocab_path = Path(data_paths[vocab_json_key])

    if not vocab_path.exists():
        raise FileNotFoundError(f"Vocab JSON not found: {vocab_path}")

    with vocab_path.open("r", encoding="utf-8") as f:
        vocab_obj = json.load(f)

    token_to_id: Dict[str, int] = vocab_obj.get("token_to_id", {})
    id_to_token: List[str] = vocab_obj.get("id_to_token", [])

    if not token_to_id or not id_to_token:
        raise ValueError(
            f"Invalid vocab JSON at {vocab_path}: missing 'token_to_id' or 'id_to_token'."
        )

    return token_to_id, id_to_token


def evaluate_topic_importance(
    paths_config: str = "configs/paths.yaml",
    top_m_words: int = 10,
    top_n_topics: int = 10,
) -> Dict[str, Any]:
    """
    Evaluate topic importance using the learned diagonal entries a_k of A_final.

    Steps:
      1) Load U_final (topic-word matrix) and A_final (topic-importance diag).
      2) Extract a_k from A_final and rank topics by descending a_k.
      3) For each topic, extract top-m words from the corresponding column of U.
      4) Save:
         - topic_importance_K{K}.csv          : all topics with a_k and rank
         - topic_importance_topwords_K{K}.csv : top-N topics with top-m words
    """
    logger = logging.getLogger("evaluate_topic_importance")
    logger.info("Starting topic-importance evaluation ...")

    # --------------------------------------------------------------
    # 1) Load paths, U_final, and A_final
    # --------------------------------------------------------------
    data_paths: Dict[str, str] = load_paths(paths_config)

    # Reuse eval root from your existing evaluation outputs
    eval_root = Path(data_paths["topic_eval_overall_metrics"]).parent
    eval_root.mkdir(parents=True, exist_ok=True)

    logger.info("Loading U_final ...")
    U = _load_final_U(paths_config=paths_config)  # shape (V, K)
    V, K = U.shape
    logger.info("U_final shape: (V=%d, K=%d)", V, K)

    a = _load_final_A(paths_config=paths_config)  # shape (K,)
    if a.shape[0] != K:
        raise ValueError(
            f"a_k length ({a.shape[0]}) does not match number of topics K={K}."
        )

    # --------------------------------------------------------------
    # 2) Rank topics by a_k (descending)
    # --------------------------------------------------------------
    topic_ids = np.arange(K, dtype=int)
    order = np.argsort(-a)  # descending by importance
    ranked_topic_ids = topic_ids[order]
    ranked_a = a[order]

    logger.info("Top-5 topics by a_k: %s", list(zip(ranked_topic_ids[:5], ranked_a[:5])))

    # --------------------------------------------------------------
    # 3) Extract top-m words for each topic from U
    # --------------------------------------------------------------


    #yaha sa
    # _, id_to_token = _load_vocab(paths_config=paths_config)
    #
    # top_m_words = int(min(top_m_words, V))
    # all_topics_rows: List[Dict[str, Any]] = []
    #
    # for rank_idx, (k, a_k) in enumerate(zip(ranked_topic_ids, ranked_a), start=1):
    #     col = U[:, k]
    #     # sort vocab indices by descending weight in U[:,k]
    #     word_order = np.argsort(-col)
    #     top_ids = word_order[:top_m_words]
    #     top_tokens = [id_to_token[i] for i in top_ids]
    #
    #     row: Dict[str, Any] = {
    #         "rank": rank_idx,
    #         "topic_id": int(k),
    #         "a_k": float(a_k),
    #     }
    #     for i, tok in enumerate(top_tokens):
    #         row[f"word_{i+1}"] = tok
    #     all_topics_rows.append(row)

    #yaha tak

    # --------------------------------------------------------------
    # 3) Extract top-m words for each topic from U
    #    with uniqueness across topics (most important topics choose first)
    # --------------------------------------------------------------
    _, id_to_token = _load_vocab(paths_config=paths_config)

    top_m_words = int(min(top_m_words, V))
    all_topics_rows: List[Dict[str, Any]] = []

    # keep track of words already used by higher-ranked topics
    used_tokens = set()

    for rank_idx, (k, a_k) in enumerate(zip(ranked_topic_ids, ranked_a), start=1):
        col = U[:, k]
        # sort vocab indices by descending weight in U[:,k]
        word_order = np.argsort(-col)

        top_tokens: List[str] = []
        for vid in word_order:
            tok = id_to_token[vid]
            if tok in used_tokens:
                continue  # skip words already used for a more important topic
            top_tokens.append(tok)
            used_tokens.add(tok)
            if len(top_tokens) >= top_m_words:
                break

        row: Dict[str, Any] = {
            "rank": rank_idx,
            "topic_id": int(k),
            "a_k": float(a_k),
        }
        for i, tok in enumerate(top_tokens):
            row[f"word_{i+1}"] = tok
        all_topics_rows.append(row)

    # --------------------------------------------------------------
    # 4) Save CSVs
    # --------------------------------------------------------------
    importance_csv = eval_root / f"topic_importance_K{K}.csv"
    topwords_csv = eval_root / f"topic_importance_topwords_K{K}.csv"

    # (a) All topics with rank + a_k + top-m words
    df_all = pd.DataFrame(all_topics_rows)
    df_all.to_csv(importance_csv, index=False, encoding="utf-8-sig")

    # (b) Top-N topics (for paper tables)
    top_n = int(min(top_n_topics, K))
    df_top = df_all.iloc[:top_n].copy()
    df_top.to_csv(topwords_csv, index=False, encoding="utf-8-sig")

    logger.info("Saved topic importance for K=%d to: %s", K, importance_csv)
    logger.info(
        "Saved top-%d topics with top-%d words to: %s",
        top_n,
        top_m_words,
        topwords_csv,
    )

    summary = {
        "K": int(K),
        "num_topics": int(K),
        "top_n_topics": top_n,
        "top_m_words": int(top_m_words),
        "importance_csv": str(importance_csv),
        "topwords_csv": str(topwords_csv),
    }
    logger.info("Topic-importance evaluation summary: %s", summary)

    return summary
