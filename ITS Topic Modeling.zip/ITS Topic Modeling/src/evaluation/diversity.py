# src/evaluation/diversity.py

from __future__ import annotations

from typing import Dict, List


def compute_topic_diversity(
    union_words: List[str],
    num_topics: int,
    top_m: int,
) -> Dict[str, float]:
    """
    Compute Topic Diversity (TD) and related stats.

    Standard TD definition (e.g., Dieng et al. 2020):
        TD = (# unique words across all topics) / (K * top_m)

    Args:
        union_words: list of all words appearing in any topic's top-m list
                     (may contain duplicates; we will uniquify).
        num_topics: number of topics K.
        top_m:      number of top words per topic (m).

    Returns:
        {
            "topic_diversity": float,
            "num_unique_words": int,
            "num_topics": int,
            "top_m": int,
        }
    """
    unique_words = set(union_words)
    num_unique = len(unique_words)

    denom = num_topics * top_m
    if denom <= 0:
        td = 0.0
    else:
        td = num_unique / float(denom)

    return {
        "topic_diversity": float(td),
        "num_unique_words": int(num_unique),
        "num_topics": int(num_topics),
        "top_m": int(top_m),
    }
