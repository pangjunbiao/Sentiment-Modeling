# src/experiments/baselines/run_nmf.py

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List

import yaml
import numpy as np
import pandas as pd

from collections import Counter

from src.data_pipeline.combine_cities import load_paths
from src.evaluation.topics_io import load_docs_tokens
from src.evaluation.coherence import compute_topic_coherence
from src.evaluation.diversity import compute_topic_diversity

logger = logging.getLogger("src.experiments.baselines.run_nmf")


# ---------------------------------------------------------------------
# Helper: load NMF config
# ---------------------------------------------------------------------

def _load_nmf_config(
    baselines_config: str = "configs/experiments_baselines.yaml",
) -> Dict[str, Any]:
    """
    Load NMF baseline configuration from experiments_baselines.yaml.

    Expected structure:

      baselines:
        nmf:
          num_topics: 20
          max_iter: 200
          random_state: 42
          top_m: 10
          tag: "nmf_K20"
    """
    cfg_path = Path(baselines_config)
    if not cfg_path.exists():
        raise FileNotFoundError(f"Baselines config not found: {cfg_path}")

    with cfg_path.open("r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}

    nmf_cfg = (cfg.get("baselines") or {}).get("nmf")
    if nmf_cfg is None:
        raise KeyError(
            "No 'baselines.nmf' section found in configs/experiments_baselines.yaml"
        )

    return nmf_cfg


# ---------------------------------------------------------------------
# Main NMF baseline runner
# ---------------------------------------------------------------------

def run_nmf_baseline(
    paths_config: str = "configs/paths.yaml",
    baselines_config: str = "configs/experiments_baselines.yaml",
) -> None:
    """
    Train an NMF baseline on the same tokenized corpus as the main model
    and evaluate it on (NPMI, C_v, Topic Diversity).

    Saves:
      data/processed/eval/baselines/{tag}_top_words.csv
      data/processed/eval/baselines/{tag}_topic_metrics.csv
      data/processed/eval/baselines/{tag}_overall_metrics.csv

    where 'tag' comes from experiments_baselines.yaml (default: nmf_K20).
    """
    # ------------------------------------------------------------------
    # 1) Load config + paths
    # ------------------------------------------------------------------
    nmf_cfg = _load_nmf_config(baselines_config=baselines_config)

    num_topics = int(nmf_cfg.get("num_topics", 20))
    max_iter = int(nmf_cfg.get("max_iter", 200))
    random_state = int(nmf_cfg.get("random_state", 42))
    top_m = int(nmf_cfg.get("top_m", 10))
    tag = str(nmf_cfg.get("tag", f"nmf_K{num_topics}"))

    logger.info(
        "NMF baseline config: num_topics=%d, max_iter=%d, random_state=%d, "
        "top_m=%d, tag=%s",
        num_topics,
        max_iter,
        random_state,
        top_m,
        tag,
    )

    data_paths = load_paths(paths_config)
    # Reuse your eval directory root, then create a 'baselines' subdir
    eval_root = Path(data_paths["topic_eval_overall_metrics"]).parent
    baseline_dir = eval_root / "baselines"
    baseline_dir.mkdir(parents=True, exist_ok=True)

    top_words_csv = baseline_dir / f"{tag}_top_words.csv"
    topic_metrics_csv = baseline_dir / f"{tag}_topic_metrics.csv"
    overall_metrics_csv = baseline_dir / f"{tag}_overall_metrics.csv"

    # ------------------------------------------------------------------
    # 2) Load tokenized documents
    # ------------------------------------------------------------------
    print("[NMF] Loading tokenized documents...")
    docs_tokens: List[List[str]] = load_docs_tokens(paths_config=paths_config)
    print(f"[NMF] Number of documents: {len(docs_tokens)}")

    if not docs_tokens:
        raise ValueError("[NMF] No tokenized documents loaded.")

    # ------------------------------------------------------------------
    # 3) Build vocabulary and document-term matrix (bag-of-words)
    # ------------------------------------------------------------------
    print("[NMF] Building vocabulary and document-term matrix...")

    # First pass: build vocabulary
    token_to_id: Dict[str, int] = {}
    for doc in docs_tokens:
        for tok in doc:
            if tok not in token_to_id:
                token_to_id[tok] = len(token_to_id)

    vocab_size = len(token_to_id)
    id_to_token: List[str] = [None] * vocab_size
    for tok, idx in token_to_id.items():
        id_to_token[idx] = tok

    num_docs = len(docs_tokens)

    # Second pass: collect counts
    rows: List[int] = []
    cols: List[int] = []
    data_vals: List[float] = []

    for d_idx, doc in enumerate(docs_tokens):
        cnt = Counter(doc)
        for tok, c in cnt.items():
            j = token_to_id.get(tok)
            if j is None:
                continue
            rows.append(d_idx)
            cols.append(j)
            data_vals.append(float(c))

    if not data_vals:
        raise ValueError("[NMF] Document-term matrix is empty (no non-zero counts).")

    from scipy.sparse import csr_matrix

    X = csr_matrix(
        (np.array(data_vals, dtype=np.float32), (np.array(rows), np.array(cols))),
        shape=(num_docs, vocab_size),
    )

    print(
        f"[NMF] DTM shape: {X.shape}, nnz={X.nnz}, vocab_size={vocab_size}"
    )

    # ------------------------------------------------------------------
    # 4) Train NMF (sklearn)
    # ------------------------------------------------------------------
    try:
        from sklearn.decomposition import NMF
    except ImportError as e:
        raise ImportError(
            "scikit-learn is required for the NMF baseline. "
            "Please install it via: pip install scikit-learn"
        ) from e

    print("[NMF] Training NMF model...")
    nmf_model = NMF(
        n_components=num_topics,
        init="nndsvd",        # stable initialization
        max_iter=max_iter,    # moderate iterations (not over-tuned)
        random_state=random_state,
        solver="cd",
        beta_loss="frobenius",
    )

    W_doc_topic = nmf_model.fit_transform(X)     # (num_docs, K)
    H_topic_word = nmf_model.components_        # (K, vocab_size)
    print("[NMF] Training done.")

    # ------------------------------------------------------------------
    # 5) Extract top-m words per topic
    # ------------------------------------------------------------------
    print(f"[NMF] Extracting top-{top_m} words for each topic...")
    topic_word_tokens: List[List[str]] = []

    for k in range(num_topics):
        row = H_topic_word[k, :]
        top_indices = np.argsort(row)[::-1][:top_m]
        words_k = [id_to_token[j] for j in top_indices]
        topic_word_tokens.append(words_k)

    # ------------------------------------------------------------------
    # 6) Compute topic coherence (NPMI, C_v)
    # ------------------------------------------------------------------
    print("[NMF] Computing topic coherence (NPMI, C_v)...")
    coh_results = compute_topic_coherence(
        topic_word_tokens=topic_word_tokens,
        docs_tokens=docs_tokens,
    )

    per_topic_npmi = coh_results["per_topic_npmi"]
    per_topic_c_v = coh_results["per_topic_c_v"]
    avg_npmi = coh_results["avg_npmi"]
    avg_c_v = coh_results["avg_c_v"]
    union_words = coh_results["union_words"]

    # ------------------------------------------------------------------
    # 7) Compute topic diversity (TD)
    # ------------------------------------------------------------------
    print("[NMF] Computing topic diversity (TD)...")
    td_info = compute_topic_diversity(
        union_words=union_words,
        num_topics=num_topics,
        top_m=top_m,
    )
    topic_diversity = td_info["topic_diversity"]

    # ------------------------------------------------------------------
    # 8) Save top words per topic
    # ------------------------------------------------------------------
    print(f"[NMF] Saving top words per topic to: {top_words_csv}")
    top_rows: List[Dict[str, Any]] = []
    for k, words in enumerate(topic_word_tokens):
        row: Dict[str, Any] = {"topic_id": k}
        for i, w in enumerate(words):
            row[f"word_{i+1}"] = w
        top_rows.append(row)

    df_top = pd.DataFrame(top_rows)
    df_top.to_csv(top_words_csv, index=False, encoding="utf-8-sig")

    # ------------------------------------------------------------------
    # 9) Save per-topic metrics
    # ------------------------------------------------------------------
    print(f"[NMF] Saving per-topic metrics to: {topic_metrics_csv}")
    df_metrics = pd.DataFrame(
        {
            "topic_id": list(range(num_topics)),
            "npmi": per_topic_npmi,
            "c_v": per_topic_c_v,
        }
    )
    df_metrics.to_csv(topic_metrics_csv, index=False, encoding="utf-8-sig")

    # ------------------------------------------------------------------
    # 10) Save overall metrics
    # ------------------------------------------------------------------
    print(f"[NMF] Saving overall metrics to: {overall_metrics_csv}")
    df_overall = pd.DataFrame(
        [
            {
                "avg_npmi": float(avg_npmi),
                "avg_c_v": float(avg_c_v),
                "topic_diversity": float(topic_diversity),
                "num_unique_words": int(td_info["num_unique_words"]),
                "num_topics": int(td_info["num_topics"]),
                "top_m": int(td_info["top_m"]),
                "tag": tag,
            }
        ]
    )
    df_overall.to_csv(overall_metrics_csv, index=False, encoding="utf-8-sig")

    # ------------------------------------------------------------------
    # 11) Print summary
    # ------------------------------------------------------------------
    print("[NMF] ===== Topic Quality Summary (NMF baseline) =====")
    print(f"[NMF] Avg NPMI        : {avg_npmi:.4f}")
    print(f"[NMF] Avg C_v         : {avg_c_v:.4f}")
    print(f"[NMF] Topic Diversity : {topic_diversity:.4f}")
    print(f"[NMF] Num topics (K)  : {num_topics}")
    print(f"[NMF] Top-m per topic : {top_m}")
    print("[NMF] ================================================\n")

    logger.info(
        "NMF baseline finished. avg_npmi=%.4f, avg_c_v=%.4f, TD=%.4f",
        avg_npmi,
        avg_c_v,
        topic_diversity,
    )
