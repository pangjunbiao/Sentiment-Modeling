# src/experiments/ablations/run_no_salience.py

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict

import yaml

from src.data_pipeline.combine_cities import load_paths
from src.graph.keyword_graph import build_and_save_keyword_graph
from src.model.trainer import train_model
from src.evaluation.report import evaluate_full_model


def run_no_salience_ablation(
    paths_config: str = "configs/paths.yaml",
    ablation_config: str = "configs/experiments_ablation.yaml",
    top_m: int = 10,
) -> None:
    """
    No-Salience ablation:

    * Rebuild the keyword graph with salience disabled:
          use_salience = False  → s_i = 1 for all i.
    * Store this new graph as a separate file (e.g. keyword_graph_noSalience.npz).
    * Temporarily point paths.yaml -> graph_path to this no-salience graph.
    * Train the model and evaluate with a tag (e.g. 'noSalience').
    * Restore the original paths.yaml at the end.

    This correctly isolates the effect of salience in the construction of W.
    """

    logger = logging.getLogger("run_no_salience_ablation")
    logger.info("Starting: No-salience ablation")

    # --------------------------------------------------------------
    # 1) Resolve current paths and choose filenames for no-salience graph
    # --------------------------------------------------------------
    data_paths = load_paths(paths_config)
    orig_graph_path = Path(data_paths["graph_path"])

    graph_no_sal = orig_graph_path.with_name(
        orig_graph_path.stem + "_noSalience.npz"
    )

    logger.info(f"No-salience ablation: base graph_path      = {orig_graph_path}")
    logger.info(f"No-salience ablation: noSalience graph_path = {graph_no_sal}")

    # --------------------------------------------------------------
    # 2) Read ablation tag from experiments_ablation.yaml (optional)
    # --------------------------------------------------------------
    tag = "noSalience"
    abl_path = Path(ablation_config)
    if abl_path.exists():
        try:
            with abl_path.open("r", encoding="utf-8") as f:
                ab_cfg = yaml.safe_load(f) or {}
            abl_info: Dict[str, Any] = (ab_cfg.get("ablations") or {}).get(
                "no_salience", {}
            )
            tag = abl_info.get("tag", tag)
        except Exception as e:
            logger.warning(
                "Could not read experiments_ablation.yaml (%s). "
                "Using default tag '%s'.",
                e,
                tag,
            )

    # --------------------------------------------------------------
    # 3) Backup original configs/paths.yaml
    # --------------------------------------------------------------
    paths_cfg_path = Path(paths_config)
    if not paths_cfg_path.exists():
        raise FileNotFoundError(f"Paths config not found: {paths_cfg_path}")

    original_text = paths_cfg_path.read_text(encoding="utf-8")

    try:
        # ----------------------------------------------------------
        # 4) Modify paths.yaml so graph_path points to no-salience graph
        # ----------------------------------------------------------
        cfg = yaml.safe_load(original_text) or {}
        if "data" not in cfg:
            raise KeyError(
                "Expected 'data' section in paths.yaml for No-salience ablation."
            )

        data_cfg = cfg["data"]

        # Point both canonical & alias keys to our no-salience graph file
        data_cfg["graph_path"] = str(graph_no_sal)
        data_cfg["keyword_graph"] = str(graph_no_sal)

        with paths_cfg_path.open("w", encoding="utf-8") as f:
            yaml.safe_dump(cfg, f, sort_keys=False, allow_unicode=True)

        logger.info(
            "No-salience ablation: updated paths.yaml to use noSalience graph."
        )

        # ----------------------------------------------------------
        # 5) Rebuild graph with salience turned OFF
        # ----------------------------------------------------------
        logger.info(
            "No-salience ablation: rebuilding keyword graph with use_salience=False..."
        )
        build_and_save_keyword_graph(
            paths_config=paths_config,
            use_post_weights=True,   # still use influence weights
            use_salience=False,      # <-- key change: s_i = 1
        )
        logger.info("No-salience ablation: keyword graph rebuilt (no salience).")

        # ----------------------------------------------------------
        # 6) Train model using no-salience graph
        # ----------------------------------------------------------
        logger.info("No-salience ablation: starting training...")
        train_model(paths_config=paths_config)
        logger.info("No-salience ablation: training finished.")

        # ----------------------------------------------------------
        # 7) Evaluate with tag (e.g. 'noSalience')
        # ----------------------------------------------------------
        logger.info("No-salience ablation: starting evaluation...")
        evaluate_full_model(
            paths_config=paths_config,
            top_m=top_m,
            tag=tag,
        )
        logger.info("No-salience ablation: evaluation finished.")

    finally:
        # ----------------------------------------------------------
        # 8) Restore original paths.yaml
        # ----------------------------------------------------------
        with paths_cfg_path.open("w", encoding="utf-8") as f:
            f.write(original_text)
        logger.info("No-salience ablation: restored original configs/paths.yaml")
        logger.info("Finished: No-salience ablation")
