# src/experiments/ablations/run_no_h.py

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict

import yaml

from src.model.trainer import train_model
from src.evaluation.report import evaluate_full_model

logger = logging.getLogger(__name__)


def run_no_h_ablation(
    paths_config: str = "configs/paths.yaml",
    ablation_config: str = "configs/experiments_ablation.yaml",
    top_m: int = 10,
) -> None:
    """
    Run the **true No-H ablation** for the current PDF model.

    Idea:
      - Keep the full data term and U / a MM updates unchanged.
      - Force the model to run **without H**:
            H = 0, Z = 0, Y = 0
        and **skip all ADMM H-updates**.
      - This reduces Θ to a purely structural term:
            Θ = U diag(a) Uᵀ
        i.e., a symmetric Poisson factorization without local residuals.

    Implementation:
      - We add a flag `training.no_h_model = True` in configs/model.yaml.
      - trainer.py will:
          * zero-out H, Z, Y right after initialization
          * skip ADMM block updates for H when `no_h_model=True`.
      - All U/a updates and other hyperparameters remain identical.

    Steps:
      1) Load 'no_h' tag from configs/experiments_ablation.yaml (optional).
      2) Backup configs/model.yaml.
      3) Set training.no_h_model = True.
      4) Train the model under this structural-only setting.
      5) Evaluate topic quality with outputs tagged (e.g. 'noH_struct').
      6) Restore the original configs/model.yaml.
    """
    logger = logging.getLogger("run_no_h_ablation")
    logger.info("Starting: TRUE No-H ablation (structural-only U diag(a) U^T)")

    # --------------------------------------------------------------
    # 1) Load ablation tag from experiments_ablation.yaml (optional)
    # --------------------------------------------------------------
    tag = "noH"  # default tag
    abl_path = Path(ablation_config)
    if abl_path.exists():
        try:
            with abl_path.open("r", encoding="utf-8") as f:
                ab_cfg = yaml.safe_load(f) or {}
            abl_info: Dict[str, Any] = (ab_cfg.get("ablations") or {}).get("no_h", {})
            tag = abl_info.get("tag", tag)
        except Exception as e:
            logger.warning(
                "Could not read experiments_ablation.yaml (%s). "
                "Using default tag '%s'.",
                e,
                tag,
            )

    # --------------------------------------------------------------
    # 2) Backup original model.yaml
    # --------------------------------------------------------------
    model_cfg_path = Path("configs/model.yaml")
    if not model_cfg_path.exists():
        raise FileNotFoundError(f"Model config not found: {model_cfg_path}")

    original_text = model_cfg_path.read_text(encoding="utf-8")

    try:
        # ----------------------------------------------------------
        # 3) Modify training.no_h_model = True  (disable H completely)
        # ----------------------------------------------------------
        cfg = yaml.safe_load(original_text) or {}
        training_cfg = cfg.setdefault("training", {})

        old_flag = training_cfg.get("no_h_model", False)
        training_cfg["no_h_model"] = True

        logger.info(
            "No-H ablation: setting training.no_h_model from %s to True",
            str(old_flag),
        )

        # NOTE: we **do not** touch model.lambda_h here.
        # The difference from the full model is ONLY that H is removed.

        # Write modified config back
        with model_cfg_path.open("w", encoding="utf-8") as f:
            yaml.safe_dump(cfg, f, sort_keys=False, allow_unicode=True)

        # ----------------------------------------------------------
        # 4) Train model under structural-only (No-H) setting
        # ----------------------------------------------------------
        logger.info("No-H ablation: starting training (H disabled)...")
        train_model(paths_config=paths_config, model_config_path=str(model_cfg_path))
        logger.info("No-H ablation: training finished.")

        # ----------------------------------------------------------
        # 5) Evaluate model and tag outputs (e.g. 'noH')
        # ----------------------------------------------------------
        logger.info("No-H ablation: starting evaluation...")
        evaluate_full_model(
            paths_config=paths_config,
            top_m=top_m,
            tag=tag,
        )
        logger.info("No-H ablation: evaluation finished.")

    finally:
        # ----------------------------------------------------------
        # 6) Restore original model.yaml
        # ----------------------------------------------------------
        with model_cfg_path.open("w", encoding="utf-8") as f:
            f.write(original_text)
        logger.info("No-H ablation: restored original configs/model.yaml")
        logger.info("Finished: No-H ablation (structural-only)")
