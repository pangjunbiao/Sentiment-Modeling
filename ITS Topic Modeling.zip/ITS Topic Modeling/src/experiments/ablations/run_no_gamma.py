# src/experiments/ablations/run_no_gamma.py

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict

import yaml

from src.model.trainer import train_model
from src.evaluation.report import evaluate_full_model


def run_no_gamma_ablation(
    paths_config: str = "configs/paths.yaml",
    ablation_config: str = "configs/experiments_ablation.yaml",
    top_m: int = 10,
) -> None:
    """
    No-Gamma Ablation (Remove U–decorrelation).

    In the updated PDF + MM/ADMM model:
      • The decorrelation penalty is   gamma * R_dec(U)
      • The decorrelation gradient step uses training.u_decor_lr

    A correct ablation must:
      1) Set model.gamma = 0.0
      2) Set training.u_decor_lr = 0.0

    Everything else remains unchanged so the experiment isolates the
    effect of γ cleanly. After training + evaluation, model.yaml is restored.
    """

    logger = logging.getLogger("run_no_gamma_ablation")
    logger.info("Starting: No-Gamma ablation")

    # --------------------------------------------------------------
    # 1) Load optional tag from experiments_ablation.yaml
    # --------------------------------------------------------------
    tag = "noGamma"
    abl_path = Path(ablation_config)

    if abl_path.exists():
        try:
            with abl_path.open("r", encoding="utf-8") as f:
                ab_cfg = yaml.safe_load(f) or {}
            abl_info: Dict[str, Any] = (ab_cfg.get("ablations") or {}).get(
                "no_gamma", {}
            )
            tag = abl_info.get("tag", tag)
        except Exception as e:
            logger.warning(
                "Could not read experiments_ablation.yaml (%s). "
                "Using default tag '%s'.",
                e,
                tag,
            )

    # --------------------------------------------------------------
    # 2) Backup original model.yaml
    # --------------------------------------------------------------
    model_cfg_path = Path("configs/model.yaml")
    if not model_cfg_path.exists():
        raise FileNotFoundError(f"Model config not found: {model_cfg_path}")

    original_cfg_text = model_cfg_path.read_text(encoding="utf-8")

    try:
        # ----------------------------------------------------------
        # 3) Modify config: disable gamma penalty AND decor LR
        # ----------------------------------------------------------
        cfg = yaml.safe_load(original_cfg_text) or {}

        if "model" not in cfg:
            raise KeyError("Expected 'model' section in configs/model.yaml")
        if "training" not in cfg:
            raise KeyError("Expected 'training' section in configs/model.yaml")

        old_gamma = cfg["model"].get("gamma", None)
        old_lr = cfg["training"].get("u_decor_lr", None)

        cfg["model"]["gamma"] = 0.0
        cfg["training"]["u_decor_lr"] = 0.0

        with model_cfg_path.open("w", encoding="utf-8") as f:
            yaml.safe_dump(cfg, f, sort_keys=False, allow_unicode=True)

        logger.info(
            "No-Gamma ablation: gamma %s → 0.0, u_decor_lr %s → 0.0",
            str(old_gamma),
            str(old_lr),
        )

        # ----------------------------------------------------------
        # 4) Train model under No-Gamma
        # ----------------------------------------------------------
        logger.info("No-Gamma: starting training...")
        train_model(paths_config=paths_config)
        logger.info("No-Gamma: training completed.")

        # ----------------------------------------------------------
        # 5) Evaluate with custom tag (NPMI + C_v + TD are all handled
        #    inside evaluate_full_model)
        # ----------------------------------------------------------
        logger.info("No-Gamma: starting evaluation...")
        evaluate_full_model(
            paths_config=paths_config,
            top_m=top_m,
            tag=tag,
        )
        logger.info("No-Gamma: evaluation finished.")

    finally:
        # ----------------------------------------------------------
        # 6) Restore original model.yaml (critical)
        # ----------------------------------------------------------
        with model_cfg_path.open("w", encoding="utf-8") as f:
            f.write(original_cfg_text)

        logger.info("No-Gamma: restored original model.yaml")
        logger.info("Finished: No-Gamma ablation")
