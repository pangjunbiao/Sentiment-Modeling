# src/experiments/ablations/run_no_decay.py

from __future__ import annotations
import logging
from pathlib import Path
from typing import Dict, Any
import yaml

from src.data_pipeline.combine_cities import load_paths
from src.graph.keyword_graph import build_and_save_keyword_graph
from src.graph.salience import compute_and_save_salience
from src.model.trainer import train_model
from src.evaluation.report import evaluate_full_model

logger = logging.getLogger(__name__)


def run_no_decay_ablation(
    paths_config: str = "configs/paths.yaml",
    ablation_config: str = "configs/experiments_ablation.yaml",
    top_m: int = 10,
) -> None:
    """
    No-distance-decay ablation.

    Full model:
        W_ij = sum_p δ_ij^(p) * w_p * decay(p) * salience(i)*salience(j)

    No-decay ablation:
        W_ij = sum_p δ_ij^(p) * w_p * 1.0 * salience(i)*salience(j)

    Steps:
      1. Backup original keyword graph (full model)
      2. Rebuild graph with use_distance_decay = False
      3. Recompute salience on that graph
      4. Train normally
      5. Evaluate with a tag "noDecay"
      6. Restore full-model graph
    """

    logger.info("Starting: No-decay ablation")

    # --------------------------------------------------------------
    # 1) Load ablation tag from experiments_ablation.yaml
    # --------------------------------------------------------------
    tag = "noDecay"
    abl_path = Path(ablation_config)
    if abl_path.exists():
        try:
            with abl_path.open("r", encoding="utf-8") as f:
                ab_cfg = yaml.safe_load(f) or {}
            abl_info = (ab_cfg.get("ablations") or {}).get("no_decay", {})
            tag = abl_info.get("tag", tag)
        except Exception as e:
            logger.warning("Could not read ablation config (%s). Using default tag 'noDecay'.", e)

    # --------------------------------------------------------------
    # 2) Backup the full graph
    # --------------------------------------------------------------
    data_paths = load_paths(paths_config)

    orig_graph_path = Path(data_paths["graph_path"])
    backup_graph_path = orig_graph_path.with_name(orig_graph_path.stem + "_backup_full_model.npz")

    logger.info("Backing up full-model graph: %s -> %s", orig_graph_path, backup_graph_path)
    orig_graph_path.replace(backup_graph_path)

    try:
        # ----------------------------------------------------------
        # 3) Rebuild keyword graph WITHOUT distance decay
        # ----------------------------------------------------------
        logger.info("Rebuilding keyword graph with NO distance decay...")

        build_and_save_keyword_graph(
            paths_config=paths_config,
            use_post_weights=True,         # keep weights
            use_distance_decay=False,      # <-- key change
            lambda_dist=0.0,               # <-- decay off
            use_salience=True,             # keep salience
        )

        if not orig_graph_path.exists():
            raise FileNotFoundError("No-decay graph not created.")

        logger.info("No-decay graph built.")

        # ----------------------------------------------------------
        # 4) Recompute salience based on the no-decay graph
        # ----------------------------------------------------------
        logger.info("Recomputing salience for no-decay graph...")
        compute_and_save_salience(paths_config=paths_config)
        logger.info("Salience recomputed.")

        # ----------------------------------------------------------
        # 5) Train model on the no-decay graph
        # ----------------------------------------------------------
        logger.info("No-decay ablation: starting training...")
        train_model(paths_config=paths_config)
        logger.info("Training finished.")

        # ----------------------------------------------------------
        # 6) Evaluate
        # ----------------------------------------------------------
        logger.info("Evaluating no-decay model...")
        evaluate_full_model(
            paths_config=paths_config,
            top_m=top_m,
            tag=tag,
        )
        logger.info("Evaluation finished.")

    finally:
        # ----------------------------------------------------------
        # 7) Restore original full-model graph
        # ----------------------------------------------------------
        logger.info("Restoring full-model graph...")
        if orig_graph_path.exists():
            orig_graph_path.unlink()
        backup_graph_path.replace(orig_graph_path)

        logger.info("Finished: No-decay ablation")
