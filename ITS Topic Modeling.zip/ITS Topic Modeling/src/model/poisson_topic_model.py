# src/model/poisson_topic_model.py

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Dict, Any, Tuple

import numpy as np
from scipy.sparse import csr_matrix, load_npz

from src.data_pipeline.combine_cities import load_paths


# ---------------------------------------------------------------------
# 0) (Optional) legacy vocab loader – still useful for inspection
# ---------------------------------------------------------------------


def _load_vocab(vocab_path: Path) -> Dict[str, int]:
    """
    Load vocabulary JSON and return token_to_id dict.

    Expected vocab.json structure:
    {
      "token_to_id": { "<token>": <id>, ... },
      "id_to_token": [ "<token0>", "<token1>", ... ],
      "freq": { "<token>": <frequency>, ... }
    }

    This is primarily for inspection / debugging; the PDF model itself
    only needs the size V, which comes from the keyword graph adjacency.
    """
    if not vocab_path.exists():
        raise FileNotFoundError(f"Vocabulary file not found: {vocab_path}")

    with vocab_path.open("r", encoding="utf-8") as f:
        vocab_obj = json.load(f)

    token_to_id = vocab_obj.get("token_to_id", {})
    if not token_to_id:
        raise ValueError(f"No 'token_to_id' found in vocab JSON: {vocab_path}")

    return token_to_id


# ---------------------------------------------------------------------
# 1) Load keyword graph adjacency W (V x V)
# ---------------------------------------------------------------------


def load_keyword_graph(
    paths_config: str = "configs/paths.yaml",
) -> csr_matrix:
    """
    Load the influence-weighted keyword co-occurrence graph W (V x V).

    This is the same adjacency that was constructed in:
        src/graph/keyword_graph.py

    and saved at data_paths["graph_path"] as a symmetric, loopless
    sparse matrix (CSR format).
    """
    data_paths: Dict[str, str] = load_paths(paths_config)
    graph_path = Path(data_paths["graph_path"])

    if not graph_path.exists():
        raise FileNotFoundError(
            f"Keyword graph adjacency not found at: {graph_path}. "
            f"Run the 'keyword_graph' stage first."
        )

    W = load_npz(graph_path).tocsr()
    V1, V2 = W.shape
    if V1 != V2:
        raise ValueError(
            f"Keyword graph must be square; got shape {W.shape} at {graph_path}"
        )

    # Ensure zero diagonal (loopless graph)
    W.setdiag(0.0)
    W.eliminate_zeros()

    return W


# ---------------------------------------------------------------------
# 2) PDF model configuration
# ---------------------------------------------------------------------


@dataclass
class PoissonTopicModelConfig:
    """
    Configuration / hyperparameters for the Poisson topic model and ADMM.

    K: number of topics.
    lambda_u, lambda_h: regularization strengths (if needed).
    gamma: decorrelation strength.
    epsilon: numeric stability term.
    """
    num_topics: int = 20
    lambda_u: float = 0.0
    lambda_h: float = 0.0
    gamma: float = 0.1
    epsilon: float = 1e-8

    # Make sure values loaded from YAML (even if written as strings)
    # are converted to the correct numeric types.
    def __post_init__(self):
        self.num_topics = int(self.num_topics)
        self.lambda_u = float(self.lambda_u)
        self.lambda_h = float(self.lambda_h)
        self.gamma = float(self.gamma)
        self.epsilon = float(self.epsilon)



# ---------------------------------------------------------------------
# 3) Poisson Deconvolution Model on W
# ---------------------------------------------------------------------


class PoissonTopicModel:
    """
    Poisson Deconvolution Factorization (PDF) on the keyword graph W.

    Data:
      - W : (V x V) symmetric, nonnegative keyword co-occurrence matrix.
            W_ij integrates user influence weights w_p and salience factors
            s_i s_j, as constructed in src/graph/keyword_graph.py.

    Latent variables:
      - U : (V x K) nonnegative topic–keyword dictionary.
             Row i = representation of word i across K topics.
      - a : (K,) nonnegative topic strengths; we use A = diag(a).
      - H : (V x K) nonnegative residual/topic-specific loading.
      - Z : (V x K) auxiliary variable for ADMM on H.
      - Y : (V x K) dual variable (Lagrange multipliers) for ADMM on H.

    Reconstruction:
      - Θ = U diag(a) U^T + U H^T + H U^T  (V x V)

    Data term (generalized KL on off-diagonals, see methodology):
      L_data(U, a, H)
        = sum_{i<j} [ Θ_ij - W_ij * log(Θ_ij) ]

    Regularizers (implemented in src/model/losses.py):
      - λ_H ||H||_1
      - (γ/2) * R_dec(U) = (γ/2) * || U^T U - diag(U^T U) ||_F^2

    This class provides:
      * storage and initialization of U, a, H, Z, Y
      * computation of Θ
      * computation of the data-fidelity term L_data(U, a, H)
    """

    def __init__(
        self,
        W: csr_matrix,
        config: PoissonTopicModelConfig,
    ) -> None:
        # Data
        self.W: csr_matrix = W.tocsr()
        self.config: PoissonTopicModelConfig = config

        self.V: int = self.W.shape[0]  # vocabulary size
        self.K: int = config.num_topics

        # Latent variables (initialized later)
        self.U: Optional[np.ndarray] = None  # (V x K)
        self.a: Optional[np.ndarray] = None  # (K,)
        self.H: Optional[np.ndarray] = None  # (V x K)
        self.Z: Optional[np.ndarray] = None  # (V x K) ADMM aux
        self.Y: Optional[np.ndarray] = None  # (V x K) ADMM dual

        # Cache for upper-triangular indices of W (i < j)
        self._upper_i: Optional[np.ndarray] = None
        self._upper_j: Optional[np.ndarray] = None
        self._upper_w: Optional[np.ndarray] = None

        self._prepare_upper_triangle_cache()

    # -----------------------------------------------------------------
    # 3.1 Upper-triangle cache for W (i < j)
    # -----------------------------------------------------------------

    def _prepare_upper_triangle_cache(self) -> None:
        """
        Precompute the indices (i, j) and values W_ij for all i<j where
        W_ij > 0. This is used in the data term:

            sum_{i<j} W_ij * log(Θ_ij).

        We still evaluate sum_{i<j} Θ_ij over *all* off-diagonal entries
        using a dense Θ, but for the KL part we only need W_ij at
        non-zero edges.
        """
        coo = self.W.tocoo()
        rows = coo.row
        cols = coo.col
        data = coo.data.astype(np.float64)

        mask = rows < cols
        self._upper_i = rows[mask].astype(np.int64)
        self._upper_j = cols[mask].astype(np.int64)
        self._upper_w = data[mask]

    # -----------------------------------------------------------------
    # 3.2 Initialization of U, a, H, Z, Y
    # -----------------------------------------------------------------

    def initialize_random(self, seed: int = 0) -> None:
        """
        Initialize U, a, H, Z, Y with simple nonnegative random values
        consistent with the constraints in the methodology:

          - U >= 0, each column L1-normalized: ||u_:k||_1 = 1
          - a_k > 0 (initialized to 1)
          - H >= 0, projected to ||H||_F = 1
          - Z = H, Y = 0 (standard ADMM warm start)

        More sophisticated initializations (e.g., using spectral methods)
        can be added later, but this is a stable default.
        """
        rng = np.random.default_rng(seed)

        # U: V x K, positive
        U = rng.gamma(shape=1.0, scale=1.0, size=(self.V, self.K))
        # L1-normalize columns of U so that ||u_:k||_1 = 1
        col_sums = U.sum(axis=0, keepdims=True)
        col_sums[col_sums == 0.0] = 1.0
        U /= col_sums

        # a: topic strengths, start from ones
        a = np.ones(self.K, dtype=np.float64)

        # H: V x K, positive, then project to ||H||_F = 1
        H = rng.gamma(shape=1.0, scale=1.0, size=(self.V, self.K))
        fro = float(np.linalg.norm(H, ord="fro"))
        if fro <= 0.0:
            # degenerate case, reinitialize to small positive values
            H = np.full((self.V, self.K), 1e-3, dtype=np.float64)
            fro = float(np.linalg.norm(H, ord="fro"))
        H /= fro

        # ADMM auxiliary and dual variables
        Z = H.copy()
        Y = np.zeros_like(H, dtype=np.float64)

        # Store
        self.U = U
        self.a = a
        self.H = H
        self.Z = Z
        self.Y = Y

    # -----------------------------------------------------------------
    # 3.3 Compute Θ = U diag(a) U^T + U H^T + H U^T Equation no 7 and it's likelihood expressiono
    # -----------------------------------------------------------------

    def compute_theta(self) -> np.ndarray:
        """
        Compute the full reconstruction matrix:

            Θ = U diag(a) U^T + U H^T + H U^T   (V x V)

        All three terms are computed explicitly and summed into a single
        dense matrix. The result is then clamped below by epsilon to
        avoid log(0) in the KL loss.

        NOTE: This is O(V^2 K) and uses O(V^2) memory, which is
        acceptable for V ≈ 4k and small K (≈10–30) in your dataset.
        """
        if self.U is None or self.H is None or self.a is None:
            raise ValueError("U, H, and a must be initialized before computing Θ.")

        eps = self.config.epsilon
        U = self.U          # (V x K)
        H = self.H          # (V x K)
        a = self.a          # (K,)


        # Λ = U diag(a) U^T (PDF applying first formulation)



        # Compute U_a = U * a (column-wise scaling): (V x K)
        U_a = U * a[None, :] # column-wise scaling: U_a[i,k] = U[i,k] * a_k
        Theta = U_a @ U.T   #  Σ_k a_k u_{ik}u_{jk}

        # Add residual terms U H^T + H U^T
        Theta += U @ H.T    #  Σ_k u_{ik}h_{jk}
        Theta += H @ U.T    #  Σ_k h_{ik}u_{jk}

        # Clamp to avoid zeros (for log)
        Theta = np.maximum(Theta, eps)
        return Theta

    # -----------------------------------------------------------------
    # 3.4 Data-fidelity term: generalized KL on off-diagonals (Equation no 8)
    # -----------------------------------------------------------------

    def pdf_data_term(self) -> float:
        """
        Compute the generalized KL data term on off-diagonal entries:

            L_data(U, a, H)
              = sum_{1 <= i < j <= V} [ Θ_ij - W_ij * log(Θ_ij) ].

        Implementation details:
          - Θ = compute_theta() is dense (V x V).
          - sum_{i<j} Θ_ij is computed from the full matrix as:
                (sum_all(Θ) - trace(Θ)) / 2
          - sum_{i<j} W_ij log Θ_ij is computed only over (i, j)
            where W_ij > 0 using the cached upper-triangle indices.
        """
        if self._upper_i is None or self._upper_j is None or self._upper_w is None:
            self._prepare_upper_triangle_cache()

        Theta = self.compute_theta()  # This is same theta we have computed above

        # Sum over all off-diagonal Θ_ij with i < j:
        # total_offdiag = (sum_{i,j} Θ_ij - sum_i Θ_ii) / 2
        total_sum = float(Theta.sum()) # Theta.sum() = ∑_{i,j} Θ_{ij}
        diag_sum = float(np.trace(Theta))  # np.trace(Theta) = ∑_{i} Θ_{ii}
        theta_offdiag_sum = 0.5 * (total_sum - diag_sum) # Therefore: total_sum - diag_sum = ∑_{i ≠ j} Θ_{ij}  (all off-diagonals, both i<j and i>j)

        # KL term: sum_{i<j} W_ij * log Θ_ij, but only for edges with W_ij > 0
        i_idx = self._upper_i
        j_idx = self._upper_j
        w_vals = self._upper_w
        theta_vals = Theta[i_idx, j_idx]  # theta_vals gives the vector of Θ_{ij} for those same edge positions.

        log_theta = np.log(theta_vals)   # log_theta computes log(Θ_{ij}).
        kl_term = float(np.sum(w_vals * log_theta))    # w_vals holds the corresponding W_{ij} values.

        # Final data-fidelity loss
        data_loss = theta_offdiag_sum - kl_term
        return data_loss


# ---------------------------------------------------------------------
# 4) Convenience constructor for the PDF model
# ---------------------------------------------------------------------


def build_poisson_topic_model(
    paths_config: str = "configs/paths.yaml",
    model_config: Optional[PoissonTopicModelConfig] = None,
) -> PoissonTopicModel:
    """
    High-level helper to construct a PoissonTopicModel (PDF) from disk.

    Steps:
      1) Load the influence-weighted keyword graph W (V x V) from
         data_paths["graph_path"] via load_keyword_graph().
      2) Create a PoissonTopicModel with the given model_config (or
         default PoissonTopicModelConfig()).
      3) Return the model (variables U, a, H, Z, Y are uninitialized
         until you call model.initialize_random()).
    """
    if model_config is None:
        model_config = PoissonTopicModelConfig()

    W = load_keyword_graph(paths_config=paths_config)
    model = PoissonTopicModel(W=W, config=model_config)
    return model
