# src/model/admm_h.py

from __future__ import annotations

import logging
from typing import Dict, Any

import numpy as np
from scipy.sparse import csr_matrix

from src.model.poisson_topic_model import PoissonTopicModel
from src.model.losses import compute_loss_components

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------
# Helper: gradient of PDF data term wrt H on W
# ---------------------------------------------------------------------

def _grad_data_wrt_H_pdf(model: PoissonTopicModel) -> np.ndarray:
    """
    Compute ∂L_data / ∂H for the PDF model, holding U and a fixed.

    L_data(U, a, H)  (as in losses.data_term) is:

        L_data = sum_{i<j} Theta_ij
                 - sum_{(i,j) with W_ij>0} W_ij * log(Theta_ij)

    where
        Theta_ij = sum_k [ a_k u_{ik} u_{jk}
                           + u_{ik} h_{jk}
                           + h_{ik} u_{jk} ].

    Decompose gradient:

      L_data =  Σ_{i<j} Theta_ij           (all off-diagonals)
                - Σ_{i<j} W_ij log Theta_ij   (only where W_ij>0)

    => ∂L/∂H = ∂/∂H Σ_{i<j} Theta_ij       (term S)
              + ∂/∂H [ - Σ W_ij log Theta ] (term KL)

    1) Term S (sum over Theta_ij):
       Only the U H^T + H U^T parts contribute w.r.t H.
       A closed-form result is:

          grad_S[r, k] = (sum_i U_{ik}) - U_{rk}

       i.e., as a matrix:

          grad_S = 1_V * (sum_i U_{ik})_k^T  -  U

    2) Term KL:
       For each edge (i,j) with i<j and W_ij>0:

          dL/dTheta_ij (KL) = - W_ij / Theta_ij

       and using:
          ∂Theta_ij / ∂h_{ik} = u_{jk}
          ∂Theta_ij / ∂h_{jk} = u_{ik}

       we accumulate:

          grad_H[i, :] += dL_dTheta * u_j
          grad_H[j, :] += dL_dTheta * u_i

    This matches the data term used in losses.data_term.
    """
    if not isinstance(model.W, csr_matrix):
        raise ValueError("model.W must be a scipy.sparse.csr_matrix.")

    if model.U is None or model.H is None or model.a is None:
        raise ValueError("Model.U, Model.H, and model.a must be initialized.")

    W = model.W.tocoo()
    U = model.U          # (V x K)
    H = model.H          # (V x K)
    a = model.a          # (K,)

    V, K = U.shape
    eps = float(model.config.epsilon)

    # ----------------------------------------------------------
    # 1) Gradient from Σ_{i<j} Theta_ij
    #     Only U H^T + H U^T matter for H
    #
    #   grad_S[r, k] = sum_i U_{ik} - U_{rk}
    # ----------------------------------------------------------
    sumU = U.sum(axis=0)                # (K,)
    grad_H = sumU[None, :] - U         # (V, K)

    # ----------------------------------------------------------
    # 2) Gradient from - Σ W_ij log(Theta_ij)
    #    Only at edges with W_ij > 0
    # ----------------------------------------------------------
    rows = W.row
    cols = W.col
    data = W.data

    for idx in range(len(data)):
        i = int(rows[idx])
        j = int(cols[idx])
        if i >= j:
            continue

        w_ij = float(data[idx])
        if w_ij <= 0.0:
            continue

        u_i = U[i, :]    # (K,)
        u_j = U[j, :]    # (K,)
        h_i = H[i, :]    # (K,)
        h_j = H[j, :]    # (K,)

        # Theta_ij (same decomposition as in the paper)
        lambda_S = a * (u_i * u_j)
        lambda_L = u_i * h_j
        lambda_R = h_i * u_j
        theta_ij = float(np.sum(lambda_S + lambda_L + lambda_R) + eps)

        # dL/dTheta_ij from KL part only:
        #   ∂/∂Theta_ij [ - W_ij log Theta_ij ] = - W_ij / Theta_ij
        dL_dTheta_kl = - w_ij / max(theta_ij, eps)

        # Accumulate gradient contributions wrt h_{ik}, h_{jk}:
        #   dTheta_ij / d h_{ik} = u_{jk}
        #   dTheta_ij / d h_{jk} = u_{ik}
        grad_H[i, :] += dL_dTheta_kl * u_j
        grad_H[j, :] += dL_dTheta_kl * u_i

    return grad_H


# ---------------------------------------------------------------------
# ADMM updates for H, Z, Gamma (scaled form)
# ---------------------------------------------------------------------

def admm_update_HZ(
    model: PoissonTopicModel,
    rho: float,
    lr_h: float,
    num_inner_iters: int = 5,
) -> Dict[str, float]:
    """
    Perform a few inner ADMM iterations to update H, Z, and Gamma
    for the PDF model.

    We consider the H-block subproblem:

        min_{H, Z}  L_data(U, a, H) + lambda_h ||Z||_1
                     s.t. H = Z,

    with scaled ADMM variables (Gamma is the scaled dual variable):

      H-step:
        minimize_H  L_data(U, a, H) +
                    (rho/2) || H - Z + Gamma ||_F^2

      Z-step:
        minimize_Z  lambda_h ||Z||_1 +
                    (rho/2) || H - Z + Gamma ||_F^2

      Gamma-step (dual update):
        Gamma <- Gamma + (H - Z).

    Implementation:

      - H-step: gradient descent using _grad_data_wrt_H_pdf + penalty
      - Z-step: soft-thresholding (L1 proximal) on H + Gamma
      - Gamma-step: standard scaled dual update
      - After inner iterations: project H onto ||H||_F = 1 with H >= 0

    Assumes:
      - model.W is csr_matrix (V x V),
      - model.U, model.H, model.Z, model.Gamma, model.a are initialized.
    """
    if not isinstance(model.W, csr_matrix):
        raise ValueError("model.W must be a scipy.sparse.csr_matrix.")

    if (
        model.U is None
        or model.H is None
        or model.Z is None
        or model.Gamma is None
        or model.a is None
    ):
        raise ValueError("Model.U, H, Z, Gamma, and a must be initialized.")

    H = model.H           # (V x K)
    Z = model.Z           # (V x K)
    Gamma = model.Gamma   # (V x K)  # scaled dual variable

    lam_h = float(getattr(model.config, "lambda_h", 0.0))
    eps = float(model.config.epsilon)

    for it in range(num_inner_iters):
        # --------------------------------------------------------------
        # 1) H-step: gradient descent on
        #      L_data(U, a, H) + (rho/2)||H - Z + Gamma||_F^2
        # --------------------------------------------------------------
        grad_data = _grad_data_wrt_H_pdf(model)  # ∂L_data/∂H

        # Quadratic penalty gradient: rho * (H - Z + Gamma)
        grad_penalty = rho * (H - Z + Gamma)

        grad_H = grad_data + grad_penalty

        # Gradient step with nonnegativity clamp
        H = H - lr_h * grad_H
        H = np.maximum(H, eps)

        # Update model.H so that subsequent gradient calls use new H
        model.H = H

        # --------------------------------------------------------------
        # 2) Z-step: soft-thresholding (L1 proximal on H + Gamma)
        #
        #   Z = argmin_Z lambda_h ||Z||_1 +
        #                  (rho/2) ||H - Z + Gamma||^2
        #
        #   => Z = S_{lambda_h / rho}(H + Gamma),
        #
        #   where S_tau(x) = sign(x) * max(|x| - tau, 0).
        #
        #   We also enforce nonnegativity afterwards.
        # --------------------------------------------------------------
        if lam_h > 0.0:
            tau = lam_h / rho
            X = H + Gamma
            Z = np.sign(X) * np.maximum(np.abs(X) - tau, 0.0)
            Z = np.maximum(Z, 0.0)
        else:
            # If lambda_h == 0, the proximal is identity (no sparsity)
            Z = np.maximum(H + Gamma, 0.0)

        # --------------------------------------------------------------
        # 3) Gamma-step: scaled dual update
        # --------------------------------------------------------------
        Gamma = Gamma + (H - Z)

        # Write back into model at the end of inner iteration
        model.H = H
        model.Z = Z
        model.Gamma = Gamma

    # --------------------------------------------------------------
    # 4) Projection: enforce ||H||_F = 1 and nonnegativity
    # --------------------------------------------------------------
    H = np.maximum(H, 0.0)
    norm_H = float(np.linalg.norm(H, ord="fro"))
    if norm_H > 0.0:
        H = H / norm_H

    model.H = H
    # Z and Gamma are left as-is; in practice, this works well for ADMM.

    # --------------------------------------------------------------
    # 5) Compute and return loss components for logging
    # --------------------------------------------------------------
    loss_components = compute_loss_components(model)

    logger.info(
        "ADMM HZ update done: total=%.4f, data=%.4f, h_l1=%.4f, u_decor_scaled=%.6f",
        loss_components["total"],
        loss_components["data"],
        loss_components["h_l1"],
        loss_components["u_decor_scaled"],
    )

    return loss_components


# ---------------------------------------------------------------------
# High-level helper used by trainer.py
# ---------------------------------------------------------------------

def admm_step_for_H(
    model: PoissonTopicModel,
    training_cfg: Dict[str, Any],
) -> Dict[str, float]:
    """
    Read ADMM hyperparameters from training_cfg (configs/model.yaml)
    and perform one ADMM block update on H, Z, and Gamma.

    Expected training_cfg keys:
      - "admm_rho"        : penalty parameter rho
      - "admm_inner_iters": number of inner gradient/prox iterations
      - "lr_h"            : learning rate for H-step
    """
    rho = float(training_cfg.get("admm_rho", 1.0))
    inner_iters = int(training_cfg.get("admm_inner_iters", 5))
    lr_h = float(training_cfg.get("lr_h", 1e-3))

    logger.info(
        "ADMM step for H: rho=%.3f, inner_iters=%d, lr_h=%.3e",
        rho,
        inner_iters,
        lr_h,
    )

    return admm_update_HZ(
        model=model,
        rho=rho,
        lr_h=lr_h,
        num_inner_iters=inner_iters,
    )
