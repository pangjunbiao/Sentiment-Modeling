# src/model/initialization.py

from __future__ import annotations
import logging
import numpy as np

from src.model.poisson_topic_model import PoissonTopicModel

logger = logging.getLogger(__name__)

def initialize_model(model: PoissonTopicModel, training_cfg):
    """
    Initialize U, H, a, Z, Gamma for the PDF model.

    - U : (V × K), nonnegative, columns L1-normalized
    - H : (V × K), nonnegative, Frobenius-normalized
    - a : (K,), nonnegative
    - Z : copy of H (ADMM auxiliary)
    - Gamma : zeros (V × K), scaled dual variable
    """

    random_seed = int(training_cfg.get("random_seed", 0))
    np.random.seed(random_seed)

    V = model.W.shape[0]
    K = model.config.num_topics
    eps = float(model.config.epsilon)

    # -----------------------
    # Initialize U (V × K)
    # -----------------------
    U = np.random.rand(V, K).astype(np.float64)
    U = np.maximum(U, eps) # U >= eps

    # Column normalize U
    col_sums = np.sum(U, axis=0)
    col_sums = np.maximum(col_sums, eps)
    U = U / col_sums[None, :]

    # -----------------------
    # Initialize H (V × K)
    # -----------------------
    H = np.random.rand(V, K).astype(np.float64)
    H = np.maximum(H, eps)    # H >= eps

    # Frobenius normalization for H
    H = H / np.linalg.norm(H, ord="fro")

    # -----------------------
    # Initialize a (K,)
    # -----------------------
    a = np.ones(K, dtype=np.float64)   # a_k > 0

    # -----------------------
    # Initialize Z and Gamma for ADMM
    # -----------------------
    Z = np.copy(H)
    Gamma = np.zeros_like(H)

    # -----------------------
    # Write into model
    # -----------------------
    model.U = U
    model.H = H
    model.a = a
    model.Z = Z
    model.Gamma = Gamma

    logger.info(
        "Initialization complete: U.shape = %s, H.shape = %s, a.shape = %s",
        U.shape, H.shape, a.shape
    )
