# main.py

from __future__ import annotations

import argparse
from pathlib import Path
import logging

import pandas as pd
import yaml

from src.evaluation.topic_event_keywords import evaluate_topic_event_keywords
from src.evaluation.topic_sharpness import evaluate_topic_sharpness
from src.experiments.ablations.run_no_decay import run_no_decay_ablation
from src.experiments.ablations.run_no_gamma import run_no_gamma_ablation
from src.experiments.ablations.run_no_h import run_no_h_ablation
from src.experiments.ablations.run_no_salience import run_no_salience_ablation
from src.experiments.ablations.run_no_weights import run_no_weights_ablation
from src.experiments.ablations.run_plain_graph import run_plain_graph_ablation
from src.experiments.baselines.run_gsdmm import run_gsdmm_baseline
from src.experiments.baselines.run_hdp import run_hdp_baseline
from src.experiments.baselines.run_lda import run_lda_baseline
from src.experiments.baselines.run_nmf import run_nmf_baseline
from src.graph.keyword_graph import build_and_save_keyword_graph
from src.graph.salience import compute_and_save_salience
from src.utils.logging_utils import setup_logging
from src.data_pipeline.combine_cities import load_paths, combine_raw_city_csvs
from src.data_pipeline.loader import load_all_cities, summarize_raw_dataframe
from src.data_pipeline.preprocessing import preprocess_and_save
from src.data_pipeline.vocab_builder import build_and_save_vocab_and_tokens
from src.data_pipeline.influence_weights import compute_and_save_influence_weights
from src.model.trainer import train_model
from src.analysis.plot_training_loss import plot_training_loss
from src.evaluation.report import evaluate_full_model
from src.evaluation.topic_sharpness import evaluate_topic_sharpness
from src.evaluation.top_topic_posts import evaluate_top_posts_per_topic
from src.evaluation.topic_importance import evaluate_topic_importance


logger = logging.getLogger(__name__)






def run_combine_cities(paths_config: str = "configs/paths.yaml") -> None:
    """
    First pipeline step: combine Beijing, Shanghai, and Xiamen raw CSV files
    into a single all_cities.csv with a 'city' column.
    """
    # NEW: logger
    logger = logging.getLogger("run_combine_cities")
    logger.info("Starting: combine_cities stage")

    data_paths = load_paths(paths_config)

    beijing_csv = data_paths["beijing_csv"]
    shanghai_csv = data_paths["shanghai_csv"]
    xiamen_csv = data_paths["xiamen_csv"]
    combined_raw = data_paths["combined_raw"]

    print("Combining raw city CSVs...")
    print(f"  Beijing : {beijing_csv}")
    print(f"  Shanghai: {shanghai_csv}")
    print(f"  Xiamen  : {xiamen_csv}")
    print(f"  Output  : {combined_raw}")

    logger.info("Combining Beijing, Shanghai, and Xiamen raw CSV files.")

    combine_raw_city_csvs(
        beijing_path=beijing_csv,
        shanghai_path=shanghai_csv,
        xiamen_path=xiamen_csv,
        output_path=combined_raw,
    )

    if Path(combined_raw).exists():
        print(f"[OK] Combined file created at: {combined_raw}")
        logger.info(f"Successfully created combined CSV: {combined_raw}")
    else:
        print(f"[WARNING] Combined file was not created: {combined_raw}")
        logger.warning(f"Combined file missing: {combined_raw}")

    logger.info("Finished: combine_cities stage")



def run_inspect_raw(paths_config: str = "configs/paths.yaml") -> None:
    """
    Load all_cities.csv and print a brief summary.
    """
    # NEW: logger
    logger = logging.getLogger("run_inspect_raw")
    logger.info("Starting: inspect_raw stage")

    print("Loading combined raw dataset (all_cities.csv)...")
    df = load_all_cities(paths_config)

    logger.info(f"Raw dataset loaded: shape={df.shape}")

    summarize_raw_dataframe(df)

    logger.info("Finished: inspect_raw stage")



def run_preprocess(paths_config: str = "configs/paths.yaml") -> None:
    """
    Preprocess the combined dataset and save a cleaned version for downstream steps.
    """
    # NEW: logger
    logger = logging.getLogger("run_preprocess")
    logger.info("Starting: preprocess stage")

    preprocess_and_save(paths_config)

    logger.info("Finished: preprocess stage")



def run_vocab_tokens(paths_config: str = "configs/paths.yaml") -> None:
    """
    Build vocabulary and tokenize posts from the cleaned dataset.
    Saves:
      - vocab.json
      - vocab_stats.csv
      - post_tokens.csv
    """
    # NEW: logger
    logger = logging.getLogger("run_vocab_tokens")
    logger.info("Starting: vocab_tokens stage")

    build_and_save_vocab_and_tokens(paths_config=paths_config)

    logger.info("Finished: vocab_tokens stage")



def run_influence_weights(paths_config: str = "configs/paths.yaml") -> None:
    """
    Compute influence weights w_p for each post and save them
    to NumPy (.npy) and CSV files for downstream use.
    """
    # NEW: logger
    logger = logging.getLogger("run_influence_weights")
    logger.info("Starting: influence_weights stage")

    compute_and_save_influence_weights(paths_config=paths_config)

    logger.info("Finished: influence_weights stage")

def run_keyword_graph(
    paths_config: str = "configs/paths.yaml",
) -> None:
    """
    Stage: build the influence- and salience-weighted keyword graph W.

    This now matches the methodology: adjacent unordered bigrams,
    binary δ^{(p)}_{ij}, weighted by w_p and s_i s_j.
    """
    logger.info("Starting: keyword_graph stage")

    # If you have a dedicated graph config, you can load flags from there.
    # For now we simply use defaults (both weights and salience ON).
    use_post_weights = True
    use_salience = True

    build_and_save_keyword_graph(
        paths_config=paths_config,
        use_post_weights=use_post_weights,
        use_salience=use_salience,
    )

    logger.info("Finished: keyword_graph stage")


def run_salience(
    paths_config: str = "configs/paths.yaml",
) -> None:
    """
    Stage: compute salience scores s_i for each vocabulary term.

    Uses an IDF-like scheme by default, consistent with the methodology
    ("capped IDF / domain-prior boost").
    """
    logger.info("Starting: salience stage")

    # Defaults: IDF-style, normalized, capped at 95th percentile
    compute_and_save_salience(
        paths_config=paths_config,
        method="idf",
        normalize=True,
        cap_percentile=95.0,
    )

    logger.info("Finished: salience stage")


def run_train_model(
    paths_config: str = "configs/paths.yaml",
    model_config_path: str = "configs/model.yaml",
) -> None:
    """
    Train the Poisson Deconvolution Factorization model using ADMM + MM.
    Saves:
      - loss curve CSV
      - checkpoints
      - final U, A, H, Z, Gamma
    """
    logger = logging.getLogger("run_train_model")
    logger.info("Starting: train_model stage")

    train_model(
        paths_config=paths_config,
        model_config_path=model_config_path,
    )

    logger.info("Finished: train_model stage")

def run_plot_loss(paths_config: str = "configs/paths.yaml") -> None:
    """
    Read training_loss.csv and plot loss curves (total / data / decor).
    """
    logger = logging.getLogger("run_plot_loss")
    logger.info("Starting: plot_loss stage")

    png_path = plot_training_loss(paths_config=paths_config)

    logger.info(f"Saved training loss plot to: {png_path}")
    logger.info("Finished: plot_loss stage")

def run_eval_full_model(
    paths_config: str = "configs/paths.yaml",
    top_m: int = 10,
) -> None:
    """
    Evaluate the *full* trained model (with H, gamma, weights, etc.)
    on topic quality metrics:

      - Topic Coherence: NPMI, C_v
      - Topic Diversity: TD

    Saves:
      - full_model_top_words.csv
      - full_model_topic_metrics.csv
      - full_model_overall_metrics.csv
    """
    logger = logging.getLogger("run_eval_full_model")
    logger.info("Starting: eval_full_model stage")

    evaluate_full_model(paths_config=paths_config, top_m=top_m)

    logger.info("Finished: eval_full_model stage")


def run_sweep_k(
    paths_config: str = "configs/paths.yaml",
    k_values: list[int] | tuple[int, ...] = (10, 15, 20, 25, 30),
    top_m: int = 10,
) -> None:
    """
    Sweep over several values of K (number of topics) in a single run.

    For each K:
      - Temporarily set model.num_topics = K in configs/model.yaml
      - Train the model (train_model stage)
      - Evaluate the model (eval_full_model) with CSV filenames
        tagged by K (e.g. *_K10.csv, *_K15.csv, ...)

    At the end:
      - Restore the original configs/model.yaml.
      - Aggregate the per-K overall metrics into a single summary CSV.
    """
    logger = logging.getLogger("run_sweep_k")
    logger.info(f"Starting: sweep_k stage for K values: {k_values}")

    model_cfg_path = Path("configs/model.yaml")
    if not model_cfg_path.exists():
        raise FileNotFoundError(f"Model config not found: {model_cfg_path}")

    # Read original config so we can restore it later
    orig_text = model_cfg_path.read_text(encoding="utf-8")
    orig_cfg = yaml.safe_load(orig_text)

    try:
        for k in k_values:
            logger.info(f"=== Sweep: K = {k} ===")

            # 1) Modify config in memory
            cfg = yaml.safe_load(orig_text)  # fresh copy each time
            if "model" not in cfg:
                raise KeyError("Expected 'model' section in configs/model.yaml")
            cfg["model"]["num_topics"] = int(k)

            # 2) Write modified config back to model.yaml
            with model_cfg_path.open("w", encoding="utf-8") as f:
                yaml.safe_dump(cfg, f, sort_keys=False, allow_unicode=True)

            # 3) Train model with this K
            logger.info(f"Training model with K={k} ...")
            train_model(paths_config=paths_config)

            # 4) Evaluate model and save CSVs with suffix "_K{k}"
            logger.info(f"Evaluating model with K={k} ...")
            tag = f"K{k}"
            evaluate_full_model(paths_config=paths_config, top_m=top_m, tag=tag)

            logger.info(f"Finished K={k}")

    finally:
        # Restore original model.yaml
        with model_cfg_path.open("w", encoding="utf-8") as f:
            f.write(orig_text)
        logger.info("Restored original configs/model.yaml")

    # ------------------------------------------------------------------
    # Aggregate overall metrics across different K into one CSV
    # ------------------------------------------------------------------
    from src.data_pipeline.combine_cities import load_paths

    data_paths = load_paths(paths_config)
    base_overall = Path(data_paths["topic_eval_overall_metrics"])

    summary_rows: list[dict] = []

    for k in k_values:
        tag = f"K{k}"
        overall_path = base_overall.with_name(
            f"{base_overall.stem}_{tag}{base_overall.suffix}"
        )
        if not overall_path.exists():
            logger.warning(f"Overall metrics file for K={k} not found: {overall_path}")
            continue

        df_k = pd.read_csv(overall_path, encoding="utf-8-sig")
        if df_k.empty:
            logger.warning(f"Overall metrics file for K={k} is empty: {overall_path}")
            continue

        row = df_k.iloc[0].to_dict()
        row["K"] = k
        summary_rows.append(row)

    if summary_rows:
        summary_df = pd.DataFrame(summary_rows)
        summary_path = base_overall.with_name(
            f"{base_overall.stem}_k_sweep_summary{base_overall.suffix}"
        )
        summary_df.to_csv(summary_path, index=False, encoding="utf-8-sig")
        logger.info(f"Sweep summary saved to: {summary_path}")
    else:
        logger.warning("No per-K overall metrics found; no sweep summary CSV written.")

    logger.info("Finished: sweep_k stage")

def run_ablation_no_h(paths_config: str = "configs/paths.yaml") -> None:
    """
    Run the No-H ablation experiment:
    - freeze H/Z by setting admm_inner_iters=0
    - train the model
    - evaluate topic quality with tag "noH"
    """
    logger = logging.getLogger("run_ablation_no_h")
    logger.info("Starting: ablation_no_h stage")
    run_no_h_ablation(paths_config=paths_config)
    logger.info("Finished: ablation_no_h stage")

def run_ablation_no_gamma(paths_config: str = "configs/paths.yaml") -> None:
    """
    Wrapper to run the No-γ (no decorrelation) ablation
    with logging at the pipeline level.
    """
    logger = logging.getLogger("run_ablation_no_gamma")
    logger.info("Starting: ablation_no_gamma stage")

    run_no_gamma_ablation(paths_config=paths_config)

    logger.info("Finished: ablation_no_gamma stage")

def run_ablation_no_weights(paths_config: str = "configs/paths.yaml") -> None:
    """
    Wrapper to run the No-weights ablation.
    """
    logger = logging.getLogger("run_ablation_no_weights")
    logger.info("Starting: ablation_no_weights stage")

    run_no_weights_ablation(paths_config=paths_config)

    logger.info("Finished: ablation_no_weights stage")

# def run_ablation_no_decay(paths_config: str = "configs/paths.yaml") -> None:
#     """
#     Wrapper for the No-decay ablation experiment.
#     """
#     logger = logging.getLogger("run_ablation_no_decay")
#     logger.info("Starting: ablation_no_decay stage")
#
#     run_no_decay_ablation(paths_config=paths_config)
#
#     logger.info("Finished: ablation_no_decay stage")

def run_ablation_no_salience(
    paths_config: str = "configs/paths.yaml",
    top_m: int = 10,
) -> None:
    """
    Wrapper to run the No-salience (s_i = 1) ablation:
    training + evaluation with tagging.
    """
    logger = logging.getLogger("run_ablation_no_salience")
    logger.info("Starting: ablation_no_salience stage")

    run_no_salience_ablation(
        paths_config=paths_config,
        ablation_config="configs/experiments_ablation.yaml",
        top_m=top_m,
    )

    logger.info("Finished: ablation_no_salience stage")


def run_ablation_plain_graph(paths_config: str = "configs/paths.yaml") -> None:
    """
    Wrapper to run the Plain co-occurrence graph ablation:
    - rebuild keyword graph with NO weights and NO salience
    - train the model
    - evaluate topic quality with tag "plainGraph"
    """
    logger = logging.getLogger("run_ablation_plain_graph")
    logger.info("Starting: ablation_plain_graph stage")

    run_plain_graph_ablation(paths_config=paths_config)

    logger.info("Finished: ablation_plain_graph stage")

def run_baseline_lda(paths_config: str = "configs/paths.yaml") -> None:
    """
    Train + evaluate the LDA baseline on the tokenized corpus.
    Results are saved under data/processed/eval/baselines/.
    """
    logger = logging.getLogger("run_baseline_lda")
    logger.info("Starting: baseline_lda stage")

    run_lda_baseline(paths_config=paths_config)

    logger.info("Finished: baseline_lda stage")

def run_baseline_nmf(paths_config: str = "configs/paths.yaml") -> None:
    """
    Train + evaluate the NMF baseline on the tokenized corpus.
    Results are saved under data/processed/eval/baselines/.
    """
    logger = logging.getLogger("run_baseline_nmf")
    logger.info("Starting: baseline_nmf stage")

    run_nmf_baseline(paths_config=paths_config)

    logger.info("Finished: baseline_nmf stage")


def run_baseline_hdp(paths_config: str = "configs/paths.yaml") -> None:
    """
    Run the HDP baseline (gensim HdpModel) and save topic quality metrics.
    """
    logger = logging.getLogger("run_baseline_hdp")
    logger.info("Starting: baseline_hdp stage")
    run_hdp_baseline(paths_config=paths_config)
    logger.info("Finished: baseline_hdp stage")

def run_baseline_gsdmm(paths_config: str = "configs/paths.yaml") -> None:
    """
    Run GSDMM baseline (short-text topic model).
    """
    logger = logging.getLogger("run_baseline_gsdmm")
    logger.info("Starting: baseline_gsdmm stage")
    run_gsdmm_baseline(paths_config=paths_config)
    logger.info("Finished: baseline_gsdmm stage")

def run_eval_topic_sharpness(
    paths_config: str = "configs/paths.yaml",
    top_ms: tuple[int, int] = (10, 25),
) -> None:
    """
    Run topic-sharpness evaluation for the current trained model.

    Assumes training has already been run with the current configs/model.yaml,
    so that the latest H is saved in model_state_dir.
    """
    logger = logging.getLogger("run_eval_topic_sharpness")
    logger.info("Starting: eval_topic_sharpness stage")

    # NOTE: keyword must be top_ms (not top_m_list)
    evaluate_topic_sharpness(
        paths_config=paths_config,
        top_ms=top_ms,
        tag=None,  # no K tag, just "current model"
    )

    logger.info("Finished: eval_topic_sharpness stage")


def run_eval_topic_sharpness_sweep(
    paths_config: str = "configs/paths.yaml",
    k_values: tuple[int, ...] = (10, 15, 20, 25, 30),
    top_ms: tuple[int, int] = (10, 25),
) -> None:
    """
    Sweep topic sharpness across multiple K values.

    For each K:
      - modify configs/model.yaml to set model.num_topics = K
      - train the model
      - evaluate topic sharpness and save CSVs tagged by K (e.g. *_K10.csv)
    """
    import yaml
    from pathlib import Path
    from src.model.trainer import train_model

    logger = logging.getLogger("run_eval_topic_sharpness_sweep")
    logger.info(f"Starting: eval_topic_sharpness_sweep for K values: {k_values}")

    model_cfg_path = Path("configs/model.yaml")
    if not model_cfg_path.exists():
        raise FileNotFoundError(f"Model config not found: {model_cfg_path}")

    # Backup original config text
    orig_text = model_cfg_path.read_text(encoding="utf-8")

    try:
        for k in k_values:
            logger.info(f"=== Sharpness sweep: K = {k} ===")

            # fresh copy of original config
            cfg = yaml.safe_load(orig_text) or {}
            if "model" not in cfg:
                raise KeyError("Expected 'model' section in configs/model.yaml")
            cfg["model"]["num_topics"] = int(k)

            # write updated config
            with model_cfg_path.open("w", encoding="utf-8") as f:
                yaml.safe_dump(cfg, f, sort_keys=False, allow_unicode=True)

            # train model at this K
            logger.info(f"Training model for K={k} ...")
            train_model(paths_config=paths_config)

            # evaluate sharpness, tag CSVs with K
            logger.info(f"Evaluating topic sharpness for K={k} ...")
            tag = f"K{k}"
            evaluate_topic_sharpness(
                paths_config=paths_config,
                top_ms=top_ms,
                tag=tag,
            )

            logger.info(f"Finished sharpness evaluation for K={k}")

    finally:
        # restore original model.yaml
        with model_cfg_path.open("w", encoding="utf-8") as f:
            f.write(orig_text)
        logger.info("Restored original configs/model.yaml")

    logger.info("Finished: eval_topic_sharpness_sweep stage")

def run_eval_top_posts(
    paths_config: str = "configs/paths.yaml",
    top_n_posts: int = 5,
    top_m_words: int = 10,
) -> None:
    logger = logging.getLogger("run_eval_top_posts")
    logger.info("Starting: eval_top_posts stage")

    evaluate_top_posts_per_topic(
        paths_config=paths_config,
        top_n_posts=top_n_posts,
        top_m_words=top_m_words,
    )

    logger.info("Finished: eval_top_posts stage")

def run_eval_event_keywords(paths_config: str = "configs/paths.yaml") -> None:
    logger = logging.getLogger("run_eval_event_keywords")
    logger.info("Starting: eval_event_keywords stage")
    evaluate_topic_event_keywords(paths_config=paths_config)
    logger.info("Finished: eval_event_keywords stage")


def run_eval_topic_importance(paths_config: str) -> None:
    """
    Wrapper for topic-importance evaluation: loads A_final and U_final,
    ranks topics by a_k, and saves CSV summaries.
    """

    logger = logging.getLogger("run_eval_topic_importance")
    logger.info("Starting: eval_topic_importance stage")

    evaluate_topic_importance(paths_config=paths_config)

    logger.info("Finished: eval_topic_importance stage")


def parse_args() -> argparse.Namespace:
    """
    Command-line interface for main.py.

    Stages:
    - all              : combine_cities → inspect_raw → preprocess → vocab
                     → influence_weights → keyword_graph → salience
    - combine_cities : build data/raw/all_cities.csv from per-city CSVs.
    - inspect_raw    : load all_cities.csv and print a summary.
    - preprocess     : clean all_cities.csv and save all_cities_clean.csv.
    - vocab            : build vocabulary and tokenize posts.
    - influence_weights: compute and save influence weights w_p.
    - keyword_graph    : build influence-weighted keyword graph adjacency.
    - salience         : compute salience scores from the keyword graph.
    - train_model      : run Poisson topic model training (U + ADMM-H/Z).
    - plot_loss        : plot training_loss.csv into a PNG figure.
    - eval_full_model  : compute TC (NPMI, C_v) and TD for the final model.
    - sweep_k          : run train+eval for multiple K values and save K-tagged CSVs.
    - ablation_no_h    : No-H ablation (freeze H/Z updates).
    - ablation_no_gamma: run No-γ ablation (gamma = 0.0).
    - ablation_no_weight: run No-weight
    - ablation_no_decay:  run no_decay
    - ablation_no_salience : run no_salience
    - baseline_lda     : train + evaluate LDA baseline.
    - baseline_NMF   : train and run baseline
    - baseline_ HDP  : train and run HDP
    - baseline_gsdmm  : train and run gsdmm
    """
    parser = argparse.ArgumentParser(
        description="Keyword graph topic model pipeline controller"
    )
    parser.add_argument(
        "--stage",
        type=str,
        default="all",
        choices=["all", "combine_cities", "inspect_raw", "preprocess", "vocab", "influence_weights",
            "keyword_graph", "salience", "train_model", "plot_loss", "eval_full_model", "sweep_k",
            "ablation_no_h", "ablation_no_gamma", "ablation_no_weights", "ablation_no_salience", "ablation_plain_graph",
            "baseline_lda", "baseline_nmf","baseline_hdp", "baseline_gsdmm",
            "eval_topic_sharpness", "eval_topic_sharpness_sweep", "eval_top_posts", "eval_event_keywords", "eval_topic_importance"],
        help="Which pipeline stage to run.",
    )
    # parser.add_argument(
    #     "--stage",
    #     type=str,
    #     default="all",
    #     choices=["all", "combine_cities", "inspect_raw", "preprocess", "vocab", "influence_weights",
    #              "keyword_graph", "salience", "train_model", "plot_loss", "eval_full_model", "sweep_k",
    #              "ablation_no_h", "ablation_no_gamma", "ablation_no_weights", "ablation_no_decay",
    #              "ablation_no_salience",
    #              "ablation_plain_graph", "baseline_lda", "baseline_nmf", "baseline_hdp", "baseline_gsdmm",
    #              "eval_topic_sharpness", "eval_topic_sharpness_sweep"],
    #     help="Which pipeline stage to run.",
    # )
    parser.add_argument(
        "--paths-config",
        type=str,
        default="configs/paths.yaml",
        help="Path to paths.yaml configuration file.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    # initialize logging
    setup_logging()
    logger = logging.getLogger("main")
    logger.info(f"Starting pipeline with stage = {args.stage}")

    if args.stage == "all":
        # 1) combine raw city CSVs
        run_combine_cities(paths_config=args.paths_config)
        # 2) quick inspection of the combined raw data
        run_inspect_raw(paths_config=args.paths_config)
        # 3) preprocess and save cleaned dataset
        run_preprocess(paths_config=args.paths_config)
        # 4) build vocabulary and tokenize posts
        run_vocab_tokens(paths_config=args.paths_config)
        # 5) compute influence weights for each post
        run_influence_weights(paths_config=args.paths_config)
        # 6) build keyword graph
        run_keyword_graph(paths_config=args.paths_config)
        # 7) compute salience scores
        run_salience(paths_config=args.paths_config)
        # 9) Training ADMM
        run_train_model( paths_config=args.paths_config, model_config_path="configs/model.yaml",)
        # 10) plot training loss curves from training_loss.csv
        run_plot_loss(paths_config=args.paths_config)
        # 11) evaluate topic quality of the full model
        run_eval_full_model(paths_config=args.paths_config)
        # 12) optional: run ablations
        run_ablation_no_h(paths_config=args.paths_config)
        #

        run_ablation_no_weights(paths_config=args.paths_config)
        # run_ablation_no_decay(paths_config=args.paths_config)
        run_ablation_no_salience(paths_config=args.paths_config)
        # 12) run baselines


    elif args.stage == "combine_cities":
        run_combine_cities(paths_config=args.paths_config)

    elif args.stage == "inspect_raw":
        run_inspect_raw(paths_config=args.paths_config)

    elif args.stage == "preprocess":
        run_preprocess(paths_config=args.paths_config)

    elif args.stage == "vocab":
        run_vocab_tokens(paths_config=args.paths_config)

    elif args.stage == "influence_weights":
        run_influence_weights(paths_config=args.paths_config)

    elif args.stage == "keyword_graph":
        run_keyword_graph(paths_config=args.paths_config)

    elif args.stage == "salience":
        run_salience(paths_config=args.paths_config)

    elif args.stage == "train_model":
        run_train_model(
            paths_config=args.paths_config,
            model_config_path="configs/model.yaml",
        )
    elif args.stage == "plot_loss":
        run_plot_loss(paths_config=args.paths_config)

    elif args.stage == "eval_full_model":
        run_eval_full_model(paths_config=args.paths_config)

    elif args.stage == "sweep_k":
        run_sweep_k(paths_config=args.paths_config)


    elif args.stage == "ablation_no_h" or args.stage == "no_h":
        # Run "No H sparsity" ablation (lambda_h = 0.0)
        run_no_h_ablation(paths_config=args.paths_config)

    elif args.stage == "ablation_no_gamma":
        run_no_gamma_ablation(paths_config=args.paths_config)

    elif args.stage == "ablation_no_weights":
        run_ablation_no_weights(paths_config=args.paths_config)

    # elif args.stage == "ablation_no_decay":
    #     run_ablation_no_decay(paths_config=args.paths_config)

    elif args.stage == "ablation_no_salience":
        run_ablation_no_salience(paths_config=args.paths_config)

    elif args.stage == "ablation_plain_graph":
        run_ablation_plain_graph(paths_config=args.paths_config)

    elif args.stage == "baseline_lda":
        run_baseline_lda(paths_config=args.paths_config)

    elif args.stage == "baseline_nmf":
        run_baseline_nmf(paths_config=args.paths_config)

    elif args.stage == "baseline_hdp":
        run_baseline_hdp(paths_config=args.paths_config)

    elif args.stage == "baseline_gsdmm":
        run_baseline_gsdmm(paths_config=args.paths_config)

    elif args.stage == "eval_topic_sharpness":
        run_eval_topic_sharpness(paths_config=args.paths_config)

    elif args.stage == "eval_topic_sharpness_sweep":
        run_eval_topic_sharpness_sweep(paths_config=args.paths_config)

    elif args.stage == "eval_top_posts":
        run_eval_top_posts(paths_config=args.paths_config)

    elif args.stage == "eval_event_keywords":
        run_eval_event_keywords(paths_config=args.paths_config)

    elif args.stage == "eval_topic_importance":
        run_eval_topic_importance(paths_config=args.paths_config)


    else:
        # Should not happen because of choices=..., but kept for safety
        raise ValueError(f"Unknown stage: {args.stage}")


if __name__ == "__main__":
    main()
