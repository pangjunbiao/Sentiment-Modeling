# src/reports/case_table.py
from __future__ import annotations
import os, json, re
from typing import Dict, List, Optional, Tuple
import numpy as np
import pandas as pd
from outputs.figures.case_study import _soft_memberships_for_rows  # reuse memberships

# --------- tiny tokenizer & sentiment fallback (no snownlp dependency here) ----------
def _tokenize_cn(text: str, min_len: int = 2) -> List[str]:
    try:
        import jieba
    except Exception:
        return []
    if not isinstance(text, str):
        return []
    text = re.sub(r"https?://\S+|@[A-Za-z0-9_\-]+|#\S+", " ", text)
    toks = [w.strip() for w in jieba.lcut(text) if w and len(w.strip()) >= min_len]
    return toks

def _sentiment_lex(texts: List[str]) -> np.ndarray:
    # small neutral lexicon fallback in [0,1]
    pos = {"满意","通畅","顺利","改善","点赞","感谢","及时","方便","干净","快捷","舒适"}
    neg = {"堵","拥堵","延误","晚点","故障","投诉","不便","差","脏","挤","停运","封闭","坏了","困在","爆满"}
    out = np.zeros(len(texts), dtype=np.float32)
    for i, t in enumerate(texts):
        if not isinstance(t, str):
            out[i] = 0.5; continue
        tp = sum(1 for w in pos if w in t)
        tn = sum(1 for w in neg if w in t)
        out[i] = float(max(0.0, min(1.0, 0.5 + 0.1*(tp - tn))))
    return out

# --------- word glossing (Chinese → English) ----------
_DEFAULT_GLOSS = {
    "公交":"bus", "公交车":"bus", "北京公交":"Beijing bus", "司机":"driver", "驾驶":"driving",
    "安全":"safety", "行为":"behavior", "规范":"standard", "推出":"rollout", "操作":"operation",
    "系统":"system", "集团":"group", "地铁":"subway", "线路":"line", "站点":"station",
    "调整":"adjustment", "乘客":"passenger", "上车":"boarding", "应用":"app", "APP":"app",
    "调度":"dispatch", "事故":"accident", "堵":"congestion", "拥堵":"congestion"
}

def _gloss_words(words: List[str], cfg: Dict, keep_n: int = 10) -> List[str]:
    # allow user overrides in config under display.cn2en_glossary
    user_map = cfg.get("display", {}).get("cn2en_glossary", {})
    mp = dict(_DEFAULT_GLOSS); mp.update(user_map)
    en = []
    for w in words:
        if w in mp:
            en.append(mp[w])
        elif all(ord(c) < 128 for c in w):  # already ascii (e.g., "APP")
            en.append(w.lower())
        # else drop unknown Chinese token to keep the table English-only
        if len(en) >= keep_n:
            break
    # keep unique order
    seen, out = set(), []
    for x in en:
        if x not in seen:
            seen.add(x); out.append(x)
    return out

# --------- main entry ----------
def run_case_table(cfg: Dict, logger,
                   topic_id: Optional[int] = None,
                   center_date: Optional[str] = None,
                   days: int = 7,
                   redact_dates: bool = True,
                   top_posts: int = 5) -> Dict:
    """
    Build case-study tables (metrics + daily series + sanitized top posts).
    If redact_dates=True, tables contain only relative day offsets (no absolute dates).
    Outputs (in outputs/reports/):
      - case_study_metrics_k{topic}_redacted.csv  or  ..._t{date}.csv
      - case_study_daily_k{topic}_redacted.csv    or  ..._t{date}.csv
      - case_study_posts_k{topic}_sanitized.csv   (English-only columns; top-5 in window)
    """
    paths = cfg["paths"]
    art_dir = os.path.join(paths["outputs_dir"], "artifacts")
    rep_dir = os.path.join(paths["outputs_dir"], "reports")
    os.makedirs(rep_dir, exist_ok=True)

    # Load artifacts
    A  = np.load(os.path.join(art_dir, "A_TxK.npy"))   # T x K
    E  = np.load(os.path.join(art_dir, "E_TxK.npy"))   # T x K
    S  = np.load(os.path.join(art_dir, "S_TxK.npy"))   # T x K
    U  = np.load(os.path.join(art_dir, "U_KxV.npy"))   # K x V
    vocab = json.load(open(os.path.join(art_dir, "vocab.json"), "r", encoding="utf-8"))
    time_index = pd.read_csv(os.path.join(art_dir, "time_index.csv"))["time_bin"].astype("datetime64[ns]")
    T, K = S.shape

    # Choose center/topic (same rule as figure)
    if topic_id is None or center_date is None:
        ti, ki = np.unravel_index(np.argmax(S), S.shape)
        topic_id = int(ki)
        center_ts = pd.Timestamp(time_index.iloc[ti])
    else:
        topic_id = int(topic_id)
        target = pd.Timestamp(center_date)
        diffs = np.abs(time_index - target)
        ti = int(np.argmin(diffs))
        center_ts = pd.Timestamp(time_index.iloc[ti])
    topic_id = max(0, min(topic_id, K - 1))

    # Window slice
    start_ts = center_ts - pd.Timedelta(days=days)
    end_ts   = center_ts + pd.Timedelta(days=days)
    mask = (time_index >= start_ts) & (time_index <= end_ts)
    t_slice = np.where(mask.values)[0] if mask.any() else np.arange(len(time_index))
    t_ticks = time_index.iloc[t_slice]

    # Series
    A_k   = A[t_slice, topic_id].astype(float)
    E_k   = E[t_slice, topic_id].astype(float)
    S_k   = S[t_slice, topic_id].astype(float)
    logE  = np.log1p(E_k.astype(np.float64))

    # Peaks & lead time
    ixA, ixE, ixS = int(np.argmax(A_k)), int(np.argmax(E_k)), int(np.argmax(S_k))
    peak_A, peak_E, peak_logE, peak_S = float(A_k[ixA]), float(E_k[ixE]), float(logE[ixE]), float(S_k[ixS])
    # relative offsets (days) from center
    # day offsets relative to center day (works for Series/Index)
    offsets = (t_ticks - center_ts).dt.days.astype(int).tolist()
    off_A, off_E, off_S = offsets[ixA], offsets[ixE], offsets[ixS]
    lead_days = int(off_S - off_E)  # S minus E

    # Load posts + influence for sentiment/volume and to produce sanitized top posts
    proc = os.path.join(paths["processed_dir"], "weibo_all.csv")
    df = pd.read_csv(proc, parse_dates=["timestamp"])
    df["post_id"] = df["seq_id"] if "seq_id" in df.columns else (np.arange(len(df)) + 1)

    infl_path = os.path.join(art_dir, "influence.parquet")
    if not os.path.exists(infl_path):
        infl_path = os.path.join(paths["outputs_dir"], "artifacts", "influence.parquet")
    infl = pd.read_parquet(infl_path)[["post_id", "time_bin", "w_base"]]
    df = pd.merge(df, infl, on="post_id", how="left")
    df["time_bin"] = pd.to_datetime(df["time_bin"], errors="coerce")
    if df["time_bin"].isna().any():
        win = cfg["time"]["window"]
        df.loc[df["time_bin"].isna(), "time_bin"] = df.loc[df["time_bin"].isna(), "timestamp"].dt.to_period(win).dt.to_timestamp()

    # Keep posts in window
    in_window = (df["time_bin"] >= start_ts) & (df["time_bin"] <= end_ts)
    dfw = df.loc[in_window].copy()

    # Sentiment proxy (lexicon) for descriptive stats
    s_vals = _sentiment_lex(dfw["text"].tolist())
    s_mean, s_std = float(np.mean(s_vals)), float(np.std(s_vals))
    n_posts = int(len(dfw))
    n_users = int(dfw["user_id"].nunique()) if "user_id" in dfw.columns else int(n_posts)
    sum_infl = float(dfw["w_base"].fillna(0.0).sum())

    # --------- METRICS table (redacted or dated) ---------
    top_idx = np.argsort(-U[topic_id])[:12]
    cn_words = [vocab[j] for j in top_idx]
    en_words = _gloss_words(cn_words, cfg, keep_n=10)

    if redact_dates:
        metrics = pd.DataFrame([{
            "topic_id": int(topic_id),
            "window_days": int(days),
            "top_words_en": " ".join(en_words) if en_words else "N/A",
            "peak_A": peak_A, "peak_A_offset_days": int(off_A),
            "peak_E": peak_E, "peak_log1pE": peak_logE, "peak_E_offset_days": int(off_E),
            "peak_S": peak_S, "peak_S_offset_days": int(off_S),
            "lead_time_days(SminusE)": int(lead_days),
            "mean_A": float(np.mean(A_k)), "mean_log1pE": float(np.mean(logE)), "mean_S": float(np.mean(S_k)),
            "sum_influence_w": sum_infl, "n_posts_window": n_posts, "n_users_window": n_users,
            "mean_sentiment": s_mean, "std_sentiment": s_std
        }])
        mname = f"case_study_metrics_k{topic_id}_redacted.csv"
    else:
        metrics = pd.DataFrame([{
            "topic_id": int(topic_id),
            "center_date": str(center_ts.date()),
            "window_days": int(days),
            "top_words_en": " ".join(en_words) if en_words else "N/A",
            "peak_A": peak_A, "peak_A_date": str(t_ticks.iloc[ixA].date()),
            "peak_E": peak_E, "peak_log1pE": peak_logE, "peak_E_date": str(t_ticks.iloc[ixE].date()),
            "peak_S": peak_S, "peak_S_date": str(t_ticks.iloc[ixS].date()),
            "lead_time_days(SminusE)": int(lead_days),
            "mean_A": float(np.mean(A_k)), "mean_log1pE": float(np.mean(logE)), "mean_S": float(np.mean(S_k)),
            "sum_influence_w": sum_infl, "n_posts_window": n_posts, "n_users_window": n_users,
            "mean_sentiment": s_mean, "std_sentiment": s_std
        }])
        mname = f"case_study_metrics_k{topic_id}_t{center_ts.date()}.csv"

    mpath = os.path.join(rep_dir, mname)
    metrics.to_csv(mpath, index=False, encoding="utf-8-sig")

    # --------- DAILY series table (redacted or dated) ---------
    if redact_dates:
        daily = pd.DataFrame({
            "day_offset": offsets,
            "A": A_k, "log1pE": logE, "S": S_k
        })
        dname = f"case_study_daily_k{topic_id}_redacted.csv"
    else:
        daily = pd.DataFrame({
            "date": [str(pd.Timestamp(x).date()) for x in t_ticks],
            "A": A_k, "log1pE": logE, "S": S_k
        })
        dname = f"case_study_daily_k{topic_id}_t{center_ts.date()}.csv"

    dpath = os.path.join(rep_dir, dname)
    daily.to_csv(dpath, index=False, encoding="utf-8-sig")

    # --------- SANITIZED TOP POSTS (English-only columns; across window) ---------
    # Topic membership & score for posts in the window
    min_len = int(cfg["features"].get("min_token_len", 2))
    Theta_rows = _soft_memberships_for_rows(dfw["text"].tolist(), vocab, U, min_len)  # N x K
    score = dfw["w_base"].fillna(0.0).to_numpy(dtype=float) * Theta_rows[:, topic_id]
    dfw = dfw.assign(topic_score=score)

    # Day offset column
    dfw["day_offset"] = ((dfw["time_bin"] - center_ts).dt.days).astype(int)

    # English keywords per post (from glossary; no Chinese text)
    def kw_en(t: str) -> str:
        toks = _tokenize_cn(t)
        return " ".join(_gloss_words(toks, cfg, keep_n=5))
    dfw["keywords_en"] = [kw_en(t) for t in dfw["text"].tolist()]

    # Select top-N by score (ensure at least available rows)
    topN = min(top_posts, len(dfw))
    keep_cols = ["rank","day_offset","city","user_id","followers","likes","comments_count","topic_score","keywords_en"]
    df_top = dfw.sort_values("topic_score", ascending=False).head(topN).copy()
    df_top.insert(0, "rank", range(1, len(df_top)+1))
    # Fill missing numeric columns if not present
    for c in ["followers","likes","comments_count"]:
        if c not in df_top.columns: df_top[c] = 0

    ppath = os.path.join(rep_dir, f"case_study_posts_k{topic_id}_sanitized.csv")
    df_top[keep_cols].to_csv(ppath, index=False, encoding="utf-8-sig")

    logger.info(f"Case study metrics saved → {mpath}")
    logger.info(f"Case study daily series saved → {dpath}")
    logger.info(f"Sanitized top posts saved → {ppath}")

    return {"metrics_csv": mpath, "daily_csv": dpath, "posts_csv": ppath}

