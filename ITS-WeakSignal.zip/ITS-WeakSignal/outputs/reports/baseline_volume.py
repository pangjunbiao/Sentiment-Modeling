from __future__ import annotations
import os
from typing import Dict, Optional
import numpy as np
import pandas as pd

from outputs.reports.baseline_utils import (
    _ensure_dir, load_artifacts, choose_center, make_window, load_posts_with_timebins, add_ground_truth_if_available
)

def run_baseline_volume(cfg: Dict, logger, topic_id: Optional[int], center_date: Optional[str], days: int = 7):
    A, E, S, U, vocab, time_index = load_artifacts(cfg)
    k, center_ts = choose_center(topic_id, center_date, S, time_index)
    t_slice, t_ticks, x = make_window(time_index, center_ts, days)

    # daily series we also expose for context (same topic k)
    A_k = A[t_slice, k]
    E_k_plot = np.log1p(E[t_slice, k].astype(np.float64))
    S_k = S[t_slice, k]

    # volume (count) per day
    df_posts = load_posts_with_timebins(cfg, win=cfg["time"]["window"])
    day_counts = df_posts["time_bin"].value_counts().sort_index()
    day_counts = day_counts.reindex(t_ticks, fill_value=0).astype(int)
    vol = day_counts.values.astype(float)

    # z-score within window
    mu, sd = vol.mean(), vol.std()
    vol_z = (vol - mu) / (sd if sd > 0 else 1.0)

    # pack daily dataframe
    df_daily = pd.DataFrame({
        "time_bin": t_ticks,
        "day_offset": x,
        "A": A_k,
        "log1pE": E_k_plot,
        "S": S_k,
        "volume": vol,
        "volume_z": vol_z
    })

    out_dir = os.path.join(cfg["paths"]["outputs_dir"], "reports", "baselines")
    _ensure_dir(out_dir)
    daily_path = os.path.join(out_dir, f"baseline_volume_daily_k{k}_center_{center_ts.date()}.csv")
    df_daily.to_csv(daily_path, index=False, encoding="utf-8-sig")

    # optional evaluation if ground truth present
    metrics = {"topic": int(k), "center_date": str(center_ts.date()), "days": int(days),
               "mean_volume": float(vol.mean()), "std_volume": float(vol.std()),
               "mean_volume_z": float(vol_z.mean())}

    y = add_ground_truth_if_available(cfg, t_ticks)
    if y is not None:
        try:
            from sklearn.metrics import roc_auc_score, average_precision_score
            metrics["AUC_volume_z"] = float(roc_auc_score(y, vol_z))
            metrics["AP_volume_z"] = float(average_precision_score(y, vol_z))
        except Exception:
            pass

    metrics_path = os.path.join(out_dir, f"baseline_volume_metrics_k{k}_center_{center_ts.date()}.csv")
    pd.DataFrame([metrics]).to_csv(metrics_path, index=False, encoding="utf-8-sig")

    logger.info(f"Baseline(volume) saved → {daily_path} and {metrics_path}")
    return {"daily": daily_path, "metrics": metrics_path, "topic": k, "center": str(center_ts)}
