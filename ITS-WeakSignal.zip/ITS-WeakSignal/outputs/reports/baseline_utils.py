# outputs/reports/baseline_utils.py
from __future__ import annotations
import os, re, json
from typing import Dict, List, Tuple, Optional
import numpy as np
import pandas as pd
import jieba

def _ensure_dir(p: str):
    os.makedirs(p, exist_ok=True)

def load_artifacts(cfg: Dict):
    paths = cfg["paths"]
    art_dir = os.path.join(paths["outputs_dir"], "artifacts")
    A = np.load(os.path.join(art_dir, "A_TxK.npy"))
    E = np.load(os.path.join(art_dir, "E_TxK.npy"))
    S = np.load(os.path.join(art_dir, "S_TxK.npy"))
    U = np.load(os.path.join(art_dir, "U_KxV.npy"))
    vocab = json.load(open(os.path.join(art_dir, "vocab.json"), "r", encoding="utf-8"))
    time_index = pd.read_csv(os.path.join(art_dir, "time_index.csv"))["time_bin"].astype("datetime64[ns]")
    return A, E, S, U, vocab, time_index

def choose_center(topic_id: Optional[int], center_date: Optional[str],
                  S: np.ndarray, time_index: pd.Series):
    """
    Centering policy:
      - If topic_id is provided and center_date is None  → center at that topic's S-peak.
      - If topic_id and center_date are provided         → snap to nearest date.
      - If topic_id is None (no topic specified)         → pick the global (t,k) of max S.
    """
    T, K = S.shape
    if topic_id is not None and center_date is None:
        k = int(np.clip(topic_id, 0, K - 1))
        t_idx = int(np.argmax(S[:, k]))
        center_ts = pd.Timestamp(time_index.iloc[t_idx])
        return k, center_ts

    if topic_id is not None and center_date is not None:
        k = int(np.clip(topic_id, 0, K - 1))
        ct = pd.Timestamp(center_date)
        diffs = np.abs(time_index - ct)
        t_idx = int(np.argmin(diffs))
        center_ts = pd.Timestamp(time_index.iloc[t_idx])
        return k, center_ts

    # fallback: no topic specified → global S maximum
    t_idx, k_idx = np.unravel_index(np.argmax(S), S.shape)
    k = int(k_idx)
    center_ts = pd.Timestamp(time_index.iloc[t_idx])
    return k, center_ts

def make_window(time_index: pd.Series, center_ts: pd.Timestamp, days: int):
    start_ts = center_ts - pd.Timedelta(days=days)
    end_ts   = center_ts + pd.Timedelta(days=days)
    mask = (time_index >= start_ts) & (time_index <= end_ts)
    if mask.any():
        t_slice = np.where(mask.values)[0]
    else:
        t_slice = np.arange(len(time_index))
    t_ticks = time_index.iloc[t_slice]
    x = (t_ticks - center_ts).dt.days.astype(int)
    return t_slice, t_ticks, x

_URL_MENTION_HASHTAG = re.compile(r"https?://\S+|@[A-Za-z0-9_\-]+|#\S+")

def tokenize(text: str, min_len: int) -> List[str]:
    if not isinstance(text, str):
        return []
    text = _URL_MENTION_HASHTAG.sub(" ", text)
    toks = [w.strip() for w in jieba.lcut(text) if w and len(w.strip()) >= min_len]
    return toks

def soft_membership_one_topic(texts: List[str], vocab: List[str], U: np.ndarray, k: int, min_len: int) -> np.ndarray:
    """Return theta_k for each text (N,)."""
    v2i = {w: j for j, w in enumerate(vocab)}
    K, V = U.shape
    eps = 1e-12
    logU = np.log(U + eps)  # K x V
    N = len(texts)
    theta_k = np.zeros((N,), dtype=np.float32)
    for i, txt in enumerate(texts):
        idxs = [v2i[t] for t in tokenize(txt, min_len) if t in v2i]
        if not idxs:
            theta_k[i] = 1.0 / K  # uniform fallback
            continue
        ll = logU[:, idxs].sum(axis=1)      # K
        m = float(ll.max())
        ex = np.exp(ll - m)
        theta = ex / (ex.sum() + eps)
        theta_k[i] = float(theta[k])
    return theta_k

def load_posts_with_timebins(cfg: Dict, win: str) -> pd.DataFrame:
    proc = os.path.join(cfg["paths"]["processed_dir"], "weibo_all.csv")
    df = pd.read_csv(proc, parse_dates=["timestamp"])
    if "seq_id" in df.columns:
        df["post_id"] = df["seq_id"]
    else:
        df["post_id"] = np.arange(len(df)) + 1
    # attach influence
    art_dir = os.path.join(cfg["paths"]["outputs_dir"], "artifacts")
    infl = pd.read_parquet(os.path.join(art_dir, "influence.parquet"))[["post_id","time_bin","w_base"]]
    df = pd.merge(df, infl, on="post_id", how="left")
    df["time_bin"] = pd.to_datetime(df["time_bin"], errors="coerce")
    need = df["time_bin"].isna()
    if need.any():
        df.loc[need, "time_bin"] = df.loc[need, "timestamp"].dt.to_period(win).dt.to_timestamp()
    return df

def add_ground_truth_if_available(cfg: Dict, t_ticks: pd.Series) -> Optional[pd.Series]:
    gt_path = cfg.get("evaluation", {}).get("ground_truth_file")
    if not gt_path:
        return None
    if not os.path.exists(gt_path):
        return None
    gt = pd.read_csv(gt_path, parse_dates=["date"])
    gt = gt.set_index("date").reindex(t_ticks).fillna(0)
    # Expect a column 'incident' ∈ {0,1}
    col = "incident" if "incident" in gt.columns else gt.columns[0]
    return gt[col].astype(int)
