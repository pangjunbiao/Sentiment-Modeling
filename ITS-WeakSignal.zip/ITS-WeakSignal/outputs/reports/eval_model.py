from __future__ import annotations
import os, json
from typing import Dict, List, Optional
import numpy as np
import pandas as pd

# Try sklearn; fall back to light implementations if missing
try:
    from sklearn.metrics import roc_auc_score, average_precision_score
    _HAS_SK = True
except Exception:
    _HAS_SK = False

def precision_at_k(y_true: np.ndarray, y_score: np.ndarray, k: int = 10) -> float:
    order = np.argsort(-y_score)
    topk = order[:min(k, len(order))]
    return float(np.sum(y_true[topk])) / max(1, len(topk))

def leadtime_first_hit_hours(y_true: np.ndarray, y_score: np.ndarray, offsets_days: np.ndarray, k: int = 10):
    order = np.argsort(-y_score)[:min(k, len(y_score))]
    for idx in order:
        if (y_true[idx] == 1) and (offsets_days[idx] < 0):
            return float(-offsets_days[idx] * 24.0)
    return None



def _safe_auc(y_true, y_score) -> Optional[float]:
    y_true = np.asarray(y_true, dtype=int)
    y_score = np.asarray(y_score, dtype=float)
    # Need at least one pos and one neg
    if y_true.sum() == 0 or y_true.sum() == len(y_true):
        return None
    if _HAS_SK:
        return float(roc_auc_score(y_true, y_score))
    # Simple Mann–Whitney U based AUC
    pos = y_score[y_true == 1]; neg = y_score[y_true == 0]
    ranks = np.argsort(np.argsort(np.concatenate([pos, neg])))
    r_pos = ranks[:len(pos)].sum() + len(pos)  # 1-based correction
    auc = (r_pos - len(pos) * (len(pos) + 1) / 2) / (len(pos) * len(neg))
    return float(auc)


def _safe_precision(y_true, y_score) -> Optional[float]:
    """
    Calculate Precision = TP / (TP + FP)
    """
    y_true = np.asarray(y_true, dtype=int)
    y_score = np.asarray(y_score, dtype=float)

    # Positive predictions
    tp = np.sum((y_true == 1) & (y_score >= 0.5))  # True Positives
    fp = np.sum((y_true == 0) & (y_score >= 0.5))  # False Positives

    if tp + fp == 0:
        return None  # Avoid division by zero

    precision = tp / (tp + fp)
    return float(precision)

def _safe_ap(y_true, y_score) -> Optional[float]:
    y_true = np.asarray(y_true, dtype=int)
    y_score = np.asarray(y_score, dtype=float)
    if y_true.sum() == 0:
        return None
    if _HAS_SK:
        return float(average_precision_score(y_true, y_score))
    # PR AUC (AP) via sorted precisions
    order = np.argsort(-y_score)
    y_sorted = y_true[order]
    cum_tp = np.cumsum(y_sorted)
    precision = cum_tp / (np.arange(len(y_sorted)) + 1)
    ap = (precision * y_sorted).sum() / max(1, y_true.sum())
    return float(ap)

def _ensure_dir(p: str):
    os.makedirs(p, exist_ok=True)

def evaluate_model(cfg: Dict, logger,
                   topic_ids: Optional[List[int]] = None,
                   days: int = 7,
                   save_prefix: str = "eval_model") -> Dict:
    """
    Offline evaluation for the model severity S(t,k).
    Labels are defined INDEPENDENTLY of S using escalation E(t,k):
      - Within the ±days window around the E-peak (per topic),
        positives are days with E >= q90 in that window.
        (Fallback: top-1 E day if q90 yields zero positives.)

    Reports: ROC-AUC, AP, mean Precision, P@K (configurable K), and first-hit@K lead-time (hours).
    By default P@K is computed on the *early* subset (offset<0) to reflect early-warning quality.
    """
    paths = cfg["paths"]
    art_dir = os.path.join(paths["outputs_dir"], "artifacts")
    rep_dir = os.path.join(paths["outputs_dir"], "reports")
    _ensure_dir(rep_dir)

    # ---- config knobs ----
    p_at_k = int(cfg.get("evaluation", {}).get("p_at_k", 5))
    early_only = bool(cfg.get("evaluation", {}).get("p_atk_early_only", True))

    # ---- load artifacts ----
    A = np.load(os.path.join(art_dir, "A_TxK.npy"))   # T x K
    E = np.load(os.path.join(art_dir, "E_TxK.npy"))   # T x K

    S_path = os.path.join(art_dir, "S_eval_TxK.npy")
    if os.path.exists(S_path):
        S = np.load(S_path)  # leakage-free variant (recommended for metrics)
    else:
        S = np.load(os.path.join(art_dir, "S_TxK.npy"))

    time_index = pd.read_csv(os.path.join(art_dir, "time_index.csv"))["time_bin"].astype("datetime64[ns]")

    T, K = S.shape
    # Topic selection: if none passed, auto-pick Top-5 by max S
    if not topic_ids:
        ks = np.argsort(-S.max(axis=0))[:5]
        topic_ids = [int(k) for k in ks]
        logger.info(f"Model eval: auto-selected topics by max S → {topic_ids}")

    rows_all = []
    per_topic_paths = []

    for k in topic_ids:
        if k < 0 or k >= K:
            logger.warning(f"Topic id {k} out of range [0,{K-1}], skipping.")
            continue

        # Center on the **E-peak** (independent of S)
        t_e = int(np.argmax(E[:, k]))
        center_ts = pd.Timestamp(time_index.iloc[t_e])

        # Build full day-offset range and slice to available dates
        offsets = np.arange(-days, days + 1)
        want_days = pd.to_datetime([center_ts + pd.Timedelta(int(d), "D") for d in offsets])
        # Align to time_index
        ti = pd.Series(np.arange(T), index=time_index)
        idx = ti.reindex(want_days).values  # may contain NaN
        valid_mask = ~pd.isna(idx)
        idx_valid = idx[valid_mask].astype(int)
        off_valid = offsets[valid_mask]

        # Extract series
        A_win = A[idx_valid, k]
        E_win = E[idx_valid, k]
        S_win = S[idx_valid, k]

        # Labels: positives = E >= q90 within window (fallback: top-1 E)
        if len(E_win) == 0:
            logger.warning(f"Topic {k}: no data in window; skipping.")
            continue
        q90 = np.quantile(E_win, 0.90)
        y_true = (E_win >= q90).astype(int)
        if y_true.sum() == 0:
            y_true[np.argmax(E_win)] = 1

        # Scores for evaluation
        S_score = S_win.astype(float)
        E_score = E_win.astype(float)  # sanity AP if we rank by E itself

        # ---- main metrics (window-level) ----
        auc_S  = _safe_auc(y_true, S_score)
        ap_S   = _safe_ap(y_true, S_score)
        precision_S = _safe_precision(y_true, S_score)
        ap_E   = _safe_ap(y_true, E_score)

        # ---- P@K and first-hit@K (use early-only subset for P@K if configured) ----
        y_for_p = y_true
        s_for_p = S_score
        if early_only:
            m = (off_valid < 0)
            if np.any(m):
                y_for_p = y_true[m]
                s_for_p = S_score[m]
            # if no early points, we fall back to the full window (keeps a value)
        p_atk = precision_at_k(y_for_p, s_for_p, k=p_at_k)

        # first-hit only makes sense against the *full* ranked list; function already enforces offset<0
        fh_atk = leadtime_first_hit_hours(y_true, S_score, off_valid, k=p_at_k)
        fh_atk_capped = min(fh_atk, 72.0) if fh_atk is not None else None

        # Prevalence & lift (makes P@K interpretable)
        prevalence = float(y_true.mean())
        lift = (p_atk / prevalence) if prevalence > 0 else None

        # Save per-topic full series (always write full offsets; NaNs where missing)
        series_df = pd.DataFrame({
            "offset_day": offsets,
            "timestamp": want_days,
        })
        # Put values only for valid days
        series_df["A"] = np.nan; series_df.loc[valid_mask, "A"] = A_win
        series_df["E"] = np.nan; series_df.loc[valid_mask, "E"] = E_win
        series_df["log1pE"] = np.nan; series_df.loc[valid_mask, "log1pE"] = np.log1p(E_win.astype(np.float64))
        series_df["S"] = np.nan; series_df.loc[valid_mask, "S"] = S_win
        series_df["label_pos"] = 0; series_df.loc[valid_mask, "label_pos"] = y_true

        series_path = os.path.join(rep_dir, f"{save_prefix}_series_k{k}.csv")
        series_df.to_csv(series_path, index=False, encoding="utf-8-sig")

        # One-line metrics per topic
        one_df = pd.DataFrame([{
            "topic": k,
            "center_date": str(center_ts.date()),
            "n_days_in_window": int(valid_mask.sum()),
            "n_pos": int(int(y_true.sum())),
            "auc_S_vs_labels": None if auc_S is None else round(auc_S, 6),
            "ap_S_vs_labels":  None if ap_S is None else round(ap_S, 6),
            "precision_S_vs_labels": None if precision_S is None else round(precision_S, 6),
            "ap_E_vs_labels":  None if ap_E is None else round(ap_E, 6),
            "p_at_k": None if p_atk is None else round(p_atk, 6),
            "first_hit_topk_h": None if fh_atk is None else round(fh_atk, 3),
            "first_hit_topk_h_capped": None if fh_atk_capped is None else round(fh_atk_capped, 3),
            "prevalence": round(prevalence, 6),
            "lift_p_at_k": None if lift is None else round(lift, 3),
        }])
        one_path = os.path.join(rep_dir, f"{save_prefix}_k{k}.csv")
        one_df.to_csv(one_path, index=False, encoding="utf-8-sig")

        rows_all.append(one_df.iloc[0].to_dict())
        per_topic_paths.append((series_path, one_path))

    # ---- summarize ----
    if not rows_all:
        logger.warning("Model eval: no topics evaluated; nothing to summarize.")
        return {"rows": 0}

    rows_df = pd.DataFrame(rows_all)
    rows_path = os.path.join(rep_dir, f"{save_prefix}_rows.csv")
    rows_df.to_csv(rows_path, index=False, encoding="utf-8-sig")

    def _mean_std(col):
        x = rows_df[col].dropna().astype(float)
        if len(x) == 0: return (None, None)
        return float(x.mean()), float(x.std(ddof=0))

    m_auc, s_auc   = _mean_std("auc_S_vs_labels")
    m_ap,  s_ap    = _mean_std("ap_S_vs_labels")
    m_apE, s_apE   = _mean_std("ap_E_vs_labels")
    m_prec, s_prec = _mean_std("precision_S_vs_labels")

    def _mean_std_float(col, zero_fill=False):
        x = rows_df[col].astype(float)
        x = x.fillna(0.0) if zero_fill else x.dropna()
        if len(x) == 0: return (None, None)
        return float(x.mean()), float(x.std(ddof=0))

    m_p,  s_p   = _mean_std_float("p_at_k")
    m_fh, s_fh  = _mean_std_float("first_hit_topk_h")            # topics with an early hit
    m_fh0,s_fh0 = _mean_std_float("first_hit_topk_h", True)      # zero-fill: “no early hit” = 0h

    summary = {
        "topics_evaluated": int(len(rows_df)),
        "mean_auc_S": None if m_auc is None else round(m_auc, 6),
        "std_auc_S":  None if s_auc is None else round(s_auc, 6),
        "mean_ap_S":  None if m_ap  is None else round(m_ap, 6),
        "std_ap_S":   None if s_ap  is None else round(s_ap, 6),
        "mean_ap_E":  None if m_apE is None else round(m_apE, 6),
        "std_ap_E":   None if s_apE is None else round(s_apE, 6),
        "mean_precision_S": None if m_prec is None else round(m_prec, 6),
        "std_precision_S":  None if s_prec is None else round(s_prec, 6),
        "mean_p_at_k":      None if m_p   is None else round(m_p, 6),
        "std_p_at_k":       None if s_p   is None else round(s_p, 6),
        "mean_first_hit_topk_h":         None if m_fh  is None else round(m_fh, 3),
        "std_first_hit_topk_h":          None if s_fh  is None else round(s_fh, 3),
        "mean_first_hit_topk_h_zerofill":None if m_fh0 is None else round(m_fh0, 3),
        "std_first_hit_topk_h_zerofill": None if s_fh0 is None else round(s_fh0, 3),
        "p_at_k_used": p_at_k,
        "p_atk_early_only": early_only,
    }

    # Save the summary to CSV
    summ_path = os.path.join(rep_dir, f"{save_prefix}_summary.csv")
    pd.DataFrame([summary]).to_csv(summ_path, index=False, encoding="utf-8-sig")

    # Console line
    msg = (
        f"Model eval (S vs E-derived labels): topics={summary['topics_evaluated']}, "
        f"mean AUC={summary['mean_auc_S']}±{summary['std_auc_S']}, "
        f"mean AP={summary['mean_ap_S']}±{summary['std_ap_S']} "
        f"(sanity AP[E]={summary['mean_ap_E']}±{summary['std_ap_E']})"
        f", P@{p_at_k}={summary['mean_p_at_k']} "
        f"(first-hit@{p_at_k}_h={summary['mean_first_hit_topk_h']} | zero-fill={summary['mean_first_hit_topk_h_zerofill']})"
        f"  [early_only={early_only}]"
    )
    logger.info(msg)
    return {"rows_csv": rows_path, "summary_csv": summ_path}

