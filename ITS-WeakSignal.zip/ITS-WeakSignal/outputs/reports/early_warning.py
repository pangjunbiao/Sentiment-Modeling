# outputs/reports/early_warning.py
from __future__ import annotations
import os
from typing import Dict, Tuple, List
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import precision_recall_curve, average_precision_score

# ============================================================
# Helpers
# ============================================================

def _ensure_dirs(base_outputs_dir: str) -> Tuple[str, str, str]:
    """
    Returns:
      ew_art_dir: where we SAVE early-warning figures  (outputs/artifacts/early_warning)
      rep_dir:    where we SAVE early-warning CSVs     (outputs/reports/early_warning)
      base_art:   where we LOAD shared artifacts from  (outputs/artifacts)
    """
    ew_art_dir = os.path.join(base_outputs_dir, "artifacts", "early_warning")
    rep_dir    = os.path.join(base_outputs_dir, "reports",  "early_warning")
    base_art   = os.path.join(base_outputs_dir, "artifacts")
    os.makedirs(ew_art_dir, exist_ok=True)
    os.makedirs(rep_dir,   exist_ok=True)
    return ew_art_dir, rep_dir, base_art

def _load_time_index(base_art_dir: str) -> pd.Series:
    csv_path = os.path.join(base_art_dir, "time_index.csv")
    npy_path = os.path.join(base_art_dir, "time_index_T.npy")
    if os.path.exists(csv_path):
        s = pd.read_csv(csv_path)
        col = "time_bin" if "time_bin" in s.columns else s.columns[0]
        return pd.to_datetime(s[col])
    if os.path.exists(npy_path):
        return pd.to_datetime(np.load(npy_path, allow_pickle=True))
    raise FileNotFoundError(f"Missing time index. Looked for {csv_path} and {npy_path}.")

def _ema_along_time(X: np.ndarray, alpha: float) -> np.ndarray:
    """EMA along time for each column; X shape (T, K)."""
    T, K = X.shape
    Y = np.empty_like(X, dtype=float)
    Y[0] = X[0]
    one_minus = 1.0 - alpha
    for t in range(1, T):
        Y[t] = alpha * X[t] + one_minus * Y[t-1]
    return Y

def _topk_by_max(S: np.ndarray, k: int) -> List[int]:
    return list(np.argsort(-S.max(axis=0))[:k].astype(int))

def _build_day_labels_from_E_peaks(
    E: np.ndarray, top_k_ids: List[int], pos_half_width: int
) -> Tuple[np.ndarray, List[Tuple[int,int]]]:
    """Union of windows around each topic’s E-peak."""
    T = E.shape[0]
    labels = np.zeros(T, dtype=int)
    windows: List[Tuple[int,int]] = []
    for k in top_k_ids:
        c = int(np.argmax(E[:, k]))
        lo = max(0, c - pos_half_width)
        hi = min(T-1, c + pos_half_width)
        labels[lo:hi+1] = 1
        windows.append((lo, hi))
    return labels, windows

def _aggregate_series(X: np.ndarray, k_ids: List[int], alpha: float, how: str = "max") -> np.ndarray:
    """Smooth per-topic, then aggregate across topics into ONE daily score."""
    Xk_ema = _ema_along_time(X[:, k_ids], alpha=alpha)
    return (Xk_ema.sum(axis=1) if how == "sum" else Xk_ema.max(axis=1)).astype(float)

def _lead_time_stats(y_hat: np.ndarray, windows: List[Tuple[int,int]], time_index: pd.Series) -> Tuple[float, float, int]:
    """Mean/STD lead-time in days across event windows."""
    leads = []
    for (lo, hi) in windows:
        idxs = np.where(y_hat == 1)[0]
        if idxs.size == 0: continue
        cand = idxs[idxs <= hi]
        if cand.size == 0: continue
        t_alarm = cand[0]
        dt = (time_index.iloc[t_alarm] - time_index.iloc[lo]) / np.timedelta64(1, "D")
        leads.append(float(dt))
    if len(leads) == 0:
        return float("nan"), float("nan"), 0
    arr = np.array(leads, dtype=float)
    return float(np.nanmean(arr)), float(np.nanstd(arr, ddof=1) if arr.size > 1 else 0.0), int(len(leads))

# ============================================================
# Core R6
# ============================================================

def _methods_available(base_art: str) -> Dict[str, np.ndarray]:
    """Load matrices needed for methods."""
    out = {}
    s_p = os.path.join(base_art, "S_TxK.npy")
    e_p = os.path.join(base_art, "E_TxK.npy")
    v_p = os.path.join(base_art, "frequency_TxK.npy")  # optional baseline
    if os.path.exists(s_p): out["S"] = np.load(s_p)
    if os.path.exists(e_p): out["E"] = np.load(e_p)
    if os.path.exists(v_p): out["V"] = np.load(v_p)
    if "S" not in out or "E" not in out:
        missing = [nm for nm in ["S_TxK.npy","E_TxK.npy"] if not os.path.exists(os.path.join(base_art, nm))]
        raise FileNotFoundError(f"Missing required artifact(s): {missing}.")
    return out

def compute_r6(cfg: Dict, logger) -> Dict[str, str]:
    """
    Builds day-level labels from E-peaks (Top-K, ±pos_half_width),
    generates multi-method PR curves, per-threshold metrics with mean lead time,
    a summary CSV, and an F1–threshold figure (quantile x-axis).
    """
    outputs_dir = cfg["paths"]["outputs_dir"]
    ew_art_dir, rep_dir, base_art = _ensure_dirs(outputs_dir)
    time_index = _load_time_index(base_art)

    mats = _methods_available(base_art)
    S = mats["S"]; E = mats["E"]; V = mats.get("V", None)

    # params
    topk           = int(cfg.get("evaluation", {}).get("topk", 5))
    pos_half_width = int(cfg.get("evaluation", {}).get("pos_half_width", 1))
    alpha          = float(cfg.get("evaluation", {}).get("alpha", 0.1))      # EMA
    agg_how        = str(cfg.get("evaluation", {}).get("ew_aggregate", "max"))  # "max" | "sum"

    # labels
    k_ids = _topk_by_max(S, topk)
    y_true_T, windows = _build_day_labels_from_E_peaks(E, k_ids, pos_half_width)

    # methods to compare
    methods_series: Dict[str, np.ndarray] = {
        "EMA(S)": _aggregate_series(S, k_ids, alpha=alpha, how=agg_how),
        "EMA(E)": _aggregate_series(E, k_ids, alpha=alpha, how=agg_how),
    }
    if V is not None:
        methods_series["EMA(Volume)"] = _aggregate_series(V, k_ids, alpha=alpha, how=agg_how)

    # PR curves + AP
    pr_curves: Dict[str, Dict[str, np.ndarray]] = {}
    summary_rows = []

    # Quantile grid for fair threshold sweep & F1–threshold plot
    q_grid = np.linspace(0.50, 0.99, 50)

    # Collect for companion plot (quantile -> F1)
    f1_lines: Dict[str, Tuple[np.ndarray, np.ndarray]] = {}

    for mname, series in methods_series.items():
        # PR from continuous scores
        precision, recall, _ = precision_recall_curve(y_true_T, series)
        ap = float(average_precision_score(y_true_T, series))
        pr_curves[mname] = {"precision": precision, "recall": recall, "AP": ap}

        # Threshold sweep on quantiles (and keep q for plot)
        ths = np.unique(np.quantile(series, q_grid))
        rows = []
        f1_vals = []
        qs_used = []
        best = {"f1": -1.0, "threshold": np.nan, "precision": 0.0, "recall": 0.0,
                "lead_mean": np.nan, "lead_std": np.nan, "lead_n": 0, "q": np.nan}

        for th in ths:
            q = float((series <= th).mean())  # empirical quantile of this threshold on the series
            y_hat = (series >= th).astype(int)

            tp = int(((y_hat == 1) & (y_true_T == 1)).sum())
            fp = int(((y_hat == 1) & (y_true_T == 0)).sum())
            fn = int(((y_hat == 0) & (y_true_T == 1)).sum())
            prec = tp / (tp + fp) if (tp + fp) > 0 else 0.0
            rec  = tp / (tp + fn) if (tp + fn) > 0 else 0.0
            f1   = (2*prec*rec/(prec+rec)) if (prec+rec) > 0 else 0.0

            lead_mean, lead_std, lead_n = _lead_time_stats(y_hat, windows, time_index)

            rows.append({
                "method": mname,
                "threshold": float(th),
                "quantile": q,
                "precision": float(prec),
                "recall": float(rec),
                "f1": float(f1),
                "lead_time_mean_days": lead_mean,
                "lead_time_std_days": lead_std,
                "lead_time_n_events": int(lead_n),
                "tp": tp, "fp": fp, "fn": fn
            })
            f1_vals.append(f1); qs_used.append(q)

            if f1 > best["f1"]:
                best.update({
                    "f1": float(f1), "threshold": float(th), "precision": float(prec),
                    "recall": float(rec), "lead_mean": lead_mean, "lead_std": lead_std,
                    "lead_n": int(lead_n), "q": q
                })

        # save per-threshold CSV
        per_thr = pd.DataFrame(rows).sort_values("quantile").reset_index(drop=True)
        per_thr.to_csv(
            os.path.join(rep_dir, f"R6_per_threshold_{mname.replace('(','').replace(')','').replace(' ','_')}.csv"),
            index=False
        )

        # store for F1–threshold plot
        f1_lines[mname] = (np.array(qs_used), np.array(f1_vals))

        # add to summary
        summary_rows.append({
            "method": mname,
            "AP": ap,
            "best_f1": best["f1"],
            "best_threshold": best["threshold"],
            "best_threshold_quantile": best["q"],
            "best_precision": best["precision"],
            "best_recall": best["recall"],
            "lead_time_at_best_mean_days": best["lead_mean"],
            "lead_time_at_best_std_days":  best["lead_std"],
            "lead_time_at_best_n_events":  best["lead_n"],
        })

    # ---------- PR figure (multi-curve) ----------
    # ---------- PR figure (multi-curve) ----------
    # ---------- PR figure (multi-curve) ----------
    # ---------- PR figure (multi-curve) ----------
    # ---------- PR figure (multi-curve) ----------
    plt.figure(figsize=(6.6, 5.2))

    # map method -> best point from summary_rows (computed above)
    best_map = {row["method"]: row for row in summary_rows}

    # add baseline prevalence (positives rate)
    prevalence = float(np.mean(y_true_T))
    plt.axhline(prevalence, linestyle="--", linewidth=1.0, alpha=0.6, color="gray",
                label=f"Prevalence = {prevalence:.3f}")

    for mname, d in pr_curves.items():
        r = d["recall"]
        p = d["precision"]

        # Remove the artificial (recall=0, precision=1) anchor from the PLOT only
        if len(r) > 0 and r[0] == 0.0:
            r = r[1:];
            p = p[1:]

        # Make EMA(E) dashed to signal it's an oracle-like baseline (labels derived from E)
        ls = "--" if mname == "EMA(E)" else "-"

        (line,) = plt.plot(r, p, lw=1.8, linestyle=ls, label=f"{mname} (AP={d['AP']:.3f})")
        color = line.get_color()

        # Best-F1 operating point marker
        best = best_map.get(mname)
        if best is not None and np.isfinite(best["best_precision"]) and np.isfinite(best["best_recall"]):
            plt.scatter(best["best_recall"], best["best_precision"], s=40, marker="o", color=color, zorder=3)

    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title("Early-Warning Precision–Recall")
    plt.legend(loc="upper right")
    plt.grid(True, linestyle="--", linewidth=0.5, alpha=0.6)
    plt.tight_layout()
    pr_path = os.path.join(ew_art_dir, "R6_PR_multicurve.png")
    plt.savefig(pr_path, dpi=300)
    plt.close()

    # ---------- F1–Threshold (quantile) companion figure ----------
    # ---------- F1–Threshold (quantile) companion figure ----------
    plt.figure(figsize=(6.6, 5.2))

    # map method -> best row from summary_rows
    best_map = {row["method"]: row for row in summary_rows}

    for mname, (qs, f1s) in f1_lines.items():
        idx = np.argsort(qs)  # clean line
        best = best_map.get(mname, None)

        # Build a legend label that includes best F1 and its quantile
        if best is not None and np.isfinite(best["best_f1"]):
            label = f"{mname} (best F1={best['best_f1']:.3f}, q={best['best_threshold_quantile']:.2f})"
        else:
            label = mname

        plt.plot(qs[idx], f1s[idx], lw=1.8, label=label)

    plt.xlabel("Threshold quantile (higher → stricter)")
    plt.ylabel("F1 score")
    plt.title("F1 vs. Threshold (Quantile scale)")
    plt.legend(loc="upper left")  # as requested
    plt.grid(True, linestyle="--", linewidth=0.5, alpha=0.6)
    plt.tight_layout()
    f1_path = os.path.join(ew_art_dir, "R6_F1_vs_threshold.png")
    plt.savefig(f1_path, dpi=300)
    plt.close()

    # ---------- Save PR points & summary ----------
    for mname, d in pr_curves.items():
        pd.DataFrame({"recall": d["recall"], "precision": d["precision"]}).to_csv(
            os.path.join(rep_dir, f"R6_prcurve_{mname.replace('(','').replace(')','').replace(' ','_')}.csv"),
            index=False
        )

    summary_df = pd.DataFrame(summary_rows)
    summary_path = os.path.join(rep_dir, "R6_summary.csv")
    summary_df.to_csv(summary_path, index=False)

    return {
        "pr_figure": pr_path,
        "f1_figure": f1_path,
        "summary_csv": summary_path,
        "per_threshold_dir": rep_dir,
    }

# ============================================================
# Entrypoint for main.py
# ============================================================

def generate_early_warning_alarms(cfg: Dict, logger) -> Dict[str, str]:
    """
    Orchestrates the full R6 step and returns output paths.
    Outputs:
      artifacts/early_warning/R6_PR_multicurve.png
      artifacts/early_warning/R6_F1_vs_threshold.png
      reports/early_warning/R6_summary.csv
      reports/early_warning/R6_per_threshold_<Method>.csv
      reports/early_warning/R6_prcurve_<Method>.csv
    """
    res = compute_r6(cfg, logger)
    logger.info(f"R6 PR figure → {os.path.abspath(res['pr_figure'])}")
    logger.info(f"R6 F1–threshold figure → {os.path.abspath(res['f1_figure'])}")
    logger.info(f"R6 summary → {os.path.abspath(res['summary_csv'])}")
    logger.info(f"R6 per-threshold/PR CSVs in → {os.path.abspath(res['per_threshold_dir'])}")
    return res
