from __future__ import annotations
import os
from typing import Dict, Optional
import numpy as np
import pandas as pd

from outputs.reports.baseline_utils import (
    _ensure_dir, load_artifacts, choose_center, make_window, load_posts_with_timebins,
    soft_membership_one_topic, add_ground_truth_if_available
)

def _compute_sentiment(series: pd.Series) -> np.ndarray:
    # Try SnowNLP, otherwise simple neutral fallback
    try:
        from snownlp import SnowNLP
        return np.array([SnowNLP(str(x)).sentiments if isinstance(x, str) else 0.5 for x in series], dtype=float)
    except Exception:
        return np.full((len(series),), 0.5, dtype=float)

def run_baseline_sentiment_mean(cfg: Dict, logger, topic_id: Optional[int], center_date: Optional[str], days: int = 7):
    A, E, S, U, vocab, time_index = load_artifacts(cfg)
    k, center_ts = choose_center(topic_id, center_date, S, time_index)
    t_slice, t_ticks, x = make_window(time_index, center_ts, days)

    A_k = A[t_slice, k]
    E_k_plot = np.log1p(E[t_slice, k].astype(np.float64))
    S_k = S[t_slice, k]

    df_posts = load_posts_with_timebins(cfg, win=cfg["time"]["window"])
    df_win = df_posts[df_posts["time_bin"].isin(t_ticks)].copy()

    min_len = int(cfg["features"].get("min_token_len", 2))
    df_win["theta_k"] = soft_membership_one_topic(df_win["text"].tolist(), vocab, U, k, min_len)
    df_win["sent"] = _compute_sentiment(df_win["text"])

    # soft-weighted mean sentiment per day
    def _soft_mean(g):
        w = g["theta_k"].to_numpy(dtype=float)
        s = g["sent"].to_numpy(dtype=float)
        ws = np.sum(w)
        return float(np.sum(w * s) / ws) if ws > 0 else 0.5

    mean_sent = df_win.groupby("time_bin").apply(_soft_mean).reindex(t_ticks, fill_value=0.5).to_numpy()

    df_daily = pd.DataFrame({
        "time_bin": t_ticks, "day_offset": x,
        "A": A_k, "log1pE": E_k_plot, "S": S_k,
        "mean_sent_soft": mean_sent
    })

    out_dir = os.path.join(cfg["paths"]["outputs_dir"], "reports", "baselines")
    _ensure_dir(out_dir)
    daily_path = os.path.join(out_dir, f"baseline_sentiment_mean_daily_k{k}_center_{center_ts.date()}.csv")
    df_daily.to_csv(daily_path, index=False, encoding="utf-8-sig")

    # optional evaluation
    metrics = {"topic": int(k), "center_date": str(center_ts.date()), "days": int(days),
               "mean_of_daily_means": float(mean_sent.mean())}
    y = add_ground_truth_if_available(cfg, t_ticks)
    if y is not None:
        try:
            from sklearn.metrics import roc_auc_score, average_precision_score
            # Lower sentiment might correspond to incidents; use (1 - mean_sent) as a score
            metrics["AUC_1_minus_mean_sent"] = float(roc_auc_score(y, 1.0 - mean_sent))
            metrics["AP_1_minus_mean_sent"] = float(average_precision_score(y, 1.0 - mean_sent))
        except Exception:
            pass

    metrics_path = os.path.join(out_dir, f"baseline_sentiment_mean_metrics_k{k}_center_{center_ts.date()}.csv")
    pd.DataFrame([metrics]).to_csv(metrics_path, index=False, encoding="utf-8-sig")

    logger.info(f"Baseline(sentiment_mean) saved → {daily_path} and {metrics_path}")
    return {"daily": daily_path, "metrics": metrics_path, "topic": k, "center": str(center_ts)}
