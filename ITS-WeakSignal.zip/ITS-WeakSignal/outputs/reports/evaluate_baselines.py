from __future__ import annotations
import os, math
from typing import Dict, List, Optional, Tuple
import numpy as np
import pandas as pd

# --- Optional metric deps (we fall back to light versions if missing) ---
try:
    from sklearn.metrics import roc_auc_score, average_precision_score
    _HAS_SK = True
except Exception:
    _HAS_SK = False

try:
    from scipy.stats import rankdata, spearmanr
    _HAS_SCIPY = True
except Exception:
    _HAS_SCIPY = False

from outputs.reports.baseline_utils import (
    load_artifacts, choose_center, make_window, load_posts_with_timebins,
    soft_membership_one_topic, _ensure_dir
)

# ------------------- small metric helpers (robust fallbacks) -------------------
def _safe_auc(y_true, y_score) -> Optional[float]:
    y_true = np.asarray(y_true, dtype=int)
    y_score = np.asarray(y_score, dtype=float)
    # need both classes present
    if y_true.sum() == 0 or y_true.sum() == len(y_true):
        return None
    if _HAS_SK:
        return float(roc_auc_score(y_true, y_score))
    # Mann–Whitney U definition of AUC
    pos = y_score[y_true == 1]; neg = y_score[y_true == 0]
    if len(pos) == 0 or len(neg) == 0: return None
    all_scores = np.concatenate([pos, neg])
    if _HAS_SCIPY:
        r = rankdata(all_scores, method="average")
    else:
        r = all_scores.argsort().argsort().astype(float) + 1.0  # 1-based approx
    r_pos = r[:len(pos)].sum()
    auc = (r_pos - len(pos) * (len(pos) + 1) / 2) / (len(pos) * len(neg))
    return float(auc)

def _safe_ap(y_true, y_score) -> Optional[float]:
    y_true = np.asarray(y_true, dtype=int)
    y_score = np.asarray(y_score, dtype=float)
    P = int(y_true.sum())
    if P == 0: return None
    if _HAS_SK:
        return float(average_precision_score(y_true, y_score))
    order = np.argsort(-y_score)
    y_sorted = y_true[order]
    cum_tp = np.cumsum(y_sorted)
    precision = cum_tp / (np.arange(len(y_sorted)) + 1)
    ap = float((precision * y_sorted).sum() / P)
    return ap

def _safe_spearman(x, y) -> Optional[float]:
    x = np.asarray(x, dtype=float); y = np.asarray(y, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y)
    x = x[mask]; y = y[mask]
    if len(x) < 3: return None
    if _HAS_SCIPY:
        return float(spearmanr(x, y, nan_policy="omit").correlation)
    # fallback: rank both, then Pearson on ranks
    def _rank(v):
        if _HAS_SCIPY: return rankdata(v, method="average")
        # simple average ranks for ties
        order = v.argsort()
        ranks = np.empty_like(order, dtype=float)
        ranks[order] = np.arange(1, len(v)+1, dtype=float)
        return ranks
    rx = _rank(x); ry = _rank(y)
    rx = (rx - rx.mean())/ (rx.std(ddof=0) + 1e-12)
    ry = (ry - ry.mean())/ (ry.std(ddof=0) + 1e-12)
    return float((rx*ry).mean())

# ------------------- label construction (E-derived, configurable) -------------------
def _make_labels_from_E(offsets, E_win, label_mode: str, pos_half_width: int = 1) -> np.ndarray:
    offsets = np.asarray(offsets, dtype=int)
    E_win   = np.asarray(E_win, dtype=float)
    y = np.zeros_like(offsets, dtype=int)
    if E_win.size == 0:
        return y

    if str(label_mode).startswith("peak_pm"):
        h = int(pos_half_width)
        peak_idx = int(np.argmax(E_win))
        peak_off = int(offsets[peak_idx])
        y[np.abs(offsets - peak_off) <= h] = 1
        return y

    # default: q90 with top-1 fallback
    q = float(np.nanquantile(E_win, 0.90))
    y[E_win >= q] = 1
    if y.sum() == 0:
        y[int(np.argmax(E_win))] = 1
    return y


# ------------------- core evaluator -------------------
def evaluate_baselines(cfg: Dict, logger,
                       topic_ids: Optional[List[int]] = None,
                       days: int = 7,
                       save_prefix: str = "eval_baselines") -> Dict:
    """
    Compute AUC, AP, lead-time, and Spearman correlation for:
      - S (severity)
      - volume_z (raw daily post count z-scored within window)
      - soft_volume (sum of topic-membership per day)
      - soft_volume_weighted (sum of w_base * membership per day)
      - inv_mean_sent = 1 - mean_sent_soft (lower sentiment → higher risk)
    Labels are **E-derived** in-window, using config:
      evaluation.label_mode: "peak_pm1" (default) or "q90"
      evaluation.pos_half_width: integer (for peak_pmH)
    Windows are **centered at each topic’s S-peak** to reflect lead/lag vs S.
    """
    # config
    eval_cfg = cfg.get("evaluation", {})
    label_mode = str(eval_cfg.get("label_mode", "peak_pm1")).strip()
    pos_half_width = int(eval_cfg.get("pos_half_width", 1))

    paths = cfg["paths"]
    rep_dir = os.path.join(paths["outputs_dir"], "reports"); _ensure_dir(rep_dir)
    out_dir = os.path.join(rep_dir, "baseline_eval"); _ensure_dir(out_dir)

    # artifacts & posts
    A, E, S, U, vocab, time_index = load_artifacts(cfg)
    T, K = S.shape
    df_posts = load_posts_with_timebins(cfg, win=cfg["time"]["window"])
    min_len = int(cfg["features"].get("min_token_len", 2))

    # topic selection: if none, auto Top-5 by max S (headline set)
    if not topic_ids:
        ks = np.argsort(-S.max(axis=0))[:int(eval_cfg.get("topk", 5))]
        topic_ids = [int(k) for k in ks]
        logger.info(f"Baseline eval: auto-selected topics by max S → {topic_ids}")

    # long-format rows for tidy plotting later
    long_rows: List[Dict] = []

    # also keep per-topic/ per-method peak offsets (lead-time) for the boxplot
    methods = ["S", "volume_z", "soft_volume", "soft_volume_weighted", "inv_mean_sent"]

    for k in topic_ids:
        if not (0 <= k < K):
            logger.warning(f"Topic {k} out of range [0,{K-1}], skipping.")
            continue

        # --- window centered at S-peak for topic k ---
        k, center_ts = choose_center(topic_id=k, center_date=None, S=S, time_index=time_index)
        t_slice, t_ticks, offsets = make_window(time_index, center_ts, days)

        # make sure offsets are a plain NumPy int array (not a pandas Series)
        if isinstance(offsets, pd.Series):
            offsets = offsets.to_numpy(dtype=int)
        else:
            offsets = np.asarray(offsets, dtype=int)

        # core series in-window
        S_k   = S[t_slice, k].astype(float)
        E_k   = E[t_slice, k].astype(float)
        A_k   = A[t_slice, k].astype(float)  # not a baseline metric here, but available if needed

        # baselines built from posts in this window
        df_win = df_posts[df_posts["time_bin"].isin(t_ticks)].copy()

        # volume & z-score
        day_counts = df_win["time_bin"].value_counts().sort_index().reindex(t_ticks, fill_value=0).astype(int)
        vol = day_counts.values.astype(float)
        vol_z = (vol - vol.mean()) / (vol.std(ddof=0) if vol.std(ddof=0) > 0 else 1.0)

        # soft memberships and influence-weighted
        theta_k = soft_membership_one_topic(df_win["text"].tolist(), vocab, U, k, min_len)
        df_win["theta_k"] = theta_k
        soft_vol = df_win.groupby("time_bin")["theta_k"].sum().reindex(t_ticks, fill_value=0.0).to_numpy()

        w = df_win["w_base"].fillna(0.0).astype(float).to_numpy() if "w_base" in df_win.columns else np.zeros(len(df_win))
        df_win["wt"] = df_win["theta_k"] * (df_win["w_base"].fillna(0.0).astype(float))
        soft_vol_w = df_win.groupby("time_bin")["wt"].sum().reindex(t_ticks, fill_value=0.0).to_numpy()

        # soft-weighted mean sentiment, then invert
        # compute sentiment lazily and cache-like to avoid heavy calls
        def _compute_sent(series: pd.Series) -> np.ndarray:
            try:
                from snownlp import SnowNLP
                return np.array([SnowNLP(str(x)).sentiments if isinstance(x, str) else 0.5 for x in series], dtype=float)
            except Exception:
                return np.full((len(series),), 0.5, dtype=float)

        df_win["sent"] = _compute_sent(df_win["text"])
        def _soft_mean(g: pd.DataFrame) -> float:
            w = g["theta_k"].to_numpy(dtype=float)
            s = g["sent"].to_numpy(dtype=float)
            ws = float(w.sum())
            return float((w * s).sum() / ws) if ws > 0 else 0.5

        mean_sent_soft = df_win.groupby("time_bin").apply(_soft_mean).reindex(t_ticks, fill_value=0.5).to_numpy()
        inv_mean_sent = 1.0 - mean_sent_soft

        # labels from E in-window, per config
        y_true = _make_labels_from_E(offsets, E_k, label_mode=label_mode, pos_half_width=pos_half_width)

        # for each method, compute metrics
        series_map = {
            "S": S_k,
            "volume_z": vol_z,
            "soft_volume": soft_vol,
            "soft_volume_weighted": soft_vol_w,
            "inv_mean_sent": inv_mean_sent
        }

        # lead time: peak offset relative to S-peak offset (which is 0 by construction)
        # still compute S's own argmax in case S has ties/plateau; we keep offset 0 for S
        s_peak_off = int(offsets[int(np.argmax(S_k))]) if len(S_k) else 0

        for mname, mvals in series_map.items():
            auc = _safe_auc(y_true, mvals)
            ap  = _safe_ap(y_true,  mvals)
            # peak offset of this method
            m_peak_off = int(offsets[int(np.argmax(mvals))]) if len(mvals) else 0
            lead = int(m_peak_off - s_peak_off)
            # Spearman vs S
            rho = _safe_spearman(mvals, S_k)

            long_rows.append({
                "topic": int(k),
                "center_date": str(center_ts.date()),
                "days": int(days),
                "label_mode": label_mode,
                "pos_half_width": int(pos_half_width),
                "method": mname,
                "auc": None if auc is None else float(auc),
                "ap":  None if ap  is None else float(ap),
                "lead_offset_days_vs_S": int(lead),
                "spearman_vs_S": None if rho is None else float(rho),
                "n_days_in_window": int(len(offsets)),
                "n_pos": int(y_true.sum())
            })

    if not long_rows:
        logger.warning("Baseline eval: no rows computed; check topics/data.")
        return {"rows": 0}

    # write long-format rows
    rows_df = pd.DataFrame(long_rows)
    rows_path = os.path.join(out_dir, f"{save_prefix}_rows_long.csv")
    rows_df.to_csv(rows_path, index=False, encoding="utf-8-sig")

    # compute a compact summary per method (mean ± std across topics)
    def _agg(df: pd.DataFrame, col: str) -> Tuple[Optional[float], Optional[float]]:
        x = df[col].dropna().astype(float)
        if len(x) == 0:
            return (None, None)
        return float(x.mean()), float(x.std(ddof=0))

    summaries = []
    for m in rows_df["method"].unique():
        sub = rows_df[rows_df["method"] == m]

        m_auc, s_auc = _agg(sub, "auc")
        m_ap, s_ap = _agg(sub, "ap")

        # lead: report median (robust) and IQR (also keep mean/std)
        lead_vals = sub["lead_offset_days_vs_S"].dropna().astype(float)
        if len(lead_vals):
            lead_mean = float(lead_vals.mean());
            lead_std = float(lead_vals.std(ddof=0))
            lead_med = float(lead_vals.median())
            q25, q75 = float(lead_vals.quantile(0.25)), float(lead_vals.quantile(0.75))
        else:
            lead_mean = lead_std = lead_med = q25 = q75 = None

        rho_mean, rho_std = _agg(sub, "spearman_vs_S")

        summaries.append({
            "method": m,
            "mean_auc": m_auc, "std_auc": s_auc,
            "mean_ap": m_ap, "std_ap": s_ap,
            "lead_mean": lead_mean, "lead_std": lead_std,
            "lead_median": lead_med, "lead_q25": q25, "lead_q75": q75,
            "mean_spearman_vs_S": rho_mean, "std_spearman_vs_S": rho_std,
            "topics_evaluated": int(len(sub["topic"].unique()))
        })

    summ_df = pd.DataFrame(summaries)
    summ_path = os.path.join(out_dir, f"{save_prefix}_summary.csv")
    summ_df.to_csv(summ_path, index=False, encoding="utf-8-sig")

    # ---- extra: concise per-method AUC/AP print + slim CSV ----
    print("\nPer-method AUC/AP (mean ± std across topics):")
    order = ["S", "volume_z", "soft_volume", "soft_volume_weighted", "inv_mean_sent"]
    for m in order:
        row = summ_df[summ_df["method"] == m]
        if not row.empty:
            auc_m, auc_s = row["mean_auc"].values[0], row["std_auc"].values[0]
            ap_m,  ap_s  = row["mean_ap"].values[0],  row["std_ap"].values[0]
            print(f"  {m:24s} AUC={auc_m:.3f}±{auc_s:.3f} | AP={ap_m:.3f}±{ap_s:.3f}")

    slim = summ_df[["method","mean_auc","std_auc","mean_ap","std_ap"]].copy()
    slim_path = os.path.join(out_dir, f"{save_prefix}_methods_auc_ap.csv")
    slim.to_csv(slim_path, index=False, encoding="utf-8-sig")

    # console line (short)
    # show S vs the strongest baseline (soft_volume_weighted) if present
    def _fmt(m, col):
        v = summ_df.loc[summ_df["method"] == m, col]
        return None if v.empty else float(v.values[0])

    s_auc = _fmt("S", "mean_auc"); s_ap = _fmt("S", "mean_ap")
    b_auc = _fmt("soft_volume_weighted", "mean_auc"); b_ap = _fmt("soft_volume_weighted", "mean_ap")

    msg = "Baseline eval: "
    msg += f"S (mean AUC={s_auc:.3f}, AP={s_ap:.3f}); " if s_auc is not None and s_ap is not None else ""
    if b_auc is not None and b_ap is not None:
        msg += f"best baseline (soft_vol_wt) AUC={b_auc:.3f}, AP={b_ap:.3f}."
    else:
        msg += "see CSV summaries for details."
    print(msg)

    return {"rows_csv": rows_path, "summary_csv": summ_path}
