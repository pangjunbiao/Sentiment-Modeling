# src/figures/case_study.py
from __future__ import annotations
import os, json, re
from typing import Dict, List, Optional
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import jieba
from matplotlib import font_manager as fm, rcParams

def _set_cjk_font(cfg=None):
    """
    Pick an installed CJK font or a user-provided font file so Chinese glyphs render.
    Optionally set cfg['plot']['font_path'] to a .ttf/.otf/.ttc file.
    """
    # 1) try common installed fonts
    preferred = ["Microsoft YaHei", "SimHei", "Noto Sans CJK SC", "Noto Sans CJK JP",
                 "Source Han Sans SC", "Arial Unicode MS"]
    available = {f.name: f.fname for f in fm.fontManager.ttflist}
    for name in preferred:
        if name in available:
            rcParams["font.sans-serif"] = [name] + rcParams.get("font.sans-serif", [])
            rcParams["axes.unicode_minus"] = False
            return name

    # 2) try user-provided font path from config
    try:
        fp = cfg.get("plot", {}).get("font_path") if cfg else None
    except Exception:
        fp = None
    if fp and os.path.exists(fp):
        fm.fontManager.addfont(fp)
        prop_name = fm.FontProperties(fname=fp).get_name()
        rcParams["font.sans-serif"] = [prop_name] + rcParams.get("font.sans-serif", [])
        rcParams["axes.unicode_minus"] = False
        return prop_name

    # 3) fall back (warnings may still appear)
    rcParams["axes.unicode_minus"] = False
    return None


# --- English gloss for Chinese tokens (extend via cfg['display']['cn2en_glossary']) ---
_DEFAULT_GLOSS = {
    "公交":"bus","公交车":"bus","北京公交":"Beijing bus","司机":"driver","驾驶":"driving",
    "安全":"safety","行为":"behavior","规范":"standard","推出":"rollout","操作":"operation",
    "系统":"system","集团":"group","地铁":"subway","线路":"line","站点":"station",
    "调整":"adjustment","乘客":"passenger","上车":"boarding","应用":"app","APP":"app",
    "调度":"dispatch","事故":"accident","堵":"congestion","拥堵":"congestion"
}
def _gloss_words(words: List[str], cfg: Dict, keep_n: int = 12) -> List[str]:
    user_map = cfg.get("display", {}).get("cn2en_glossary", {})
    mp = dict(_DEFAULT_GLOSS); mp.update(user_map)
    out, seen = [], set()
    for w in words:
        if w in mp:
            val = mp[w]
        elif all(ord(c) < 128 for c in w):  # already ascii (e.g., "APP")
            val = w.lower()
        else:
            continue  # drop unknown Chinese token to keep it English-only
        if val not in seen:
            seen.add(val); out.append(val)
        if len(out) >= keep_n:
            break
    return out


# ---------- helpers ----------
def _tokenize(text: str, min_len: int) -> List[str]:
    if not isinstance(text, str):
        return []
    text = re.sub(r"https?://\S+|@[A-Za-z0-9_\-]+|#\S+", " ", text)
    toks = [w.strip() for w in jieba.lcut(text) if w and len(w.strip()) >= min_len]
    return toks

def _soft_memberships_for_rows(texts: List[str], vocab: List[str], U: np.ndarray, min_len: int) -> np.ndarray:
    """
    Soft topic memberships per text using topic-word matrix U (KxV) with rows that sum to 1.
    Returns array (N_texts x K).
    """
    v2i = {w: j for j, w in enumerate(vocab)}
    K, V = U.shape
    eps = 1e-12
    logU = np.log(U + eps)  # K x V

    N = len(texts)
    Theta = np.zeros((N, K), dtype=np.float32)
    for i, txt in enumerate(texts):
        toks = _tokenize(txt, min_len)
        idxs = [v2i[t] for t in toks if t in v2i]
        if not idxs:
            Theta[i, :] = 1.0 / K
            continue
        ll = logU[:, idxs].sum(axis=1)        # K
        m = float(ll.max())
        ex = np.exp(ll - m)
        Theta[i, :] = (ex / (ex.sum() + eps)).astype(np.float32)
    return Theta

def _ensure_dirs(*paths):
    for p in paths:
        os.makedirs(p, exist_ok=True)


# ---------- core ----------
def run_case_study(cfg: Dict, logger,
                   topic_id: Optional[int] = None,
                   center_date: Optional[str] = None,
                   days: int = 7) -> Dict:
    """
    Create a 3-panel timeline (A, log(1+E), S) for a chosen topic around a center date (±days).
    Also exports representative posts for that topic/time and writes a summary JSON.
    """
    paths = cfg["paths"]
    art_dir = os.path.join(paths["outputs_dir"], "artifacts")
    fig_dir = os.path.join(paths["outputs_dir"], "figures")
    rep_dir = os.path.join(paths["outputs_dir"], "reports")
    _ensure_dirs(fig_dir, rep_dir)

    # ----- Load artifacts -----
    A  = np.load(os.path.join(art_dir, "A_TxK.npy"))   # (T,K)
    E  = np.load(os.path.join(art_dir, "E_TxK.npy"))   # (T,K)
    S  = np.load(os.path.join(art_dir, "S_TxK.npy"))   # (T,K)
    U  = np.load(os.path.join(art_dir, "U_KxV.npy"))   # (K,V)
    vocab = json.load(open(os.path.join(art_dir, "vocab.json"), "r", encoding="utf-8"))
    time_index = pd.read_csv(os.path.join(art_dir, "time_index.csv"))["time_bin"].astype("datetime64[ns]")
    T, K = A.shape

    # ----- Select (topic, center time): 4 explicit cases -----
    topic_given  = topic_id is not None
    center_given = center_date is not None

    if not topic_given and not center_given:
        # global maximum of S over (t,k)
        t_idx, k_idx = np.unravel_index(np.argmax(S), S.shape)
        topic_id = int(k_idx)
        center_ts = pd.Timestamp(time_index.iloc[t_idx])

    elif topic_given and not center_given:
        # keep requested topic; pick its best center day (argmax over t)
        topic_id = int(topic_id)
        topic_id = max(0, min(topic_id, K - 1))
        t_idx = int(np.argmax(S[:, topic_id]))
        center_ts = pd.Timestamp(time_index.iloc[t_idx])

    elif not topic_given and center_given:
        # snap the given center day to nearest bin; pick best topic at that day
        tmp_center = pd.Timestamp(center_date)
        t_idx = int(np.argmin(np.abs(time_index - tmp_center)))
        center_ts = pd.Timestamp(time_index.iloc[t_idx])
        topic_id = int(np.argmax(S[t_idx, :]))

    else:
        # both provided: keep topic; snap center to nearest bin
        topic_id = int(topic_id)
        topic_id = max(0, min(topic_id, K - 1))
        tmp_center = pd.Timestamp(center_date)
        t_idx = int(np.argmin(np.abs(time_index - tmp_center)))
        center_ts = pd.Timestamp(time_index.iloc[t_idx])

    # ----- Build time slice -----
    start_ts = center_ts - pd.Timedelta(days=days)
    end_ts   = center_ts + pd.Timedelta(days=days)
    mask = (time_index >= start_ts) & (time_index <= end_ts)
    t_slice = np.where(mask.values)[0] if mask.any() else np.arange(len(time_index))

    t_ticks = time_index.iloc[t_slice]
    A_k = A[t_slice, topic_id]
    E_k = E[t_slice, topic_id]
    S_k = S[t_slice, topic_id]

    # ----- Top words (English, comma-separated) -----
    top_words_idx = np.argsort(-U[topic_id])[:12]
    cn_top = [vocab[j] for j in top_words_idx]
    top_words = _gloss_words(cn_top, cfg, keep_n=12)  # requires _DEFAULT_GLOSS / _gloss_words in this file

    # ----- X-axis as day offsets relative to the center (center = 0) -----
    x = (t_ticks - center_ts).dt.days.astype(int)

    # ----- Fonts for CJK (safe if absent) -----
    _set_cjk_font(cfg)

    # ----- Figure -----
    fig, axes = plt.subplots(3, 1, figsize=(12, 7), sharex=True)
    axes[0].plot(x, A_k, linewidth=1.8)
    E_k_plot = np.log1p(E_k.astype(np.float64))  # log(1+E) scale for readability
    axes[1].plot(x, E_k_plot, linewidth=1.8)
    axes[2].plot(x, S_k, linewidth=1.8)

    for ax, label in zip(axes, ["Attention A(t,k)", "Escalation log(1+E(t,k))", "Severity S(t,k)"]):
        ax.set_ylabel(label); ax.grid(True, alpha=0.25)
        ax.axvline(0, linestyle="--", linewidth=1.2)  # center day

    axes[2].set_xlabel("Day offset (center = 0)")
    title = f"Case Study — Topic {topic_id} | Center: Day 0 | Top words: {', '.join(top_words)}"
    fig.suptitle(title)
    fig.tight_layout(rect=[0, 0.03, 1, 0.95])

    fig_name = f"case_study_k{topic_id}_center_{center_ts.date()}.png"
    fig_path = os.path.join(fig_dir, fig_name)
    fig.savefig(fig_path, dpi=200)
    plt.close(fig)

    # ----- Representative posts at the center window -----
    proc = os.path.join(paths["processed_dir"], "weibo_all.csv")
    df = pd.read_csv(proc, parse_dates=["timestamp"])
    df["post_id"] = df["seq_id"] if "seq_id" in df.columns else (np.arange(len(df)) + 1)

    infl_path = os.path.join(art_dir, "influence.parquet")
    if not os.path.exists(infl_path):
        infl_path = os.path.join(paths["outputs_dir"], "artifacts", "influence.parquet")
    infl = pd.read_parquet(infl_path)[["post_id", "time_bin", "w_base"]]
    df = pd.merge(df, infl, on="post_id", how="left")
    df["time_bin"] = pd.to_datetime(df["time_bin"], errors="coerce")
    win = cfg["time"]["window"]
    need = df["time_bin"].isna()
    if need.any():
        df.loc[need, "time_bin"] = df.loc[need, "timestamp"].dt.to_period(win).dt.to_timestamp()

    df_center = df[df["time_bin"] == center_ts].copy()
    if not df_center.empty:
        min_len = int(cfg["features"].get("min_token_len", 2))
        Theta_rows = _soft_memberships_for_rows(df_center["text"].tolist(), vocab, U, min_len)  # N x K
        theta_k = Theta_rows[:, topic_id]
        weight = df_center["w_base"].fillna(0.0).to_numpy(dtype=float)
        df_center["topic_score"] = weight * theta_k

        keep_cols = ["time_bin","city","screen_name","user_id","followers","likes",
                     "comments_count","text","topic_score"]
        keep_cols = [c for c in keep_cols if c in df_center.columns]
        top_posts = df_center[keep_cols].sort_values("topic_score", ascending=False).head(10)
        posts_path = os.path.join(rep_dir, f"case_study_posts_k{topic_id}_t{center_ts.date()}.csv")
        top_posts.to_csv(posts_path, index=False, encoding="utf-8-sig")
    else:
        posts_path = None

    # ----- Summary JSON (also used by batch to lock centers) -----
    summary = {
        "topic": topic_id,
        "center_date": str(center_ts.date()),
        "window_days": days,
        "figure": os.path.basename(fig_path),
        "top_words": top_words,
        "posts_csv": os.path.basename(posts_path) if posts_path else None,
    }
    with open(os.path.join(rep_dir, f"case_study_k{topic_id}_summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    logger.info(f"Case study saved → {fig_path} (posts: {posts_path})")
    # for programmatic chaining (case_batch uses 'center')
    return {"figure": fig_path, "posts": posts_path, "topic": topic_id, "center": str(center_ts)}
