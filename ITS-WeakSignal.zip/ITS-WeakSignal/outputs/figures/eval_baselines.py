from __future__ import annotations
import os
from typing import Dict, List, Optional
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from outputs.reports.evaluate_baselines import evaluate_baselines

_METHOD_ORDER = ["S", "volume_z", "soft_volume", "soft_volume_weighted", "inv_mean_sent"]
_METHOD_LABELS = {
    "S": "Severity S",
    "volume_z": "Volume (z)",
    "soft_volume": "Soft volume",
    "soft_volume_weighted": "Soft vol. (influence-wt)",
    "inv_mean_sent": "1 − mean sentiment",
}

def _ensure_dir(p: str):
    os.makedirs(p, exist_ok=True)

def _se_from_std(std: float, n: int) -> float:
    if std is None or n is None or n <= 1:
        return 0.0
    return float(std) / np.sqrt(float(n))

def run_eval_baselines_figure(
    cfg: Dict,
    logger,
    topic_ids: Optional[List[int]] = None,
    days: int = 7,
    save_prefix: str = "eval_baselines",
    include_spearman: bool = False
) -> Dict:
    """
    Make a compact summary figure for baseline effectiveness:
      Panel 1: mean ROC–AUC ± SE bars (across topics)
      Panel 2: mean AP ± SE bars (across topics)
      Panel 3: lead-time boxplot (peak offset vs S; days)
      (Optional) Panel 4: Spearman(·, S) ± SE bars

    If needed, this function first runs outputs/reports/evaluate_baselines.py
    to create the summary/rows CSVs.
    """
    paths = cfg["paths"]
    rep_dir = os.path.join(paths["outputs_dir"], "reports", "baseline_eval")
    fig_dir = os.path.join(paths["outputs_dir"], "figures")
    _ensure_dir(rep_dir); _ensure_dir(fig_dir)

    rows_path = os.path.join(rep_dir, f"{save_prefix}_rows_long.csv")
    summ_path = os.path.join(rep_dir, f"{save_prefix}_summary.csv")

    # Ensure we have evaluation CSVs
    if not (os.path.exists(rows_path) and os.path.exists(summ_path)):
        logger.info("eval_baselines figure: rows/summary missing; running evaluator…")
        evaluate_baselines(cfg, logger, topic_ids=topic_ids, days=days, save_prefix=save_prefix)

    # Load data
    rows_df = pd.read_csv(rows_path)
    summ_df = pd.read_csv(summ_path)

    # Keep only known methods, in canonical order
    methods_present = [m for m in _METHOD_ORDER if m in set(rows_df["method"].unique())]

    # Prepare AUC/AP bars (mean ± SE)
    auc_vals, auc_err, ap_vals, ap_err, n_topics = [], [], [], [], []
    for m in methods_present:
        row = summ_df[summ_df["method"] == m]
        if row.empty:
            continue
        mean_auc = row["mean_auc"].values[0]
        std_auc  = row["std_auc"].values[0]
        mean_ap  = row["mean_ap"].values[0]
        std_ap   = row["std_ap"].values[0]
        n        = int(row["topics_evaluated"].values[0])

        auc_vals.append(float(mean_auc) if pd.notna(mean_auc) else np.nan)
        ap_vals.append(float(mean_ap) if pd.notna(mean_ap) else np.nan)
        auc_err.append(_se_from_std(float(std_auc) if pd.notna(std_auc) else 0.0, n))
        ap_err.append(_se_from_std(float(std_ap) if pd.notna(std_ap) else 0.0, n))
        n_topics.append(n)

    labels = [_METHOD_LABELS.get(m, m) for m in methods_present]
    x = np.arange(len(methods_present))

    # Lead-time arrays per method
    lead_data = [rows_df.loc[rows_df["method"] == m, "lead_offset_days_vs_S"].dropna().astype(float).values
                 for m in methods_present]

    # Figure layout
    n_panels = 3 + (1 if include_spearman else 0)
    fig, axes = plt.subplots(n_panels, 1, figsize=(10, 2.8 * n_panels), sharex=False)
    if n_panels == 1:
        axes = [axes]

    # Panel 1: ROC–AUC
    ax = axes[0]
    ax.bar(x, auc_vals, yerr=auc_err, capsize=4)
    ax.set_ylabel("ROC–AUC (mean ± SE)")
    ax.set_xticks(x); ax.set_xticklabels(labels, rotation=15, ha="right")
    ax.set_ylim(0.0, 1.05)
    ax.grid(True, axis="y", alpha=0.25)

    # Panel 2: AP
    ax = axes[1]
    ax.bar(x, ap_vals, yerr=ap_err, capsize=4)
    ax.set_ylabel("Average Precision (mean ± SE)")
    ax.set_xticks(x); ax.set_xticklabels(labels, rotation=15, ha="right")
    ax.set_ylim(0.0, 1.05)
    ax.grid(True, axis="y", alpha=0.25)

    # Panel 3: Lead-time boxplot
    ax = axes[2]
    # horizontal line at 0 (S-peak alignment)
    ax.axhline(0.0, linestyle="--", linewidth=1.2, color="gray")
    bp = ax.boxplot(
        lead_data,
        positions=x + 1,  # 1-based positions look nicer
        showfliers=False,
        whis=[25, 75],   # IQR whiskers
        widths=0.6
    )
    ax.set_xticks(x + 1); ax.set_xticklabels(labels, rotation=15, ha="right")
    ax.set_ylabel("Lead offset vs S (days)")
    ax.grid(True, axis="y", alpha=0.25)

    # Optional Panel 4: Spearman(·, S)
    if include_spearman:
        rho_vals, rho_err = [], []
        for m in methods_present:
            sub = rows_df[rows_df["method"] == m]["spearman_vs_S"].dropna().astype(float)
            if len(sub):
                rho_vals.append(float(sub.mean()))
                rho_err.append(float(sub.std(ddof=0)) / np.sqrt(len(sub)))
            else:
                rho_vals.append(np.nan); rho_err.append(0.0)
        ax = axes[3]
        ax.bar(x, rho_vals, yerr=rho_err, capsize=4)
        ax.set_ylabel("Spearman(·, S) (mean ± SE)")
        ax.set_xticks(x); ax.set_xticklabels(labels, rotation=15, ha="right")
        ax.set_ylim(-1.0, 1.0)
        ax.grid(True, axis="y", alpha=0.25)

    # Title + footnote
    eval_cfg = cfg.get("evaluation", {})
    label_mode = str(eval_cfg.get("label_mode", "peak_pm1"))
    pos_half_width = int(eval_cfg.get("pos_half_width", 1))
    topk = int(eval_cfg.get("topk", 5))
    title = f"Baseline effectiveness (Top-{topk} topics; window ±{days} d; labels: {label_mode}, H={pos_half_width})"
    fig.suptitle(title)
    fig.tight_layout(rect=[0, 0.03, 1, 0.95])

    # Save
    fname = f"{save_prefix}_summary_fig_days{days}.png"
    out_path = os.path.join(fig_dir, fname)
    fig.savefig(out_path, dpi=200)
    plt.close(fig)

    logger.info(f"Baseline summary figure saved → {out_path}")
    return {"figure": out_path, "rows_csv": rows_path, "summary_csv": summ_path}
