from __future__ import annotations
import os
from typing import Dict, Optional
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from outputs.reports.baseline_utils import (
    load_artifacts, choose_center, make_window, _ensure_dir
)
from outputs.reports.baseline_soft_volume_weighted import run_baseline_soft_volume_weighted


def run_baseline_soft_volume_weighted_figure(
    cfg: Dict, logger, topic_id: Optional[int], center_date: Optional[str], days: int = 7
):
    """
    Render a 4-panel baseline figure (A, log(1+E), S, Weighted Soft Volume) for topic k,
    centered on that topic's S-peak (or a provided center date).
    Auto-generates the daily CSV via `run_baseline_soft_volume_weighted` and then plots it.
    """
    # Determine topic and center
    A, E, S, U, vocab, time_index = load_artifacts(cfg)
    k, center_ts = choose_center(topic_id, center_date, S, time_index)
    _, _, _ = make_window(time_index, center_ts, days)  # ensures consistent windowing

    # Ensure the per-day series exists (and get its path)
    rep = run_baseline_soft_volume_weighted(cfg, logger, k, str(center_ts.date()), days)
    df = pd.read_csv(rep["daily"], parse_dates=["time_bin"])

    # Figure: 3 core panels + baseline panel
    fig_dir = os.path.join(cfg["paths"]["outputs_dir"], "figures")
    _ensure_dir(fig_dir)

    fig, axes = plt.subplots(4, 1, figsize=(12, 9), sharex=True)

    axes[0].plot(df["day_offset"], df["A"], linewidth=1.8)
    axes[0].set_ylabel("Attention A(t,k)")
    axes[0].grid(True, alpha=0.25)

    axes[1].plot(df["day_offset"], df["log1pE"], linewidth=1.8)
    axes[1].set_ylabel("Escalation log(1+E)")
    axes[1].grid(True, alpha=0.25)

    axes[2].plot(df["day_offset"], df["S"], linewidth=1.8)
    axes[2].set_ylabel("Severity S")
    axes[2].grid(True, alpha=0.25)

    axes[3].plot(df["day_offset"], df["soft_volume_weighted"], linewidth=1.8)
    axes[3].set_ylabel("Weighted soft volume (Σ w·θ_k)")
    axes[3].set_xlabel("Day offset (center = 0)")
    axes[3].grid(True, alpha=0.25)

    for ax in axes:
        ax.axvline(0, linestyle="--", linewidth=1.2)

    title = f"Baseline — Weighted Soft Volume | Topic {k} | Center: Day 0"
    fig.suptitle(title)
    fig.tight_layout(rect=[0, 0.03, 1, 0.95])

    out_name = f"baseline_soft_volume_weighted_overview_k{k}_center_{center_ts.date()}.png"
    out_path = os.path.join(fig_dir, out_name)
    fig.savefig(out_path, dpi=200)
    plt.close(fig)

    logger.info(f"Baseline figure (soft_volume_weighted) → {out_path}")
    return {"figure": out_path, "topic": k, "center": str(center_ts)}
