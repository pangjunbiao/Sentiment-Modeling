# src/figures/case_study_multi.py
from __future__ import annotations
import os, json
from typing import Dict, Optional, List, Tuple
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# reuse the CJK font helper from the single-case module
from outputs.figures.case_study import _set_cjk_font

def _top_words_for_topic(U_row: np.ndarray, vocab: List[str], n: int = 10) -> List[str]:
    idx = np.argsort(-U_row)[:n]
    return [vocab[j] for j in idx]

def run_case_study_multi(cfg: Dict, logger,
                         center_date: Optional[str] = None,
                         days: int = 7,
                         topn: int = 5,
                         make_overlay_S: bool = True) -> Dict:
    """
    Companion figure: Top-N topics around a center date (±days).
    Produces:
      - Heatmap of S(t,k) for top-N topics (rows=topics, cols=days in window)
      - Optional one-panel overlay of S(t,k) curves for the same topics
      - CSV table listing topic id, peak S, and top words
    """
    paths = cfg["paths"]
    art_dir = os.path.join(paths["outputs_dir"], "artifacts")
    fig_dir = os.path.join(paths["outputs_dir"], "figures")
    rep_dir = os.path.join(paths["outputs_dir"], "reports")
    os.makedirs(fig_dir, exist_ok=True); os.makedirs(rep_dir, exist_ok=True)

    # Load core artifacts
    S = np.load(os.path.join(art_dir, "S_TxK.npy"))          # T x K
    A = np.load(os.path.join(art_dir, "A_TxK.npy"))          # T x K (for completeness if needed)
    U = np.load(os.path.join(art_dir, "U_KxV.npy"))          # K x V
    vocab = json.load(open(os.path.join(art_dir, "vocab.json"), "r", encoding="utf-8"))
    time_index = pd.read_csv(os.path.join(art_dir, "time_index.csv"))["time_bin"].astype("datetime64[ns]")
    T, K = S.shape

    # Choose center day: default = argmax over S (global)
    if center_date is None:
        ti, ki = np.unravel_index(np.argmax(S), S.shape)
        center_ts = pd.Timestamp(time_index.iloc[ti])
    else:
        center_ts = pd.Timestamp(center_date)
        diffs = np.abs(time_index - center_ts)
        ti = int(np.argmin(diffs))
        center_ts = pd.Timestamp(time_index.iloc[ti])

    # Window slice
    start_ts = center_ts - pd.Timedelta(days=days)
    end_ts   = center_ts + pd.Timedelta(days=days)
    mask = (time_index >= start_ts) & (time_index <= end_ts)
    if mask.any():
        t_slice = np.where(mask.values)[0]
    else:
        t_slice = np.arange(len(time_index))
    t_ticks = time_index.iloc[t_slice]
    S_win = S[t_slice, :]  # (#t, K)

    # Select top-N topics by **peak S within this window**
    peak_per_k = S_win.max(axis=0)                 # K
    order = np.argsort(-peak_per_k)[:max(1, topn)]
    top_idx = order.tolist()
    top_labels = [f"k={k}" for k in top_idx]

    # Prepare heatmap matrix: rows=topics, cols=time
    H = S_win[:, top_idx].T  # (topn x #t)

    # Table of topic words + peak S
    rows = []
    for k in top_idx:
        words = _top_words_for_topic(U[k], vocab, n=10)
        rows.append({"topic_id": int(k),
                     "peak_S_in_window": float(peak_per_k[k]),
                     "top_words": " ".join(words)})
    table_df = pd.DataFrame(rows)
    table_path = os.path.join(rep_dir, f"case_study_top{len(top_idx)}_table.csv")
    table_df.to_csv(table_path, index=False, encoding="utf-8-sig")

    # Set CJK-capable font
    _set_cjk_font(cfg)

    # ---- Figure A: Heatmap of S ----
    fig_h, ax_h = plt.subplots(1, 1, figsize=(12, 4 + 0.2*len(top_idx)))
    im = ax_h.imshow(H, aspect="auto", interpolation="nearest")
    # x ticks as dates (sparse)
    xticks = np.linspace(0, H.shape[1]-1, min(8, H.shape[1]), dtype=int)
    ax_h.set_xticks(xticks)
    ax_h.set_xticklabels([str(pd.Timestamp(t_ticks.iloc[i]).date()) for i in xticks], rotation=30, ha="right")
    ax_h.set_yticks(np.arange(len(top_idx)))
    # ytick labels = topic id + top-words first 6 tokens for readability
    ylabels = []
    for k in top_idx:
        words = _top_words_for_topic(U[k], vocab, n=6)
        ylabels.append(f"k={k}: {' '.join(words)}")
    ax_h.set_yticklabels(ylabels)
    ax_h.set_xlabel("Time")
    ax_h.set_ylabel("Topics (top words)")
    title = f"Top-{len(top_idx)} topics by severity around {center_ts.date()} (S(t,k))"
    fig_h.suptitle(title)
    cbar = fig_h.colorbar(im, ax=ax_h)
    cbar.set_label("Severity S(t,k)")
    fig_h.tight_layout(rect=[0, 0.03, 1, 0.95])

    heatmap_path = os.path.join(fig_dir, f"case_study_top{len(top_idx)}_heatmap.png")
    fig_h.savefig(heatmap_path, dpi=200)
    plt.close(fig_h)

    # ---- Figure B (optional): overlay of S curves ----
    overlay_path = None
    if make_overlay_S:
        fig_o, ax_o = plt.subplots(1, 1, figsize=(12, 3.5))
        for k in top_idx:
            ax_o.plot(t_ticks, S_win[:, k], linewidth=1.6, label=f"k={k}")
        ax_o.axvline(center_ts, linestyle="--", linewidth=1.2)
        ax_o.set_xlabel("Time")
        ax_o.set_ylabel("Severity S(t,k)")
        ax_o.grid(True, alpha=0.25)
        ax_o.legend(ncol=min(len(top_idx), 5), fontsize=9)
        fig_o.suptitle(f"S(t,k) overlay for top-{len(top_idx)} topics around {center_ts.date()}")
        fig_o.tight_layout(rect=[0, 0.03, 1, 0.95])
        overlay_path = os.path.join(fig_dir, f"case_study_top{len(top_idx)}_overlay_S.png")
        fig_o.savefig(overlay_path, dpi=200)
        plt.close(fig_o)

    logger.info(f"Saved top-{len(top_idx)} heatmap → {heatmap_path}")
    if overlay_path:
        logger.info(f"Saved overlay S figure → {overlay_path}")
    logger.info(f"Saved topic table → {table_path}")

    return {"heatmap": heatmap_path, "overlay_S": overlay_path, "table": table_path,
            "center": str(center_ts.date()), "topics": top_idx}
