# outputs/figures/beta_ablation_fig.py
from __future__ import annotations
import os
from typing import Dict, Optional, Sequence
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from src.ranking.ablation import run_beta_ablation  # auto-generate CSV if missing


def _ensure_dir(p: str):
    os.makedirs(p, exist_ok=True)


def run_beta_ablation_figure(
    cfg: Dict,
    logger,
    save_prefix: str = "beta_ablation",
    # bars use SD by default (paper-friendly). Set True to show SE instead.
    use_se: bool = False,
    # which “only_*” examples (optional) to add to the compact panel
    only_examples: Optional[Sequence[str]] = ("only_attention", "only_influence"),
) -> Dict:
    """
    Make a compact 2-panel figure for β-ablation:
      Panel A: Kendall τ (Top-K) for each setting (bar chart).
      Panel B: Mean lead offset (days) ± SD (or ± SE if use_se=True).

    Reads:  outputs/reports/{save_prefix}_summary.csv
    Writes: outputs/figures/{save_prefix}_fig.png
    """
    rep_dir = os.path.join(cfg["paths"]["outputs_dir"], "reports")
    fig_dir = os.path.join(cfg["paths"]["outputs_dir"], "figures")
    _ensure_dir(fig_dir)

    summ_path = os.path.join(rep_dir, f"{save_prefix}_summary.csv")
    if not os.path.exists(summ_path):
        logger.info(f"{summ_path} not found; running run_beta_ablation(...) to create it.")
        run_beta_ablation(cfg, logger, topk=None, save_prefix=save_prefix)

    if not os.path.exists(summ_path):
        raise FileNotFoundError(f"β-ablation summary CSV still not found: {summ_path}")

    df = pd.read_csv(summ_path)

    # Desired order for compact panel
    want = ["default", "equal", "drop_freq", "drop_attention", "drop_influence", "drop_escalation"]
    if only_examples:
        for s in only_examples:
            if s not in want:
                want.append(s)

    # Keep only rows that exist
    present = set(df["setting"].astype(str))
    order = [s for s in want if s in present]
    if not order:
        raise RuntimeError("No recognized β-ablation settings found in summary CSV.")

    sub = df[df["setting"].isin(order)].copy()
    sub["__order"] = sub["setting"].apply(lambda s: order.index(s))
    sub = sub.sort_values("__order")

    # -------- Values (BACKWARD-COMPATIBLE for different column schemas) --------
    labels = sub["setting"].tolist()
    tau_topk = sub["kendall_tau_topk"].astype(float).to_numpy()

    def _has(col: str) -> bool:
        return col in sub.columns

    # Prefer *days* for plotting; convert from hours if needed
    # Supported schemas:
    #   old:    lead_mean, lead_std   (days)
    #   alt:    mean_lead, lead_std   (days)
    #   new:    mean_lead_d[, lead_std_d|lead_std_h]
    #   hours:  mean_lead_h[, lead_std_h]
    if _has("lead_mean") and _has("lead_std"):
        lead_mean_days = sub["lead_mean"].astype(float)
        lead_std_days = sub["lead_std"].astype(float).fillna(0.0)
    elif _has("mean_lead") and _has("lead_std"):
        lead_mean_days = sub["mean_lead"].astype(float)
        lead_std_days = sub["lead_std"].astype(float).fillna(0.0)
    elif _has("mean_lead_d"):
        lead_mean_days = sub["mean_lead_d"].astype(float)
        if _has("lead_std_d"):
            lead_std_days = sub["lead_std_d"].astype(float).fillna(0.0)
        elif _has("lead_std_h"):
            lead_std_days = (sub["lead_std_h"].astype(float) / 24.0).fillna(0.0)
        else:
            lead_std_days = pd.Series(0.0, index=sub.index)
    elif _has("mean_lead_h"):
        lead_mean_days = (sub["mean_lead_h"].astype(float) / 24.0)
        if _has("lead_std_h"):
            lead_std_days = (sub["lead_std_h"].astype(float) / 24.0).fillna(0.0)
        else:
            lead_std_days = pd.Series(0.0, index=sub.index)
    else:
        raise KeyError(
            "Could not find lead-time columns in the β-ablation summary. "
            f"Available columns: {list(sub.columns)}. "
            "Expected one of: ['lead_mean','lead_std'], "
            "['mean_lead','lead_std'], "
            "['mean_lead_d','lead_std_d'|'lead_std_h'], "
            "or ['mean_lead_h','lead_std_h']."
        )

    lead_mean = lead_mean_days.to_numpy()
    # If you ever store an 'n_topics' column per setting, you can switch to SE here:
    n_for_se = None
    lead_err = (lead_std_days.to_numpy() / np.sqrt(n_for_se)) if (use_se and n_for_se) else lead_std_days.to_numpy()

    # Pretty x-tick labels
    def pretty(s: str) -> str:
        if s.startswith("drop_"): return "drop " + s.split("_", 1)[1]
        if s.startswith("only_"): return "only " + s.split("_", 1)[1]
        return s

    xt = [pretty(s) for s in labels]
    x = np.arange(len(labels))

    # -------- Figure --------
    fig, axes = plt.subplots(1, 2, figsize=(12, 5), sharex=False)
    ax1, ax2 = axes

    # Panel A — rank stability (τ Top-K)
    bars1 = ax1.bar(x, tau_topk, width=0.6)
    ax1.axhline(0.0, linestyle="--", linewidth=1.0, color="k")
    ax1.set_xticks(x); ax1.set_xticklabels(xt, rotation=40, ha="right")
    ax1.set_ylabel("Kendall τ (Top-K)")
    ax1.set_title("Rank stability vs default")
    ax1.grid(True, axis="y", alpha=0.25)

    # Panel B — lead time (days)
    bars2 = ax2.bar(x, lead_mean, yerr=lead_err, capsize=3, width=0.6)
    ax2.axhline(0.0, linestyle="--", linewidth=1.0, color="k")
    ax2.set_xticks(x); ax2.set_xticklabels(xt, rotation=40, ha="right")
    ax2.set_ylabel("Lead offset vs E (days)")
    ax2.set_title(f"Timeliness (mean ± {'SE' if (use_se and n_for_se) else 'SD'})")
    ax2.grid(True, axis="y", alpha=0.25)

    # Subtle highlight for default & equal
    for bars in (bars1, bars2):
        for i, b in enumerate(bars):
            if labels[i] in {"default", "equal"}:
                b.set_edgecolor("black")
                b.set_linewidth(1.4)

    # Suptitle with meta info (if present)
    def _get(col, default=""):
        return str(sub[col].iloc[0]) if col in sub.columns and len(sub[col]) else default

    nm = _get("norm_mode", "minmax")
    incE = _get("include_E", "TRUE")
    daysw = _get("days_window", "7")

    fig.suptitle(f"β-ablation robustness (norm={nm}; include_E={incE}; ±{daysw}d)", y=0.98)
    fig.tight_layout(rect=[0, 0, 1, 0.94])

    out = os.path.join(fig_dir, f"{save_prefix}_fig.png")
    plt.savefig(out, dpi=200)
    plt.close(fig)

    # Hard check (helps when running from IDEs)
    if not os.path.exists(out):
        raise RuntimeError(f"Figure was not written: {os.path.abspath(out)}")

    logger.info(f"β-ablation figure saved → {os.path.abspath(out)}")
    return {"figure": out, "csv": summ_path}
