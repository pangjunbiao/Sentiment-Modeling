from __future__ import annotations
import os
from typing import Dict, Optional
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from outputs.reports.baseline_utils import (
    load_artifacts, choose_center, make_window, _ensure_dir
)
from outputs.reports.baseline_volume import run_baseline_volume

def run_baseline_volume_figure(cfg: Dict, logger, topic_id: Optional[int], center_date: Optional[str], days: int = 7):
    A, E, S, U, vocab, time_index = load_artifacts(cfg)
    k, center_ts = choose_center(topic_id, center_date, S, time_index)
    t_slice, t_ticks, x = make_window(time_index, center_ts, days)

    # ensure daily exists (and get path)
    rep = run_baseline_volume(cfg, logger, k, str(center_ts.date()), days)
    df = pd.read_csv(rep["daily"], parse_dates=["time_bin"])

    fig_dir = os.path.join(cfg["paths"]["outputs_dir"], "figures"); _ensure_dir(fig_dir)
    fig, axes = plt.subplots(4, 1, figsize=(12, 9), sharex=True)
    axes[0].plot(df["day_offset"], df["A"], linewidth=1.8); axes[0].set_ylabel("Attention A(t,k)"); axes[0].grid(True, alpha=0.25)
    axes[1].plot(df["day_offset"], df["log1pE"], linewidth=1.8); axes[1].set_ylabel("Escalation log(1+E)"); axes[1].grid(True, alpha=0.25)
    axes[2].plot(df["day_offset"], df["S"], linewidth=1.8); axes[2].set_ylabel("Severity S"); axes[2].grid(True, alpha=0.25)

    axes[3].plot(df["day_offset"], df["volume_z"], linewidth=1.8)
    axes[3].set_ylabel("Volume z-score")
    axes[3].set_xlabel("Day offset (center = 0)")
    for ax in axes: ax.axvline(0, linestyle="--", linewidth=1.2); ax.grid(True, alpha=0.25)

    title = f"Baseline — Volume (z) | Topic {k} | Center: Day 0"
    fig.suptitle(title); fig.tight_layout(rect=[0, 0.03, 1, 0.95])

    name = f"baseline_volume_overview_k{k}_center_{center_ts.date()}.png"
    out = os.path.join(fig_dir, name); fig.savefig(out, dpi=200); plt.close(fig)
    logger.info(f"Baseline figure (volume_z) → {out}")
    return {"figure": out, "topic": k, "center": str(center_ts)}
