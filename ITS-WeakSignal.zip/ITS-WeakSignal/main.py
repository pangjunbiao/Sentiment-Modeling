# main.py
from __future__ import annotations
import os, sys, argparse, logging, datetime, pathlib, yaml

from outputs.figures.beta_ablation_fig import run_beta_ablation_figure
from outputs.figures.eval_baselines import run_eval_baselines_figure
from outputs.reports.case_table import run_case_table
from outputs.reports.early_warning import generate_early_warning_alarms
from outputs.reports.eval_model import evaluate_model
from outputs.reports.evaluate_baselines import evaluate_baselines
from outputs.sensitivity_analysis.K_sensitivity.run_k_sensitivity import run_k_sensitivity
from outputs.sensitivity_analysis.M_sensitivity.run_m_sensitivity import run_m_sensitivity
from outputs.sensitivity_analysis.h_sensitivity.run_h_sensitivity import run_h_sensitivity
from src.data.process import run_processing
from src.influence.weights import run_influence
from src.graph.cooc import run_cooc
from src.features.tokenize import build_time_keyword_matrix
from src.models.pdf_init import run_pdf_init
from src.ranking.ablation import run_beta_ablation
from src.sentiment.sentiment import run_sentiment
from src.ranking.severity import run_ranking
from outputs.figures.case_study import run_case_study
from outputs.figures.case_study_multi import run_case_study_multi
from outputs.reports.baseline_volume import run_baseline_volume
from outputs.reports.baseline_soft_volume import run_baseline_soft_volume
from outputs.reports.baseline_soft_volume_weighted import run_baseline_soft_volume_weighted
from outputs.reports.baseline_sentiment_mean import run_baseline_sentiment_mean

from outputs.figures.baseline_volume import run_baseline_volume_figure
from outputs.figures.baseline_soft_volume import run_baseline_soft_volume_figure
from outputs.figures.baseline_soft_volume_weighted import run_baseline_soft_volume_weighted_figure
from outputs.figures.baseline_sentiment_mean import run_baseline_sentiment_mean_figure
from src.ranking.derive_factors import run_derive_factors
from src.sentiment.sentiment_visualization import plot_sentiment_trends, plot_sentiment_escalation, plot_topic_evolution
from src.utils.data_loader_sentiment import load_sentiment_data, load_vocab
from src.models.pdf_admm import run_pdf_fit  # wrapper that calls fit_pdf_window per window
import os
import copy
import shutil




def load_config(path: str) -> dict:
    if not os.path.exists(path):
        raise FileNotFoundError(f"Config file not found: {path}")
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def setup_logger(log_dir: str, name: str = "its_pipeline") -> logging.Logger:
    pathlib.Path(log_dir).mkdir(parents=True, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = os.path.join(log_dir, f"{name}_{ts}.log")
    logger = logging.getLogger(name); logger.setLevel(logging.INFO)
    if logger.hasHandlers(): logger.handlers.clear()
    fh = logging.FileHandler(log_path, encoding="utf-8"); fh.setLevel(logging.INFO)
    ch = logging.StreamHandler(sys.stdout);            ch.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    fh.setFormatter(fmt); ch.setFormatter(fmt)
    logger.addHandler(fh); logger.addHandler(ch)
    logger.info(f"Logging to {log_path}")
    return logger

def _normalize_paths(cfg: dict) -> dict:
    for k in ["raw_dir", "processed_dir", "outputs_dir"]:
        p = cfg["paths"].get(k)
        if p:
            cfg["paths"][k] = os.path.abspath(p)
    return cfg

def _parse_topics(s: str):
    if not s: return []
    return [int(x.strip()) for x in s.split(",") if x.strip().isdigit()]

def _auto_topk_by_S(cfg, topk: int = 5):
    import numpy as np, os
    art_dir = os.path.join(cfg["paths"]["outputs_dir"], "artifacts")
    S = np.load(os.path.join(art_dir, "S_TxK.npy"))  # T x K
    ks = np.argsort(-S.max(axis=0))[:topk]
    return [int(k) for k in ks]

def _ensure_beta_factors(cfg, logger):
    art = os.path.join(cfg["paths"]["outputs_dir"], "artifacts")
    need = [nm for nm in ("frequency_TxK.npy","user_influence_TxK.npy")
            if not os.path.exists(os.path.join(art, nm))]
    if need:
        logger.info(f"β-prep: missing {need}; deriving now …")
        run_derive_factors(cfg, logger, save_prefix="derived")

def run_case_batch(cfg, logger, topic_ids=None, days=7, redact_dates=True):
    from outputs.figures.case_study import run_case_study
    from outputs.reports.case_table import run_case_table
    import numpy as np, os, pandas as pd, json

    art_dir = os.path.join(cfg["paths"]["outputs_dir"], "artifacts")
    rep_dir = os.path.join(cfg["paths"]["outputs_dir"], "reports")
    fig_dir = os.path.join(cfg["paths"]["outputs_dir"], "figures")
    os.makedirs(rep_dir, exist_ok=True); os.makedirs(fig_dir, exist_ok=True)

    # If no explicit list, choose Top-5 by max S(t,k)
    S = np.load(os.path.join(art_dir, "S_TxK.npy"))  # T x K
    if not topic_ids:
        topk = int(cfg.get("display", {}).get("case_batch_topk", 5))
        ks = np.argsort(-S.max(axis=0))[:topk]
        topic_ids = [int(k) for k in ks]

    logger.info(f"Case batch topics: {topic_ids}")
    if not topic_ids:
        logger.warning("No topics provided or discovered; nothing to do.")
        return []

    rows = []
    for k in topic_ids:
        logger.info(f"Case batch: topic {k}")
        # 1) figure (auto-picks center if not provided)
        rfig = run_case_study(cfg, logger, topic_id=k, center_date=None, days=days)
        center = str(pd.to_datetime(rfig["center"]).date())
        # 2) tables (use the SAME center as the figure)
        rtbl = run_case_table(cfg, logger, topic_id=k, center_date=center,
                              days=days, redact_dates=redact_dates, top_posts=5)
        # collect a summary row
        rows.append({
            "topic": k,
            "center_date": center,
            "figure": os.path.basename(rfig.get("figure","")),
            "metrics_csv": f"case_study_metrics_k{k}_redacted.csv",
            "daily_csv":   f"case_study_daily_k{k}_redacted.csv",
            "posts_csv":   f"case_study_posts_k{k}_sanitized.csv"
        })
        logger.info(f"Saved k={k} → {rows[-1]['figure']} and CSVs")

    # Write an index to verify batch outputs
    idx_path = os.path.join(rep_dir, "case_batch_index.csv")
    pd.DataFrame(rows).to_csv(idx_path, index=False, encoding="utf-8-sig")
    logger.info(f"Batch index written → {idx_path}")
    return rows


def main():
    parser = argparse.ArgumentParser(description="ITS Weak-Signal Pipeline")
    parser.add_argument("--config", default="config/config.yaml", help="Path to YAML config")
    parser.add_argument(
        "--run", default="all",
        choices=["process", "influence", "cooc", "features", "pdf_init", "sentiment", "pdf_fit", "rank",
                 "casestudy", "casestudy_multi", "case_table", "case_batch", "eval_model",
                 # baselines (reports)
                 "baseline_volume_report", "baseline_soft_volume_report",
                 "baseline_soft_volume_weighted_report", "baseline_sentiment_mean_report",
                 # baselines (figures)
                 "baseline_volume_fig", "baseline_soft_volume_fig",
                 "baseline_soft_volume_weighted_fig", "baseline_sentiment_mean_fig",
                 # optional convenience
                 "baseline_all_reports", "baseline_all_figs", "eval_baselines_report", "eval_baselines_fig",
                 "eval_baselines_all",
                 "beta_prep", "beta_ablation", "beta_ablation_fig",
                 # Sensitivity analysis options
                 "K_sensitivity", "M_sensitivity", "h_sensitivity", "early_warning", "visualizations",
                 "all"],

        help="Stage to run"
    )
    parser.add_argument("--topic", type=int, default=None, help="Topic id for case study (default: auto)")
    parser.add_argument("--center", type=str, default=None, help="Center date YYYY-MM-DD for case study (default: auto)")
    parser.add_argument("--days", type=int, default=7, help="±days around center to plot")
    parser.add_argument("--topics", type=str, default="", metavar="TOPICS",
                        help="Comma-separated topic IDs for batch case studies (e.g., 1,3,5,7,10)")

    args = parser.parse_args()

    cfg = load_config(args.config)
    cfg = _normalize_paths(cfg)
    logs_dir = os.path.join(cfg["paths"]["outputs_dir"], "logs")
    logger = setup_logger(logs_dir)
    logger.info(f"cwd={os.getcwd()}  outputs_dir={cfg['paths']['outputs_dir']}")

    # PROCESS
    if args.run in {"all","process"}:
        run_processing(cfg, logger)
        if args.run == "process": return

    # INFLUENCE
    if args.run in {"all","influence"}:
        run_influence(cfg, logger)
        if args.run == "influence": return

    # COOCCURRENCE
    if args.run in {"all","cooc"}:
        run_cooc(cfg, logger)
        if args.run == "cooc": return

    # FEATURES
    if args.run in {"all","features"}:
        build_time_keyword_matrix(cfg, logger)
        if args.run == "features": return

    # PDF INIT
    if args.run in {"all","pdf_init"}:
        run_pdf_init(cfg, logger)
        if args.run == "pdf_init": return

    # SENTIMENT & ESCALATION
    if args.run in {"all","sentiment"}:
        run_sentiment(cfg, logger)
        if args.run == "sentiment": return

    # PDF FIT (μ ablations live here)
    if args.run in {"all", "pdf_fit"}:
        run_pdf_fit(
            cfg, logger,
            mu_mode="per_window",  # "none" | "global" | "per_window"
            mu_value=1.0,  # used only if mu_mode == "global"
            lambda_H=5e-2,
            rho=1.0,
            max_iters=30,
            inner_mm_iters=1,
            enforce_l1_cols=True,
            mu_bounds=(0.0, 5.0),
            lambda_mu_smooth=0.0,  # >0 if you want temporal smoothing on μ_t
            verbose=False,
        )
        if args.run == "pdf_fit":
            return

    # RANK
    if args.run in {"all","rank"}:
        run_ranking(cfg, logger)
        if args.run == "rank": return

    # CASE STUDY FIGURE
    if args.run in {"all","casestudy"}:
        run_case_study(cfg, logger, topic_id=args.topic, center_date=args.center, days=args.days)
        if args.run == "casestudy": return


    # CASE STUDY (multi-topic companion)
    if args.run in {"all","casestudy_multi"}:
        # reuse args.center and args.days; allow a topn override via env or default to 5
        topn = int(os.environ.get("TOPN", "5"))
        run_case_study_multi(cfg, logger, center_date=args.center, days=args.days, topn=topn, make_overlay_S=True)
        if args.run == "casestudy_multi": return

    # CASE STUDY TABLE (metrics + daily series, English-only)
    if args.run in {"all","case_table"}:
        run_case_table(cfg, logger, topic_id=args.topic, center_date=args.center, days=args.days)
        if args.run == "case_table": return

    # CASE STUDY BATCH (multiple topics → figure + tables per topic)
    if args.run == "case_batch":
        topic_ids = _parse_topics(args.topics)   # e.g., "1,3,5,7,10"
        run_case_batch(cfg, logger, topic_ids=topic_ids, days=args.days, redact_dates=True)
        return

    # --- MODEL EVAL (AUC/AP for severity S; main + optional supplement) ---
    if args.run == "eval_model":
        # Main headline: auto Top-K by S, days=args.days
        evaluate_model(cfg, logger, topic_ids=None, days=args.days, save_prefix="eval_main")

        # Optional supplement if explicit topics are provided
        if args.topics.strip():
            topic_ids = _parse_topics(args.topics)
            evaluate_model(cfg, logger, topic_ids=topic_ids, days=args.days, save_prefix="eval_supp")
        return

    # --- BASELINE EFFECTIVENESS: REPORT (AUC/AP/lead-time/Spearman) ---
    if args.run in {"all","eval_baselines_report"}:
        topic_ids = _parse_topics(args.topics) if args.topics and args.topics.strip() else None
        evaluate_baselines(cfg, logger, topic_ids=topic_ids, days=args.days, save_prefix="eval_baselines")
        if args.run == "eval_baselines_report":
            return

    # --- BASELINE EFFECTIVENESS: FIGURE (bars + boxplot; auto-runs report if missing) ---
    if args.run in {"all","eval_baselines_fig"}:
        topic_ids = _parse_topics(args.topics) if args.topics and args.topics.strip() else None
        run_eval_baselines_figure(cfg, logger, topic_ids=topic_ids, days=args.days,
                                  save_prefix="eval_baselines", include_spearman=True)
        if args.run == "eval_baselines_fig":
            return

    # --- Convenience: run both report and figure in one go ---
    if args.run == "eval_baselines_all":
        topic_ids = _parse_topics(args.topics) if args.topics and args.topics.strip() else None
        evaluate_baselines(cfg, logger, topic_ids=topic_ids, days=args.days, save_prefix="eval_baselines")
        run_eval_baselines_figure(cfg, logger, topic_ids=topic_ids, days=args.days,
                                  save_prefix="eval_baselines", include_spearman=True)
        return

    # --- INDIVIDUAL BASELINE RUNS (reports) ---
    if args.run == "baseline_volume_report":
        run_baseline_volume(cfg, logger, topic_id=args.topic, center_date=args.center, days=args.days); return
    if args.run == "baseline_soft_volume_report":
        run_baseline_soft_volume(cfg, logger, topic_id=args.topic, center_date=args.center, days=args.days); return
    if args.run == "baseline_soft_volume_weighted_report":
        run_baseline_soft_volume_weighted(cfg, logger, topic_id=args.topic, center_date=args.center, days=args.days); return
    if args.run == "baseline_sentiment_mean_report":
        run_baseline_sentiment_mean(cfg, logger, topic_id=args.topic, center_date=args.center, days=args.days); return

    # --- INDIVIDUAL BASELINE RUNS (figures) ---
    if args.run == "baseline_volume_fig":
        run_baseline_volume_figure(cfg, logger, topic_id=args.topic, center_date=args.center, days=args.days); return
    if args.run == "baseline_soft_volume_fig":
        run_baseline_soft_volume_figure(cfg, logger, topic_id=args.topic, center_date=args.center, days=args.days); return
    if args.run == "baseline_soft_volume_weighted_fig":
        run_baseline_soft_volume_weighted_figure(cfg, logger, topic_id=args.topic, center_date=args.center, days=args.days); return
    if args.run == "baseline_sentiment_mean_fig":
        run_baseline_sentiment_mean_figure(cfg, logger, topic_id=args.topic, center_date=args.center, days=args.days); return

    # --- Convenience: run all baselines for one topic (reports/figs) ---
    if args.run == "baseline_all_reports":
        for fn in (run_baseline_volume, run_baseline_soft_volume,
                   run_baseline_soft_volume_weighted, run_baseline_sentiment_mean):
            fn(cfg, logger, topic_id=args.topic, center_date=args.center, days=args.days)
        return
    if args.run == "baseline_all_figs":
        for fn in (run_baseline_volume_figure, run_baseline_soft_volume_figure,
                   run_baseline_soft_volume_weighted_figure, run_baseline_sentiment_mean_figure):
            fn(cfg, logger, topic_id=args.topic, center_date=args.center, days=args.days)
        return

    # --- β PREP: materialize missing factors (frequency, user_influence) ---
    if args.run == "beta_prep":
        run_derive_factors(cfg, logger, save_prefix="derived")
        return

    # β ablation (R3)
    if args.run == "beta_ablation":
        _ensure_beta_factors(cfg, logger)  # <<< ensure inputs
        res = run_beta_ablation(cfg, logger, topk=None, save_prefix="beta_ablation")
        if isinstance(res, dict) and "summary_csv" in res:  # <<< correct key
            logger.info(f"β-ablation CSV → {os.path.abspath(res['summary_csv'])}")
        return

    # β ablation (figure only; will auto-run report if missing)
    if args.run == "beta_ablation_fig":
        run_beta_ablation_figure(cfg, logger, save_prefix="beta_ablation", use_se=False)
        return

    if args.run in {"all", "K_sensitivity"}:
        logger.info("Running K sensitivity analysis...")
        run_k_sensitivity(cfg, logger)
        logger.info("K sensitivity analysis completed.")

    if args.run in {"all", "M_sensitivity"}:
        logger.info("Running M sensitivity analysis...")
        run_m_sensitivity(cfg, logger)
        logger.info("M sensitivity analysis completed.")

    if args.run in {"all", "h_sensitivity"}:
        logger.info("Running h sensitivity analysis...")
        run_h_sensitivity(cfg, logger)
        logger.info("h sensitivity analysis completed.")

    if args.run in {"all", "early_warning"}:
        logger.info("Running early-warning detection curves...")
        generate_early_warning_alarms(cfg, logger)
        logger.info("Early-warning detection completed.")

    # --- Visualization Stage (placed before other processes) ---
    if args.run in {"all", "visualizations"}:
        logger.info("Running visualizations...")
        from src.sentiment.sentiment_visualization import run_visualizations
        run_visualizations(cfg)  # Passing the loaded config object

        # Return after visualizations if only visualizations are needed
        if args.run == "visualizations":
            return

    # ------------------ ALL: evaluation + baselines (no CLI needed) ------------------
    if args.run == "all":
        # 1) Evaluation (headline result; prints to console + writes CSVs)
        evaluate_model(cfg, logger, topic_ids=None, days=args.days, save_prefix="eval_main")

        # 2) Decide which topics for baselines:
        if args.topics.strip():
            topics = _parse_topics(args.topics)
        elif args.topic is not None:
            topics = [args.topic]
        else:
            topk = int(cfg.get("evaluation", {}).get("topk", 5))  # falls back to 5 if absent
            topics = _auto_topk_by_S(cfg, topk=topk)

        # 3) Baselines — run reports AND figures for each topic
        for k in topics:
            # Reports (each writes its own CSV in outputs/reports/baselines/)
            run_baseline_volume(cfg, logger, topic_id=k, center_date=args.center, days=args.days)
            run_baseline_soft_volume(cfg, logger, topic_id=k, center_date=args.center, days=args.days)
            run_baseline_soft_volume_weighted(cfg, logger, topic_id=k, center_date=args.center, days=args.days)
            run_baseline_sentiment_mean(cfg, logger, topic_id=k, center_date=args.center, days=args.days)

            # Figures (each writes a PNG in outputs/figures/)
            run_baseline_volume_figure(cfg, logger, topic_id=k, center_date=args.center, days=args.days)
            run_baseline_soft_volume_figure(cfg, logger, topic_id=k, center_date=args.center, days=args.days)
            run_baseline_soft_volume_weighted_figure(cfg, logger, topic_id=k, center_date=args.center, days=args.days)
            run_baseline_sentiment_mean_figure(cfg, logger, topic_id=k, center_date=args.center, days=args.days)
        # 4) Beta ablation (R3) — run automatically in "all"
        _ensure_beta_factors(cfg, logger)
        res = run_beta_ablation(cfg, logger, topk=None, save_prefix="beta_ablation")
        if isinstance(res, dict) and "summary_csv" in res:
            logger.info(f"β-ablation CSV → {os.path.abspath(res['summary_csv'])}")
        run_beta_ablation_figure(cfg, logger, save_prefix="beta_ablation", use_se=False)
        # #early_warning
        generate_early_warning_alarms(cfg, logger)  # Run early warning if "all" is selected


    print("\n✅ Completed requested stage(s). See outputs/artifacts/, outputs/reports/, outputs/figures/.\n")

if __name__ == "__main__":
    main()
